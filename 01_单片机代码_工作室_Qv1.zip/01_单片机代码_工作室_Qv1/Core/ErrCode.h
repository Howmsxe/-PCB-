#ifndef __CORE_ERRCODE_H
#define __CORE_ERRCODE_H

#define ERR_SENS      67u
#define ERR_BELT      72u
#define ERR_PCA_FAIL  74u

#endif
