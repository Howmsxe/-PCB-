#ifndef __CORE_SCHED_H
#define __CORE_SCHED_H

#include "Core/Types.h"
#include "Core/Time.h"

void Sched_Init(void);

#define STEP_END   0xFFu

typedef u8 (*StepAct)(void);

typedef struct {
    StepAct act;
    u16     to_ms;
    u8      next_ok;
    u8      next_to;
} Step;

u8 Step_Run(const Step *tbl, u8 n, u8 first);

void Step_SetDeadline(u32 toMs);

extern u32 g_stepDlT0;
extern u32 g_stepDlMs;
extern u8  g_stepDlOn;
#define STEP_EXPIRED()   ((g_stepDlOn != 0u) && (TIME_ELAPSED(g_stepDlT0, g_stepDlMs) ? 1u : 0u))

#endif
