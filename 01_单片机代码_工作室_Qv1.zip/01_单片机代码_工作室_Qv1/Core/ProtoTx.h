#ifndef __CORE_PROTO_TX_H
#define __CORE_PROTO_TX_H

#include "Core/Types.h"

#define PROTO_TX_READY        0xABu
#define PROTO_TX_ACCEPT_OK    0xAAu
#define PROTO_TX_START_COMM   0xACu
#define PROTO_TX_END_COMM     0xA3u
#define PROTO_TX_CONFIRM_OK   0xF0u
#define PROTO_TX_PARAM_BEGIN  0xB1u
#define PROTO_TX_PARAM_END    0xB2u
#define PROTO_TX_PARAM_OK     0xB3u
#define PROTO_TX_ACTION_DONE  0xD6u
#define PROTO_TX_RETRY        0xD7u

#define PROTO_TX_ERR_INTERNAL 0x83u
#define PROTO_EXT_BAD_DATA    0xA1u
#define PROTO_EXT_BAD_STATE   0xA2u

void Proto_SendReady(void);
void Proto_SendAcceptOk(u8 echo);
void Proto_SendStartComm(void);
void Proto_SendConfirmOk(void);
void Proto_SendEndComm(void);
void Proto_SendExtErr(u8 code);
void Proto_SendActionDone(void);
void Proto_SendRetry(void);
void Proto_SendIntErr(u8 code);

#endif
