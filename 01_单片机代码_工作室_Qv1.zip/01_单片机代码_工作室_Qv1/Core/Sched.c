#include "Core/Sched.h"
#include "Core/Time.h"

u32 g_stepDlT0 = 0u;
u32 g_stepDlMs = 0u;
u8  g_stepDlOn = 0u;

void Step_SetDeadline(u32 toMs)
{
    if (toMs == 0u) { g_stepDlOn = 0u; return; }
    g_stepDlT0 = Time_Now();
    g_stepDlMs = toMs;
    g_stepDlOn = 1u;
}

u8 Step_Run(const Step *tbl, u8 n, u8 first)
{
    u8 i = first;
    u8 ok = 1u;

    while (i != (u8)STEP_END)
    {
        const Step *s;
        u32 t0;

        if (i >= n) return 0u;
        s  = &tbl[i];
        t0 = Time_Now();

        Step_SetDeadline(s->to_ms);
        ok = (u8)((s->act != 0) ? s->act() : 0u);
        Step_SetDeadline(0u);

        if ((ok != 0u) && (s->to_ms != 0u) && TIME_ELAPSED(t0, s->to_ms)) ok = 0u;

        i = (ok != 0u) ? s->next_ok : s->next_to;
    }
    return ok;
}

void Sched_Init(void)
{

}
