#include "Core/ParamCode.h"

STATIC_ASSERT(CFG_POS_SLOTS >= (u8)POS_COUNT, param_code_pos_slots);
STATIC_ASSERT(CFG_AXIS_SLOTS == 3u, param_code_axis_slots_3);
STATIC_ASSERT((u16)(PARAM_CODE_POS_LAST - PARAM_CODE_POS_FIRST + 1u)
              == (u16)((u16)POS_COUNT * (u16)CFG_AXIS_SLOTS), param_code_pos_span);

u8 ParamCode_Apply(SysParams *p, u8 code, s16 v)
{
    if (p == 0) return 0u;

    if ((code >= PARAM_CODE_POS_FIRST) && (code <= PARAM_CODE_POS_LAST))
    {
        u8 k = (u8)(code - PARAM_CODE_POS_FIRST);

        p->pos[k / (u8)CFG_AXIS_SLOTS][k % (u8)CFG_AXIS_SLOTS] = v;
        return 1u;
    }

    switch (code)
    {

    case PARAM_CODE_RUN_SPEED0:  p->runSpeed[0]   = v; return 1u;
    case PARAM_CODE_RUN_SPEED1:  p->runSpeed[1]   = v; return 1u;
    case PARAM_CODE_RUN_SPEED2:  p->runSpeed[2]   = v; return 1u;
    case PARAM_CODE_BELT_SPEED0: p->beltSpeed[0]  = v; return 1u;
    case PARAM_CODE_BELT_SPEED1: p->beltSpeed[1]  = v; return 1u;
    case PARAM_CODE_BELT_DIR0:   p->beltDir[0]    = v; return 1u;
    case PARAM_CODE_BELT_DIR1:   p->beltDir[1]    = v; return 1u;
    case PARAM_CODE_SENS_DELAY0: p->sensDelay[0]  = v; return 1u;
    case PARAM_CODE_SENS_DELAY1: p->sensDelay[1]  = v; return 1u;

    case PARAM_CODE_SRV_TYPE0:
        if ((v == (s16)SRV_TYPE_180) || (v == (s16)SRV_TYPE_360)) { p->srvType[0] = (u8)v; return 1u; }
        return 0u;
    case PARAM_CODE_SRV_TYPE1:
        if ((v == (s16)SRV_TYPE_180) || (v == (s16)SRV_TYPE_360)) { p->srvType[1] = (u8)v; return 1u; }
        return 0u;
    case PARAM_CODE_SRV_TYPE2:
        if ((v == (s16)SRV_TYPE_180) || (v == (s16)SRV_TYPE_360)) { p->srvType[2] = (u8)v; return 1u; }
        return 0u;

    case PARAM_CODE_BELT_MICRO0: p->beltMicro[0]  = v; return 1u;
    case PARAM_CODE_BELT_MICRO1: p->beltMicro[1]  = v; return 1u;

    default: return 0u;
    }
}

u8 ParamCode_Get(const SysParams *p, u8 code, s16 *v)
{
    u8 k;

    if ((p == 0) || (v == 0)) return 0u;

    if ((code >= PARAM_CODE_POS_FIRST) && (code <= PARAM_CODE_POS_LAST))
    {
        k = (u8)(code - PARAM_CODE_POS_FIRST);
        *v = p->pos[k / (u8)CFG_AXIS_SLOTS][k % (u8)CFG_AXIS_SLOTS];
        return 1u;
    }

    switch (code)
    {
    case PARAM_CODE_RUN_SPEED0:  *v = p->runSpeed[0];  return 1u;
    case PARAM_CODE_RUN_SPEED1:  *v = p->runSpeed[1];  return 1u;
    case PARAM_CODE_RUN_SPEED2:  *v = p->runSpeed[2];  return 1u;
    case PARAM_CODE_BELT_SPEED0: *v = p->beltSpeed[0]; return 1u;
    case PARAM_CODE_BELT_SPEED1: *v = p->beltSpeed[1]; return 1u;
    case PARAM_CODE_BELT_DIR0:   *v = p->beltDir[0];   return 1u;
    case PARAM_CODE_BELT_DIR1:   *v = p->beltDir[1];   return 1u;
    case PARAM_CODE_SENS_DELAY0: *v = p->sensDelay[0]; return 1u;
    case PARAM_CODE_SENS_DELAY1: *v = p->sensDelay[1]; return 1u;
    case PARAM_CODE_SRV_TYPE0:   *v = (s16)p->srvType[0]; return 1u;
    case PARAM_CODE_SRV_TYPE1:   *v = (s16)p->srvType[1]; return 1u;
    case PARAM_CODE_SRV_TYPE2:   *v = (s16)p->srvType[2]; return 1u;
    case PARAM_CODE_BELT_MICRO0: *v = p->beltMicro[0]; return 1u;
    case PARAM_CODE_BELT_MICRO1: *v = p->beltMicro[1]; return 1u;
    default: return 0u;
    }
}
