#ifndef __CORE_TYPES_H
#define __CORE_TYPES_H

#include "stm32f10x.h"

#define ARRAY_LEN(a)   (sizeof(a)/sizeof((a)[0]))
#define CLAMP(v,lo,hi) ((v) < (lo) ? (lo) : ((v) > (hi) ? (hi) : (v)))
#define UNUSED(x)      ((void)(x))

#define STATIC_ASSERT(cond, tag)  typedef char static_assert_##tag[(cond) ? 1 : -1]

#define TIME_ELAPSED(sinceMs, n)  ((u32)(Time_Now() - (sinceMs)) >= (u32)(n))
#define TIME_DUE(t)               (((s32)(Time_Now() - (t)) >= 0))

#ifndef __STM32F10X_STDPERIPH_VERSION
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef int8_t   s8;
typedef int16_t  s16;
typedef int32_t  s32;
#endif

typedef enum {
    RUN_IDLE = 0, RUN_HOME = 1, RUN_FLOW = 2,
    RUN_TEST = 3, RUN_STEPT = 4, RUN_SENST = 5, RUN_LINK = 6
} RunMode;

#endif
