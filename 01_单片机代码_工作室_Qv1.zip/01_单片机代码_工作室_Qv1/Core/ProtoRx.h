#ifndef __CORE_PROTO_RX_H
#define __CORE_PROTO_RX_H

#include "Core/Types.h"

#define PROTO_RX_START_COMM   0x53u
#define PROTO_RX_READY        0x54u
#define PROTO_RX_ACCEPT       0x55u
#define PROTO_RX_RETRY        0x57u
#define PROTO_RX_END_COMM     0x5Cu
#define PROTO_RX_CONFIRM      0x0Fu
#define PROTO_RX_IDLE_BYTE    0x00u

#define PROTO_RX_ACT_START_MAIN      2u
#define PROTO_RX_ACT_CANCEL_ALL      3u
#define PROTO_RX_ACT_BOX_1           4u
#define PROTO_RX_ACT_BOX_6           9u
#define PROTO_RX_ACT_RESET          10u
#define PROTO_RX_ACT_ESTOP_HOME     11u
#define PROTO_RX_ACT_EXPORT         12u
#define PROTO_RX_ACT_IMPORT         13u
#define PROTO_RX_ACT_MAX            13u

#define PROTO_SESSION_TIMEOUT_MS     5000u

#define PROTO_IMPORT_TIMEOUT_MS     15000u

/* 从机发起流程（识别到位）单步超时：上位机每步响应应在几十 ms 内完成。 */
#define PROTO_SLAVE_TIMEOUT_MS      1000u

void Proto_RxByte(u8 b);
void Proto_Poll(void);
void Proto_Enable(void);
u8   Proto_Importing(void);

/* 从机发起：上光电检测到有料后，主动发 0xAC→0xD6→0xA3 通知上位机抓拍识别。
 * 流程为异步状态机，由 Proto_Poll 推进；Proto_SlaveShot 只发起第一帧 0xAC。 */
void Proto_SlaveShot(void);

#endif
