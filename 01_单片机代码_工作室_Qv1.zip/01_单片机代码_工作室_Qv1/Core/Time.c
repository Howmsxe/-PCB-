#include "Core/Time.h"
#include "Modules/Encoder.h"
#include "stm32f10x.h"

#define TIME_TIM1_PSC        719u
#define TIME_TIM1_ARR        0xFFFFu
#define TIME_RAW_US_PER_TICK 10u

static volatile u32 s_ms = 0u;

void Time_Init(void)
{

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

}

void Time_FreeRunInit(void)
{
    TIM_TimeBaseInitTypeDef t;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

    t.TIM_Prescaler         = (u16)TIME_TIM1_PSC;
    t.TIM_CounterMode       = TIM_CounterMode_Up;
    t.TIM_Period            = (u16)TIME_TIM1_ARR;
    t.TIM_ClockDivision     = TIM_CKD_DIV1;
    t.TIM_RepetitionCounter = 0u;
    TIM_TimeBaseInit(TIM1, &t);

    TIM_Cmd(TIM1, ENABLE);
}

u32 Time_RawUs(void)
{

    return (u32)TIM1->CNT * (u32)TIME_RAW_US_PER_TICK;
}

void Time_AddMs(u32 ms)
{
    u32 pm;

    if (ms == 0u) return;

    pm = __get_PRIMASK();
    __disable_irq();
    s_ms += ms;
    __set_PRIMASK(pm);
}

u32 Time_Now(void)
{
    return s_ms;
}

void Time_TickFromIrq(void)
{

    s_ms++;

    Enc_IsrTick();
}

u32 Time_Since(u32 sinceMs)
{

    return (u32)(Time_Now() - sinceMs);
}

u8 Time_Elapsed(u32 sinceMs, u32 n)
{

    if ((u32)(Time_Now() - sinceMs) >= n) return 1u;
    return 0u;
}

u8 Time_Due(u32 t)
{

    if ((s32)(Time_Now() - t) >= 0) return 1u;
    return 0u;
}
