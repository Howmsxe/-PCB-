#include "Core/Types.h"
#include "Core/ProtoRx.h"
#include "Core/ProtoTx.h"
#include "Core/Time.h"
#include "Core/ParamCode.h"
#include "Modules/SerialPort.h"
#include "Modules/Params.h"
#include "App/Flow.h"
#include "App/Cmd.h"
#include "App/ParamSet.h"
#include "Ui/Ui.h"

typedef enum {
    PROTO_ST_IDLE = 0,
    PROTO_ST_WAIT_ACTION,
    PROTO_ST_WAIT_CONFIRM
} ProtoState;

/* 从机发起流程（识别到位）：0xAC→等0x54→0xD6+0xA3→等0x55→等复述→0xF0×2。 */
typedef enum {
    SLAVE_ST_IDLE = 0,
    SLAVE_ST_WAIT_READY,
    SLAVE_ST_WAIT_ACCEPT,
    SLAVE_ST_WAIT_ECHO
} SlaveState;

static u8  Proto_ExecAction(u8 act);
static void Proto_SessionTick(void);
static void Proto_ImportBegin(void);
static void Proto_ImportReset(void);
static void Proto_ImportFinish(void);
static void Proto_ImportBad(void);
static void Proto_ImportTimeout(void);
static void Proto_ImportByte(u8 b);
static void Proto_ImportTick(void);
static void Proto_SlaveRxByte(u8 b);
static void Proto_SlaveTick(void);

static u8 s_enabled = 0u;

static u8 s_state = (u8)PROTO_ST_IDLE;

static u8 s_action = 0u;

static u32 s_t0 = 0u;

static u8  s_slaveState = (u8)SLAVE_ST_IDLE;
static u32 s_slaveT0    = 0u;

static u8 Proto_ExecAction(u8 act)
{
    /* 返回 1 = 动作已生效（调用方据此发 0xD6 动作完成）；
     * 返回 0 = 动作被拒/未生效（调用方据此发 0xA2，不再发 0xD6）。
     * 文档 §3：失败才发 0xA2，成功才发 0xD6，两者不能连发。 */
    switch (act)
    {
    case (u8)PROTO_RX_ACT_START_MAIN:
        UI_EStop();
        /* Flow_Start：1=已启动；0=已在主循环(拒绝)；2=挂起(上电/回正中/参数未就绪)。
         * 方案 A：0 与 2 都视为「未立即生效」，发 0xA2，不发 0xD6。 */
        return (Flow_Start() == 1u) ? 1u : 0u;

    case (u8)PROTO_RX_ACT_CANCEL_ALL:
        UI_EStop();
        Flow_Abort();
        return 1u;

    case (u8)PROTO_RX_ACT_RESET:
        return (Flow_Reset() == 1u) ? 1u : 0u;

    case (u8)PROTO_RX_ACT_ESTOP_HOME:
        UI_EStop();
        Flow_Home();
        return 1u;

    case (u8)PROTO_RX_ACT_EXPORT:
        Cmd_ParamExport();
        return 1u;

    case (u8)PROTO_RX_ACT_IMPORT:
        Proto_ImportBegin();
        return 1u;

    default:

        if ((act >= (u8)PROTO_RX_ACT_BOX_1) && (act <= (u8)PROTO_RX_ACT_BOX_6))
        {
            return (Flow_SetBox((u8)(act - (u8)PROTO_RX_ACT_BOX_1 + 1u)) == 1u) ? 1u : 0u;
        }
        return 0u;
    }
}

static u8  s_impOn   = 0u;
static u32 s_impT    = 0u;
static u8  s_impN    = 0u;
static u8  s_impCode = 0u;
static u8  s_impLo   = 0u;
static u8  s_impHi   = 0u;

static void Proto_ImportBegin(void)
{
    /* 参数导入已降级：不进入导入态、不接收参数，直接回 0xB3 接受确认，
     * 让上位机的导入流程能走完（不写 Flash）。 */
    s_impOn = 0u;
    Ser_SendByte((u8)PROTO_TX_PARAM_OK);
}

static void Proto_ImportReset(void)
{
    s_impOn = 0u;
    s_impN  = 0u;
}

static void Proto_ImportFinish(void)
{
    Proto_ImportReset();
    Params_ClampAll(Params_Draft());
    ParamSet_ReqSave();
    Ser_SendByte((u8)PROTO_TX_PARAM_OK);
}

static void Proto_ImportBad(void)
{
    Proto_ImportReset();
    Proto_SendExtErr((u8)PROTO_EXT_BAD_DATA);
}

static void Proto_ImportTimeout(void)
{
    Proto_ImportReset();
    Proto_SendExtErr((u8)PROTO_EXT_BAD_STATE);
}

static void Proto_ImportByte(u8 b)
{
    if (s_impN == 0u)
    {
        if ((b == (u8)PROTO_RX_CONFIRM) || (b == (u8)PROTO_RX_IDLE_BYTE))
        {
            return;
        }
        if (b == (u8)PARAM_CODE_END)
        {
            Proto_ImportFinish();
            return;
        }
        s_impCode = b;
        s_impN    = 1u;
        return;
    }

    if (s_impN == 1u)
    {
        s_impLo = b;
        s_impN  = 2u;
        return;
    }

    if (s_impN == 2u)
    {
        s_impHi = b;
        s_impN  = 3u;
        return;
    }

    s_impN = 0u;
    if (b != (u8)PARAM_CODE_END)
    {
        Proto_ImportBad();
        return;
    }
    if (ParamCode_Apply(Params_Draft(), s_impCode,
                        (s16)((u16)s_impLo | ((u16)s_impHi << 8u))) == 0u)
    {
        Proto_ImportBad();
    }
}

static void Proto_ImportTick(void)
{
    if (s_impOn == 0u) return;
    if (!TIME_ELAPSED(s_impT, PROTO_IMPORT_TIMEOUT_MS)) return;
    Proto_ImportTimeout();
}

static void Proto_SessionTick(void)
{
    if (s_state == (u8)PROTO_ST_IDLE) return;
    if (s_impOn != 0u) return;
    if (!TIME_ELAPSED(s_t0, PROTO_SESSION_TIMEOUT_MS)) return;
    s_action = 0u;
    s_state  = (u8)PROTO_ST_IDLE;
}

void Proto_SlaveShot(void)
{
    if (s_enabled == 0u) return;
    if (s_slaveState != (u8)SLAVE_ST_IDLE) return;   /* 已有从机流程在跑，忽略 */

    s_slaveState = (u8)SLAVE_ST_WAIT_READY;
    s_slaveT0    = Time_Now();
    Proto_SendStartComm();                            /* 发 0xAC 开始通讯 */
}

/* 从机发起流程的字节处理：此路径在方向位过滤（最高位=1 丢弃）之前，
 * 因为上位机复述的从机指令 0xD6 最高位=1，会被主路径的过滤误丢。 */
static void Proto_SlaveRxByte(u8 b)
{
    switch (s_slaveState)
    {
    case (u8)SLAVE_ST_WAIT_READY:
        if (b == (u8)PROTO_RX_READY)                 /* 0x54 上位机准备好 */
        {
            Proto_SendActionDone();                  /* 发 0xD6 识别到位 */
            Proto_SendEndComm();                     /* 发 0xA3 结束通讯 */
            s_slaveState = (u8)SLAVE_ST_WAIT_ACCEPT;
            s_slaveT0    = Time_Now();
        }
        break;

    case (u8)SLAVE_ST_WAIT_ACCEPT:
        if (b == (u8)PROTO_RX_ACCEPT)                /* 0x55 上位机接受成功 */
        {
            s_slaveState = (u8)SLAVE_ST_WAIT_ECHO;
            s_slaveT0    = Time_Now();
        }
        break;

    case (u8)SLAVE_ST_WAIT_ECHO:
        /* 复述字节：应为 0xD6（识别到位动作位）。 */
        if (b == (u8)PROTO_TX_ACTION_DONE)
        {
            Proto_SendConfirmOk();                   /* 一致 → 0xF0 0xF0 */
        }
        else
        {
            Proto_SendRetry();                       /* 不符 → 0xD7 0xD7 */
        }
        s_slaveState = (u8)SLAVE_ST_IDLE;
        break;

    default:
        break;
    }
}

static void Proto_SlaveTick(void)
{
    if (s_slaveState == (u8)SLAVE_ST_IDLE) return;
    if (!TIME_ELAPSED(s_slaveT0, PROTO_SLAVE_TIMEOUT_MS)) return;
    s_slaveState = (u8)SLAVE_ST_IDLE;                /* 超时回空闲 */
}

void Proto_RxByte(u8 b)
{

    if (s_enabled == 0u)
    {
        return;
    }

    if (s_impOn != 0u)
    {
        Proto_ImportByte(b);
        return;
    }

    if (b == (u8)PROTO_RX_IDLE_BYTE)
    {
        return;
    }

    /* 从机发起流程优先于方向位过滤：上位机复述的从机指令 0xD6 最高位=1，
     * 会被下方 (b & 0x80) 过滤误丢。仅在从机流程活跃时走此路径。 */
    if (s_slaveState != (u8)SLAVE_ST_IDLE)
    {
        Proto_SlaveRxByte(b);
        return;
    }

    if ((b & 0x80u) != 0u)
    {
        return;
    }

    if (b == (u8)PROTO_RX_START_COMM)
    {
        s_state  = (u8)PROTO_ST_WAIT_ACTION;
        s_action = 0u;
        s_t0     = Time_Now();
        Proto_SendReady();
        return;
    }

    if (b == (u8)PROTO_RX_RETRY)
    {
        s_action = 0u;
        s_state  = (u8)PROTO_ST_IDLE;
        return;
    }

    if (b == (u8)PROTO_RX_END_COMM)
    {
        if (s_state != (u8)PROTO_ST_WAIT_ACTION)
        {
            return;
        }
        if (s_action == 0u)
        {
            Proto_SendExtErr((u8)PROTO_EXT_BAD_STATE);
            return;
        }
        s_state = (u8)PROTO_ST_WAIT_CONFIRM;
        Proto_SendAcceptOk(s_action);
        return;
    }

    if (b == (u8)PROTO_RX_CONFIRM)
    {
        u8 act;

        if (s_state != (u8)PROTO_ST_WAIT_CONFIRM)
        {
            return;
        }
        act      = s_action;
        s_action = 0u;
        s_state  = (u8)PROTO_ST_IDLE;
        if (Proto_ExecAction(act) != 0u)
        {
            /* 动作已生效 → 发 0xD6 动作完成。
             * 参数导入（动作13）降级为"Proto_ImportBegin 内已回 0xB3 接受确认"，不发 0xD6。 */
            if (act != (u8)PROTO_RX_ACT_IMPORT)
            {
                Proto_SendActionDone();
            }
        }
        else
        {
            /* 动作被拒/未生效 → 发 0xA2，不发 0xD6（文档 §3：失败才发 0xA2）。 */
            Proto_SendExtErr((u8)PROTO_EXT_BAD_STATE);
        }
        return;
    }

    if (s_state == (u8)PROTO_ST_WAIT_ACTION)
    {
        if (b <= (u8)PROTO_RX_ACT_MAX)
        {
            if (b == 1u)
            {
                return;
            }
            /* 文档 §4 规则3：一次会话只认第一个动作码，多发的只认第一个。 */
            if (s_action == 0u)
            {
                s_action = b;
            }
            return;
        }
        return;
    }

}

void Proto_Poll(void)
{
    u8 b;
    u8 n;

    if (s_enabled == 0u)
    {
        for (n = 0u; n < 32u; n++)
        {
            if (!Ser_GetByte(&b))
            {
                return;
            }
        }
        return;
    }

    Proto_ImportTick();
    Proto_SessionTick();
    Proto_SlaveTick();

    for (n = 0u; n < 32u; n++)
    {
        if (!Ser_GetByte(&b))
        {
            return;
        }

        Proto_RxByte(b);
    }
}

void Proto_Enable(void)
{
    Ser_Flush();
    s_enabled = 1u;
}

u8 Proto_Importing(void)
{
    return s_impOn;
}
