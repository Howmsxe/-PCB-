#include "Core/ProtoTx.h"
#include "Core/ErrCode.h"
#include "Modules/SerialPort.h"

void Proto_SendReady(void)
{
    Ser_SendByte((u8)PROTO_TX_READY);
}

void Proto_SendAcceptOk(u8 echo)
{
    Ser_SendByte((u8)PROTO_TX_ACCEPT_OK);
    Ser_SendByte(echo);
}

void Proto_SendStartComm(void)
{
    Ser_SendByte((u8)PROTO_TX_START_COMM);
}

void Proto_SendConfirmOk(void)
{
    Ser_SendByte((u8)PROTO_TX_CONFIRM_OK);
    Ser_SendByte((u8)PROTO_TX_CONFIRM_OK);
}

void Proto_SendEndComm(void)
{
    Ser_SendByte((u8)PROTO_TX_END_COMM);
}

void Proto_SendExtErr(u8 code)
{
    if ((code != (u8)PROTO_EXT_BAD_DATA) && (code != (u8)PROTO_EXT_BAD_STATE))
    {
        code = (u8)PROTO_EXT_BAD_STATE;
    }
    Ser_SendByte(code);
}

void Proto_SendActionDone(void)
{
    Ser_SendByte((u8)PROTO_TX_ACTION_DONE);
}

void Proto_SendRetry(void)
{
    Ser_SendByte((u8)PROTO_TX_RETRY);
    Ser_SendByte((u8)PROTO_TX_RETRY);
}

void Proto_SendIntErr(u8 code)
{
    if ((code < 65u) || (code > 74u))
    {
        code = 65u;
    }
    Ser_SendByte((u8)PROTO_TX_ERR_INTERNAL);
    Ser_SendByte(code);
}
