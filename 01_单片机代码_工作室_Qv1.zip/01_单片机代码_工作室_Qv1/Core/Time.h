#ifndef __CORE_TIME_H
#define __CORE_TIME_H

#include "Core/Types.h"

void     Time_Init(void);
void     Time_FreeRunInit(void);
u32      Time_Now(void);
u32      Time_RawUs(void);
void     Time_AddMs(u32 ms);
void     Time_TickFromIrq(void);
u32      Time_Since(u32 sinceMs);
u8       Time_Elapsed(u32 sinceMs, u32 n);
u8       Time_Due(u32 t);

#endif
