#ifndef __CORE_PARAM_CODE_H
#define __CORE_PARAM_CODE_H

#include "Core/Types.h"
#include "Modules/Params.h"

#define PARAM_CODE_POS_FIRST    1u
#define PARAM_CODE_POS_LAST     24u
#define PARAM_CODE_RUN_SPEED0   25u
#define PARAM_CODE_RUN_SPEED1   26u
#define PARAM_CODE_RUN_SPEED2   27u
#define PARAM_CODE_BELT_SPEED0  28u
#define PARAM_CODE_BELT_SPEED1  29u
#define PARAM_CODE_BELT_DIR0    30u
#define PARAM_CODE_BELT_DIR1    31u
#define PARAM_CODE_SENS_DELAY0  32u
#define PARAM_CODE_SENS_DELAY1  33u
#define PARAM_CODE_SRV_TYPE0    34u
#define PARAM_CODE_SRV_TYPE1    35u
#define PARAM_CODE_SRV_TYPE2    36u
#define PARAM_CODE_BELT_MICRO0  37u
#define PARAM_CODE_BELT_MICRO1  38u
#define PARAM_CODE_END          0xFFu

u8 ParamCode_Apply(SysParams *p, u8 code, s16 v);

u8 ParamCode_Get(const SysParams *p, u8 code, s16 *v);

#endif
