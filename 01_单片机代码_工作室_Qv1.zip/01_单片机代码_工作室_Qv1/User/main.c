#include "Core/Types.h"
#include "Core/Time.h"
#include "Core/Sched.h"
#include "Bsp/Bsp.h"
#include "Modules/Belt.h"
#include "Modules/Servo.h"
#include "Modules/Sensor.h"
#include "Modules/SerialPort.h"
#include "Modules/Params.h"
#include "Modules/Encoder.h"
#include "Modules/Display/OLED.h"
#include "App/Handshake.h"
#include "App/Flow.h"
#include "App/PowerUp.h"
#include "App/ParamSet.h"
#include "App/Cmd.h"
#include "Ui/Ui.h"
#include "Core/ProtoRx.h"

static void Banner(void)
{
    OLED_Clear();
    OLED_ShowString(1, 1, "Qv1");
    OLED_ShowString(2, 1, "Loops+Ports");
    if (gParamResetFlag) OLED_ShowString(3, 1, "PARAM RESET!");
    OLED_Refresh();
}

int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Params_Load();
    Bsp_Init();
    Bsp_HbInit();
    Time_Init();
    Time_FreeRunInit();
    Enc_Init();
    Ser_Init();
    Sensor_Init();
    OLED_Init();
    PowerUp_Init();
    Hs_Init();
    Flow_Init();
    ParamSet_Init();
    Cmd_Init();
    UI_Init();
    Sched_Init();
    (void)Enc_TakeRotate();
    (void)Enc_TakeEvent();
    PowerUp_Run();
    if (gParamResetFlag) Banner();
    Bsp_WdgInit();   /* ���Ź��ָ����ã�EXTI �ж�ȱʧ�ĸ������ޣ��� stm32f10x_it.c�� */
    while (1)
    {
        Bsp_WdgFeed();
        Proto_Poll();
        UI_RunStep();
    }
}
