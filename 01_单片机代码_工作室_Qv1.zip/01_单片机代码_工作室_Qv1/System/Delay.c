#include "stm32f10x.h"

static void DelayTick_us(u32 xus)
{
    SysTick->LOAD = 72 * xus;
    SysTick->VAL  = 0x00;
    SysTick->CTRL = 0x00000005;
    while (!(SysTick->CTRL & 0x00010000)) { }
    SysTick->CTRL = 0x00000004;
}

void Delay_ms(u32 xms)
{
    while (xms-- != 0u)
    {
        DelayTick_us(1000u);
    }
}
