#ifndef __BSP_BSP_H
#define __BSP_BSP_H

#include "Bsp/BoardPorts.h"

void     Bsp_Init(void);
void     Bsp_Write(PinDef p, u8 level);
void     Bsp_SetMode(PinDef p, u8 dir);
u8       Bsp_Read(PinDef p);
void     Bsp_ExtiConfig(PinDef p, u8 bothEdges, u8 irqPrio);

void     Bsp_HbInit(void);
void     Bsp_HbToggle(void);

void     Bsp_WdgInit(void);
void     Bsp_WdgFeed(void);

#endif
