#include "App/Handshake.h"

void Hs_Init(void)
{

}

void Hs_Clear(HandshakeId id)
{
    (void)id;
}
