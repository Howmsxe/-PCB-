#ifndef __APP_CMD_H
#define __APP_CMD_H

#include "Core/Types.h"

void Cmd_Init(void);
void Cmd_Task(void);

void Cmd_SendEvt(s16 evt);
void Cmd_SendWarn(const char* tag);
void Cmd_SendWarnU32(const char* tag, u32 v);
void Cmd_SendMode(const char* tag);
void Cmd_SendFlow(const char* tag);
void Cmd_SendStall(u16 code);

void Cmd_ParamExport(void);
void Cmd_ParamImportStart(void);
u8   Cmd_Importing(void);

#endif
