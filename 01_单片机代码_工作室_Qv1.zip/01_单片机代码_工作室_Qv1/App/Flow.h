#ifndef __APP_FLOW_H
#define __APP_FLOW_H

#include "Core/Types.h"
#include "Core/ErrCode.h"

typedef enum {
    FLOW_PREP = 0,
    FLOW_FEED,
    FLOW_CLASSIFY,
    FLOW_RETURN
} FlowState;

void    Flow_Init(void);
void    Flow_Home(void);

u8      Flow_Reset(void);

u8      Flow_HomeActive(void);
u8      Flow_Homing(void);
u8      Flow_Homed(void);

void    Flow_HomedMark(u8 ok);

u8      Flow_Start(void);

void    Flow_Abort(void);
u8      Flow_SetBox(u8 n);

u8      Flow_P2P1(s16 arm1, s16 arm2, s16 tray);
u8      Flow_P2P2(s16 tray, s16 arm2, s16 arm1);
RunMode Flow_CurrentMode(void);
FlowState Flow_State(void);
u8      Flow_Running(void);
u8      Flow_CycleKind(void);
const char* Flow_StateName(FlowState s);

u8      Flow_StartTest(u8 testMode);
u8      Flow_TestActive(void);
u8      Flow_TestPending(void);

void    Flow_TestAbort(void);

void    Flow_Service(void);

void    Flow_IdleService(void);
void    Flow_RunTestNow(void);
void    Flow_RunMainNow(void);

u8      Flow_PowerUpBeat(void);

void    Flow_VoidPending(void);

#endif
