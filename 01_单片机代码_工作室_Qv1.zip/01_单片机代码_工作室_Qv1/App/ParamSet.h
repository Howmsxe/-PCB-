#ifndef __APP_PARAMSET_H
#define __APP_PARAMSET_H

#include "Core/Types.h"

void ParamSet_Init(void);
void ParamSet_Task(void);

void ParamSet_ReqCommit(void);
void ParamSet_ReqSave(void);

u8   ParamSet_SafePoint(void);

u8   ParamSet_TakeSaved(void);

u8   ParamSet_SaveHint(void);

#endif
