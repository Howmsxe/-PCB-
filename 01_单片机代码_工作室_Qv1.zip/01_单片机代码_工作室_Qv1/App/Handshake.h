#ifndef __APP_HANDSHAKE_H
#define __APP_HANDSHAKE_H

#include "Core/Types.h"

typedef enum {
    HS_NONE = 0,
    HS_MATERIAL_OUT,
    HS_BELT2_READY,
    HS_ARM_PICK_READY,
    HS_MATERIAL_AT_PICK,
    HS_PICK_DONE,
    HS_RECOG_DONE,
    HS_BOX_DONE,
    HS_USER,
    HS_COUNT
} HandshakeId;

void Hs_Init(void);
void Hs_Clear(HandshakeId id);

#endif
