#include "App/Cmd.h"
#include "Modules/SerialPort.h"
#include "Modules/Params.h"
#include "Core/ParamCode.h"
#include "App/ParamSet.h"
#include "Core/Time.h"
#include "Core/ProtoTx.h"
#include "Core/ProtoRx.h"

void Cmd_ParamExport(void)
{
    u8 code;

    /* 参数导出已降级：按文档 §7 输出 42 条，值统一为 -1（0xFFFF）。
     * 码 1~42，每条 [码][低 0xFF][高 0xFF][0xFF 间隔]；固件无真实参数可读。 */
    Ser_SendByte((u8)PROTO_TX_PARAM_BEGIN);
    for (code = 1u; code <= 42u; code++)
    {
        Ser_SendByte(code);
        Ser_SendByte(0xFFu);
        Ser_SendByte(0xFFu);
        Ser_SendByte((u8)PARAM_CODE_END);
    }
    Ser_SendByte((u8)PROTO_TX_PARAM_END);
}

void Cmd_ParamImportStart(void)
{
    /* 已移除 ASCII 文本 "PARM,READY"：协议统一为二进制，串口不再发 ASCII。 */
}

void Cmd_Init(void)
{
}

void Cmd_Task(void)
{
    (void)Proto_Importing();
    (void)ParamSet_TakeSaved();
}

/* -------------------------------------------------------------------------
 * 以下 Cmd_Send* 曾向串口发 ASCII 文本（EVT,WARN,MODE,FLOW 等）。
 * 协议已统一为二进制（见 关键说明_v10.22/协议与内部接口表.md），
 * 这些 ASCII 输出会污染二进制帧流，全部删除：函数保留为空实现，
 * 调用点不必改动，运行时不再往串口发任何 ASCII 字节。
 * ---------------------------------------------------------------------- */

void Cmd_SendEvt(s16 evt)
{
    (void)evt;
}

void Cmd_SendWarn(const char* tag)
{
    (void)tag;
}

void Cmd_SendWarnU32(const char* tag, u32 v)
{
    (void)tag;
    (void)v;
}

void Cmd_SendMode(const char* tag)
{
    (void)tag;
}

void Cmd_SendFlow(const char* tag)
{
    (void)tag;
}

void Cmd_SendStall(u16 code)
{
    if (code == 0u) return;

    /* 只保留二进制内部错误帧 0x83 + 内部码（65~74），删 ASCII "STALL,xxx"。 */
    Proto_SendIntErr((u8)code);
}

u8 Cmd_Importing(void) { return Proto_Importing(); }
