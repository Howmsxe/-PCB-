#include "Core/Types.h"
#include "Core/Time.h"
#include "Modules/Belt.h"
#include "Modules/Servo.h"
#include "Modules/Params.h"
#include "App/Cmd.h"
#include "App/Flow.h"
#include "App/PowerUp.h"
#include "Core/ProtoRx.h"
#include "Ui/Ui.h"

#define PWR_DELAY_MS        1000u
#define PWR_HOME_STEP_MS     667u

static u8 puRun  = 0;
static u8 puDone = 0;

void PowerUp_BeltsInit(void)
{

    Belt_Init();
}

void PowerUp_ServosInit(void)
{

    Servo_Init();
}

void PowerUp_Init(void)
{
    PowerUp_BeltsInit();
    PowerUp_ServosInit();
    puRun  = 0u;
    puDone = 0u;
}

static u8 PowerUp_WaitMs(u32 ms)
{
    u32 t0 = Time_Now();

    for (;;)
    {
        Proto_Poll();
        if (Flow_PowerUpBeat() != 0u) return 0u;
        if (TIME_ELAPSED(t0, ms)) return 1u;
    }
}

static void PowerUp_End(u8 normal)
{
    UI_HideBootSplash();

    Flow_HomedMark(normal);

    if (normal == 0u)
    {
        Flow_VoidPending();
        Cmd_SendWarn("PSABORT");
    }
    puRun  = 0u;
    puDone = 1u;
    Proto_Enable();

}

void PowerUp_Run(void)
{
    static const u8 order[3] = { SRV_TRAY, SRV_ARM2, SRV_ARM1 };
    u8 i;

    puRun = 1u;
    UI_ShowBootSplash();

    if (PowerUp_WaitMs(PWR_DELAY_MS) == 0u) { PowerUp_End(0u); return; }
    for (i = 0u; i < 3u; i++)
    {
        Servo_SetImmediate(order[i], gParam.pos[POS_INIT][order[i]]);
        if (PowerUp_WaitMs(PWR_HOME_STEP_MS) == 0u) { PowerUp_End(0u); return; }
    }
    Cmd_SendEvt(1);

    PowerUp_End(1u);
}

u8 PowerUp_Busy(void) { return puRun; }
u8 PowerUp_Done(void) { return puDone; }
