#ifndef __APP_POWERUP_H
#define __APP_POWERUP_H

#include "Core/Types.h"

void PowerUp_BeltsInit(void);
void PowerUp_ServosInit(void);
void PowerUp_Init(void);

void PowerUp_Run(void);
u8   PowerUp_Busy(void);
u8   PowerUp_Done(void);

#endif
