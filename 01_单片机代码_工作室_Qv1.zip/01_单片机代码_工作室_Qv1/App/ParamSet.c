#include "Core/Types.h"
#include "Core/Time.h"
#include "Modules/Params.h"
#include "Modules/Belt.h"
#include "Modules/Servo.h"
#include "App/Flow.h"
#include "App/PowerUp.h"
#include "App/Cmd.h"
#include "App/ParamSet.h"
#include "Ui/Ui.h"

#define PS_FORCE_MS  2000u
#define PS_WARN_MS   3000u
#define PS_HINT_MS   1500u

static u8  s_commit = 0;
static u8  s_save   = 0;
static u8  s_reset  = 0;
static u32 s_reqT   = 0;
static u32 s_holdT  = 0;
static u32 s_warnT  = 0;
static u8  s_saved  = 0;

static u8  s_uiWait = 0;
static u8  s_uiDone = 0;
static u32 s_uiT    = 0;

static u8 PS_MachineIdle(void)
{
    return (u8)((!Flow_Running() && !Flow_TestActive() && !Flow_HomeActive()) ? 1u : 0u);
}

u8 ParamSet_TakeSaved(void)     { u8 v = s_saved;     s_saved     = 0u; return v; }

static void PS_UiBegin(void)
{
    s_uiWait = 1u;
    s_uiDone = 0u;
}

static void PS_UiEnd(u8 ok)
{
    s_uiWait = 0u;
    if (ok != 0u)
    {
        s_uiDone = 1u;
        s_uiT    = Time_Now();
    }
    else
    {
        s_uiDone = 0u;
    }
}

u8 ParamSet_SaveHint(void)
{
    if (s_uiWait != 0u) return 1u;
    if (s_uiDone == 0u) return 0u;
    if (TIME_ELAPSED(s_uiT, PS_HINT_MS))
    {
        s_uiDone = 0u;
        return 0u;
    }
    return 2u;
}

void ParamSet_Init(void)
{
    s_commit = 0;
    s_save   = 0;
    s_reset  = 0;
    s_reqT   = 0;
    s_holdT  = 0;
    s_warnT  = 0;
    s_saved  = 0;
    s_uiWait = 0;
    s_uiDone = 0;
    s_uiT    = 0;
    Params_DraftSync();
}

static void PS_Touch(void)
{
    if (s_reqT == 0u)
    {
        s_reqT  = Time_Now();
        s_holdT = s_reqT;
        s_warnT = s_reqT;
    }
}

void ParamSet_ReqCommit(void)     { PS_Touch(); s_commit = 1u; }
void ParamSet_ReqSave(void)       { PS_Touch(); s_commit = 1u; s_save = 1u; }

u8 ParamSet_SafePoint(void)
{
    if (PowerUp_Busy())    return 0u;
    if (Flow_HomeActive()) return 0u;

    if (UI_IsLiveDebug())  return 0u;
    if (Servo_AnyBusy())   return 0u;
    return 1u;
}

static void PS_Waiting(void)
{
    if (s_reqT == 0u)
    {
        PS_Touch();
        return;
    }
    if (!TIME_ELAPSED(s_warnT, PS_WARN_MS)) return;

    s_warnT = Time_Now();
    Cmd_SendWarnU32("PSWAIT", (u32)(s_warnT - s_holdT) / 1000u);
}

static u8 ParamSet_FlashSafe(void)
{
    if (!ParamSet_SafePoint()) return 0u;

    if (Cmd_Importing())       return 0u;
    if (Belt_IsRunning(BELT1)) return 0u;
    if (Belt_IsRunning(BELT2)) return 0u;
    return 1u;
}

void ParamSet_Task(void)
{
    u8 safe;
    u8 fsafe;


    if (UI_ConsumeSaveParam() != 0u) { PS_Touch(); PS_UiBegin(); s_commit = 1u; s_save = 1u; }
    if (UI_ConsumeReset()     != 0u) { PS_Touch(); PS_UiBegin(); s_reset  = 1u; }

    if (s_commit == 0u && s_save == 0u && s_reset == 0u) return;

    safe  = ParamSet_SafePoint();
    fsafe = ParamSet_FlashSafe();

    if (s_reset != 0u)
    {
        if (!fsafe)
        {
            PS_Waiting();
            if (safe && PS_MachineIdle() && TIME_ELAPSED(s_reqT, PS_FORCE_MS))
            {
                Belt_StopAll();
                s_reqT = Time_Now();
            }
            return;
        }
        s_reset  = 0u;
        s_commit = 0u;
        s_save   = 0u;

        if (Params_ResetDefault() != 0u)
        {
            s_saved = 1u;
            PS_UiEnd(1u);
        }
        else
        {
            PS_UiEnd(0u);
        }
        s_reqT  = 0u;
        s_holdT = 0u;
        s_warnT = 0u;
        return;
    }

    if (!safe) { PS_Waiting(); return; }

    if (s_commit != 0u)
    {
        s_commit = 0u;
        (void)Params_CommitDraft();
    }

    if (s_save != 0u)
    {
        if (!fsafe)
        {
            PS_Waiting();
            if (safe && PS_MachineIdle() && TIME_ELAPSED(s_reqT, PS_FORCE_MS))
            {
                Belt_StopAll();
                s_reqT = Time_Now();
            }
            return;
        }

        (void)Params_CommitDraft();

        s_save = 0u;

        if (Params_Save() != 0u)
        {
            s_saved = 1u;
            PS_UiEnd(1u);
        }
        else
        {
            PS_UiEnd(0u);
        }
    }

    s_reqT  = 0u;
    s_holdT = 0u;
    s_warnT = 0u;
}
