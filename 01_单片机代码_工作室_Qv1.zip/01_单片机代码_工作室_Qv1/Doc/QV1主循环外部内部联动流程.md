# QV1 主循环 · 外部内部联动流程

> 工程：`工作室_Qv1`｜固件版本：Qv1｜文档版本：2026-10-26
> 本文按**当前代码**逐函数核对编写（行号对应 `App/Flow.c` 与 `Ui/Ui.c`），不是设计稿。

---

## 0 一张全景图

```
外部                       内部                                   外部
────────────────────────────────────────────────────────────────────────
串口启动帧 ──► Flow_IdleService ──► Flow_Start ──► Flow_RunMainNow
                                                      │
                                                      ▼
                                            ┌───────────────────┐
旋钮/按键 ──► Enc_Task ──► UI_Key/UI_Rotate ─►│  Flow_RunMain     │──► 串口 EVT/FLOW/MODE/STALL
上/下光电 ──► EXTI ──► s_rawLevel ───────────►│  (七步 for(;;))   │──► OLED 运行页(冻结)
                                             │                   │──► 带1 PA2 / 带2 PB5 PWM
PCA9685 反馈 ──► Servo_Arrived ─────────────►│                   │──► 舵机 CH0/1/2
                                             └───────────────────┘
```

主循环里**没有一处阻塞延时**：每个等待块都是 `for(;;)` + 心跳 + 三出口。

---

## 1 外部 → 内部：四类输入

### 1.1 串口（上位机）

| 帧 | 字节 | 落点 | 作用 |
|---|---|---|---|
| 启动主循环 | `53 02 5C 0F 0F` | `ProtoRx` → `Flow_Start()`（Flow.c:1410） | 置 `mode=RUN_FLOW`，回 `FLOW,START` + `MODE,PREP` |
| 选箱 | `53 04 5C 0F 0F` + 箱号 | `ProtoRx` → `Flow_SetBox()`（Flow.c:1680 附近） | 在选箱页生效；识别期间到达则暂存 `s_boxPending` |
| 取消 | 对应动作码 | `Flow_Abort()` | 置 `s_cancel=1`，主循环下一拍退出 |

`Flow_Start()` 的四道门（任一不过就回 `FLOW,WAIT` 并置 `startPending` 等下一轮）：
1. `PowerUp_Busy()` —— 上电时序没走完
2. `homeActive` —— 正在归位
3. `s_inMain` —— 已经在主循环里
4. `!Flow_ParamsReady()` —— 参数草稿未落盘

### 1.2 屏 + 旋钮/按键（EC11）

- `Enc_Task()` 在心跳里每 10 ms 跑一次，产事件：`ENC_EV_SHORT=1`（按住 ≥30 ms 松开）、`ENC_EV_LONG=2`（按住 ≥2000 ms）、`DOWN=3`、`UP=4`；旋转单独走 `Enc_TakeRotate()`。
- `UI_Key()` = 取事件，`UI_Rotate()` = 取旋钮增量。
- **选箱页**：旋钮改 `boxSelIdx`，短按确认（`boxSelRes`）。
- **主循环退出**：只认**长按**（`UI_Key()==2`）→ 置 `reqTestExit`。
- 运行页画面冻结后按键仍有效（实测 0.925 ms 响应，见第 7 节）。

### 1.3 光电（NPN 开集，低=有料）

- 引脚 PB1=上、PB0=下，**内部上拉由 `Sensor_Init()` 自己开**（`Bsp_SetMode(..., PDIR_IN_PU)`）。
- 电平变化走 EXTI → `Sensor_IsrEdge()` 更新 `s_rawLevel`（无去抖）。
- 主循环判定全用 `Sensor_RawLevel()`（经 `Qv_RawLow()` 取反）。
- `Sensor_Active()` 是 100 ms 去抖后的逻辑值，只给屏显与诊断用。
- 停带后 `Sensor_ForceIdle()` **一次性**把逻辑值置「无料」，随后由物理值自动调回。

### 1.4 上电与归位

`PowerUp_Run()` 跑完（实测 3006 ms）→ `Flow_IdleService()` 里触发 `Flow_Home()` → `s_homed=1` 才允许进主循环；否则 `Flow_RunMain` 立刻 `Flow_SafeExit` + `WARN,HOMEOVER`。

---

## 2 内部主循环：七步

入口 `Flow_RunMainNow()`（Flow.c:1637）：

```
清 s_cancel / s_err / denseMode，st=FLOW_PREP，s_inMain=1
→ Flow_RunMain()
→ 出错则 Flow_FailStop(s_err,1)（发 STALL）
  否则 Flow_CancelStop()（回主菜单 + 归位）
```

`Flow_RunMain()`（Flow.c:1150）主体：

```c
Sensor_Resync();  Flow_Home();          /* 回中，失败则 HOMEOVER 退出 */
UI_ShowTestExit(0u);                    /* 打开运行页 */
s_cycleKind = QV_KIND_NORMAL;
denseMode   = 0u;
first       = 1u;

for (;;)
{
    if (Flow_Stopped()) break;              /* 出口 1：取消/故障 */

    if (first != 0u) { first = 0u; s_cycleKind = QV_KIND_NORMAL; }   /* 首轮必普通 */
    else             { s_cycleKind = Qv_DenseJudge() ? DENSE : NORMAL; }

    denseMode = (s_cycleKind == DENSE);
    Cmd_SendMode(...);                      /* 本轮进入时上报一帧 */

    if (!Qv_CycleFront()) break;            /* 出口 2：按判定做一轮 */
}
if (s_err == 0 && s_cancel == 0) s_err = ERR_ARM;       /* 兜底 */
```

### 步骤 1 · 带 1 送料 + 步骤 2 · 带 2 下料（`Qv_CycleFront`，Flow.c:725）

```
Flow_Enter(FLOW_FEED)
Flow_Belt(BELT1, 1)       起动
  └ Qv_WaitLow(UP)        上光电连续低 ≥150 ms
  └ Qv_DelayStop(UP)      等「料延迟」(0~500 ms，-1=不延时)
Flow_Belt(BELT1, 0)       停止
Sensor_ForceIdle(UP)      一次性复位
→ Qv_PieceTail()
```

`Qv_PieceTail()`（Flow.c:710）：

```
Flow_Belt(BELT2, 1)       起动
  └ Qv_WaitLow(DOWN)      下光电连续低 ≥150 ms
  └ Qv_DelayStop(DOWN)    等「料延迟」
Flow_Belt(BELT2, 0)       停止
Sensor_ForceIdle(DOWN)
→ Qv_Deposit()            步骤 3、4
→ Qv_DupCheck()           步骤 5
```

### 步骤 3 · 识别 + 步骤 4 · 选箱（`Qv_Deposit`，Flow.c:598）

```
Flow_Enter(FLOW_CLASSIFY)
BeltStop(BELT1);  BeltStop(BELT2)
Flow_GoRecog()            臂1→POS_RECOG, 臂2→POS_RECOG, 料盘→POS_INIT
Cmd_SendEvt(15)           串口: EVT,15
recogValid=1; selectWait=1
if (s_boxPending) boxCmd=s_boxPending   /* 识别期间早到的选箱帧在这消费 */
UI_ShowBoxSelect()
for (;;)                  等选箱：UI_PageBoxStep() + UI_ConsumeBoxSelect() + Flow_SetBox()
UI_HideBoxSelect()
if (box == BOX_CANCEL) return 1        /* 取消：不动作，直接下一轮 */
MoveAngle(ARM1, POS_BOX(box)[ARM1])    /* 臂1 到箱角，之后不回位 */
MoveAngle(ARM2, POS_BOX(box)[ARM2])
MoveAngle(ARM2, POS_PICK[ARM2])        /* 臂2 回取料位 */
```

**料盘全程不动**（主人 2026-10-26 裁定）。

**选箱窗 `s_boxWin`**（主人 2026-10-26 要求「选箱后复位选箱帧」）：

| 时机 | 窗 | 行为 |
|---|---|---|
| `Flow_Enter(FLOW_CLASSIFY)` | 开 | 识别期间到达的帧 → 暂存 `s_boxPending` |
| 选箱页等待 | 开 | 到达的帧 → 直接进 `boxCmd` |
| 选箱完成 / 取消退出 | **关** | `boxCmd`、`s_boxPending` 一起清零 |
| 关窗后（含 4 s 预算期间） | 关 | `Flow_SetBox` 直接 `return 0`，**不缓存** |

关窗是为了防止：上一轮的选箱帧在 4 s 预算期间被收下，下一轮误用箱号。

### 步骤 5 · 多余料 4 s 预算（`Qv_DupCheck`，Flow.c:663）

```
Belt2Start()
rem = 4000;  t0 = now
for (;;)
{
    used = now - t0;  if (used >= rem) break;      /* 预算耗尽 */
    if (下光电低)
    {
        Qv_WaitLow(DOWN)           150 ms 确认
        rem -= (now - t0)          暂停：扣掉已用
        Qv_DelayStop(DOWN)         料延迟（这段带2 仍跑，不计预算）
        BeltStop(BELT2)
        Sensor_ForceIdle(DOWN)
        Qv_Deposit()               走步骤 3、4
        Belt2Start()               续跑
        t0 = now                   重新起算剩余
        if (rem == 0) break;
    }
}
BeltStop(BELT2)
```

### 关于结构的说明：这是**判断循环**

主循环不是「做一轮再判」，而是**每轮进入时先判一次**：

```
第 1 轮：强制普通（不判定）
第 N 轮（N≥2）：Qv_DenseJudge() 决定本轮走普通还是密料 → 再执行
```

因此 `MODE,NORMAL` / `MODE,DENSE` 帧的**帧序 = 轮次进入顺序**，第 N 帧就是第 N 轮的模式。

### 步骤 6 · 密料判定（`Qv_DenseJudge`，Flow.c:740）

```
for (;;)
{
    上光电低 且 连续 ≥150 ms  → 返回 1（DENSE）
    上光电高                  → 返回 0（NORMAL）
}
```

只有这一处决定下一轮走「普通」还是「密料」。

### 步骤 7 · 回环

回 `Qv_CycleFront`。**首轮强制普通**（`s_cycleKind` 初值 `QV_KIND_NORMAL`）。

---

## 3 普通流程 vs 密料流程

两者共用同一套七步，差别只在**步骤 1 起步时上光电是否已压料**：

| | 上光电起步状态 | 步骤 1 行为 |
|---|---|---|
| 普通 | 无料 | 带 1 起动 → 等料 → 检出 → 停带 |
| 密料 | **已有料压着** | 带 1 起动 → 150 ms 即满足 → 停带 |

会有一条「密料轮把下一轮带 1 起步从 判点+13 ms 推到 判点+163 ms」的连锁（因为判定本身要等满 150 ms）。

---

## 4 内部 → 外部：五类输出

| 输出 | 内容 | 时机 |
|---|---|---|
| 串口事件 | `EVT,1` 上电完 / `EVT,15` 识别完成 / `EVT,17` 入箱 | 对应步骤 |
| 串口模式 | `MODE,PREP` 启动 / `MODE,NORMAL` `MODE,DENSE` **每轮一帧** | 步骤 6 之后 |
| 串口故障 | `STALL,<码>`（65=ERR_ARM…74）/ `WARN,<文本>` | 退出或异常 |
| OLED | 运行页冻结（内容变化才刷）/ 选箱页 | 见第 6 节 |
| 执行器 | 带 1 = TIM2_CH3(PA2)、带 2 = TIM3_CH2(PB5)；舵机 PCA9685 CH0/1/2 | 各步骤动作 |

---

## 4.1 带控制：一对变一个

带的「起动 / 停止」是一体两面，合并成**一个**函数（主人 2026-10-26 要求）：

```c
static u8 Flow_Belt(u8 idx, u8 on);   /* idx = BELT1 / BELT2 */
```

| 参数 | 语义 |
|---|---|
| `on = 0` | 停（关通道 + CCR=0 + 待命电平） |
| `on = 1` | 按参数方向起（`gParam.beltDir[idx]`） |

`on` **只有 0 和 1**，没有第三种值，语义唯一——不会因为参数给错而出现意料之外的方向。

反向是**另一个语义**，单独一个入口，没有硬并进来：

```c
static u8 Flow_BeltRev(u8 idx);       /* 反向起；停仍用 Flow_Belt(idx, 0) */
```

原来的 `Flow_Belt2Start()` 只是 `Flow_BeltRun(BELT2)` 的纯别名，已删除，调用处直接用 `Flow_Belt(BELT2, 1)`。
底层 `Flow_BeltRunIdx(idx, dir)` 保留。

| 原入口 | 现在 |
|---|---|
| `Flow_BeltRun(idx)` | `Flow_Belt(idx, 1)` |
| `Flow_BeltStop(idx)` | `Flow_Belt(idx, 0)` |
| `Flow_BeltRunRev(idx)` | `Flow_BeltRev(idx)` |
| `Flow_Belt2Start()` | `Flow_Belt(BELT2, 1)` |

## 5 每个等待块里跑什么（心跳）

任何 `for(;;)` 等待块内部都按这个顺序跑：

```
Flow_BeatThrottled()   每 10 ms 一次 → Flow_Beat():
                          Bsp_WdgFeed()      喂看门狗（内部 100 ms 节流，超时 1 s）
                          Proto_Poll()       收串口 + 半包处理
                          Flow_Service()     Sensor/Servo/UI/Cmd/Enc/ParamSet/看门狗
                          Flow_PollCancel()  取消按键
Sensor_Task()          100 ms 去抖更新 s_lastLevel
Flow_PickStep()        舵机取料序列推进
Flow_Stopped()         三出口之一
```

**关键机器事实**：不跑心跳 = 舵机不动、屏不刷、串口不收、取消按不到。所以每个等待块都强制带心跳。

时间基准：`Time_Now()` 来自 TIM4 的 100 µs 中断，每 10 次 +1 ms —— **1 ms 粒度**，与 10 ms 心跳节拍无关。150 ms / 4 s 判定全用它。

---

## 6 OLED 与 UI（主循环期间）

- 驱动层 `OLED_RF_PAGES = 1`：一次 `OLED_Refresh()` 只推 1 页（128 字节 ≈2300 次软 I2C 写），`UI_Tick` 的 pending 分支每拍补 1 页，一帧摊到 8 拍（80 ms）。
- 运行页 `PageRunTick`：算画面签名（上光电/下光电/带1/带2/运行阶段），**相同就直接返回**（不清屏、不画、不推）。
- 选箱页 `UI_PageBoxStep`：按（选中行/顶行/闪烁相位）算签名，相同不重画。
- 结果：165 s 长跑 OLED 合计写量 **1.32 亿 → 1097 万（-91.7%）**，按键响应 0.925 ms 不变。

---

## 7 三条出口

| 出口 | 触发 | 动作 |
|---|---|---|
| 正常取消 | 长按旋钮（≥2 s）/ 串口取消 | `Flow_CancelStop()`：停带 + 三轴 Hold + 清握手 + `UI_GotoMain()` + `Flow_Home()` |
| 步骤失败 | 起带失败 / 臂超时 / 等料失败 | `Flow_FailStop(s_err,1)`：停带 + `STALL,<码>` |
| 兜底 | 主循环意外退出（`s_err==0 && s_cancel==0`） | 置 `ERR_ARM` 后走 FailStop（**注意：正常中止也会被标成臂故障**，见待办） |

**取消/故障都不会留下转动的带或半空中舵机**：`Flow_SafeExit` 里 `Belt_StopAll()` + 三轴 `Servo_Hold()`。

---

## 8 实测时刻表（`QV1_NNN`，注入式，三件料）

| 事件 | 轮 1 | 轮 2 | 轮 3 |
|---|---|---|---|
| 带 1 起 | 5010.3 | 18634.8 | 33628.0 |
| 上光电有料（去抖后上报） | 8002.7 | 22999.9 | 38000.8 |
| 带 1 停 | 8372.9 | 23370.0 | 38370.9 |
| 带 2 起（下料） | 8372.9 | 23370.0 | 38370.9 |
| 带 2 停（下料） | 10180.0 | 25182.9 | 40180.0 |
| 识别完成 `EVT,15` | — | — | — |
| 选箱帧 → 臂动作 | 13000 收帧 | 28000 收帧 | 43000 收帧 |
| 带 2 预算段 | 14608.9 → 18621.8 | 29605.9 → 33614.9 | 44612.9 → 48625.8 |
| **4 s 窗口实测** | **4012.9** | **4009.1** | **4012.9** |
| 判定 | NORMAL | NORMAL | NORMAL |
| 带 1 起（下一轮） | 18634.8 | 33628.0 | 48638.8（等料） |

延迟反推：上光电 = 注入 +150（检出）+300（料延迟）+20~23 ms（节拍与执行）；下光电 = +150+500+30 ms。

---

## 9 与上位机的最小交互契约

1. **启动**：发 `53 02 5C 0F 0F`；收到 `FLOW,START` + `MODE,PREP` 表示已接单。
2. **每件料**：固件在识别完成时发 `EVT,15`；上位机**此时**发选箱帧 `53 04 5C 0F 0F` + 箱号。
   - 早发也行（识别那 1.5 s 内到达会缓存，不会丢）；晚发就一直等。
3. **每轮判定**：固件发 `MODE,NORMAL` 或 `MODE,DENSE`，**帧序 = 轮序**，可逐轮核对。
4. **异常**：`STALL,<码>` 表示已停机并 Hold 三轴，需人工复位。
5. **取消**：旋钮长按 2 s，或串口取消帧。

---

## 10 待办（不影响流程，但要知道）

1. `Flow_RunMain` 结尾把「正常中止」也标成 `ERR_ARM`，日志里 `STALL,01000001` 分不清是臂真故障还是正常收尾。
2. 取消选箱（`BOX_CANCEL`）路径没有场景覆盖。
3. 完全等不到选箱帧时无超时（符合「等人工操作」，但上位机失联就会一直停）。
4. 刷屏真实耗时仍为推算级（仿真不计 CPU 时间），上板要用示波器量。
