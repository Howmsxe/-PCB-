# 对抗审阅 B：步进 ENA 时序 与 参数安全点

审阅对象（只读，未改任何源码、未运行 Keil/仿真）：

- `Modules/Belt.c` / `Modules/Belt.h`（停车起车时序、TIM4 延时脱机、`Belt_EnaSettled`）
- `App/ParamSet.c`（安全点、请求消费）、`Modules/Params.c`（草稿层）、`App/Cmd.c` 的 `Cmd_EnaLockCheck` 与参数导入/`10.1`/`22`
- 调用方与判据来源：`Ui/Ui.c`、`User/main.c` 任务表、`App/Flow.c`、`App/TestFlow.c`、`App/Seq.c`、`Modules/Servo.c`、`Modules/SerialPort.c`、`Core/Time.c`、`Core/Sched.c`、`Bsp/Bsp.c`
- 设计意图以 `Doc/时序.md` §5/§6、`Doc/架构.md` §6/§7 为准（引用处标行号）

本报告只记录"能让它出错的具体时序反例"：每条给 反例（调用顺序 → 后果）／依据（代码原文 + `文件:行号`）／成立性／修法建议，按严重度排序。

## 结论

**部分反驳。** 两条最像事故的猜想——「`s_enaOffT` 残留把正在跑的带脱机」与「整块提交回滚除 `lastAngle` 外的运行期字段」——**都攻不破**（见「未能反驳的设计点」1/2/11，其中前者给的是不变式证明）；但在两条设计的**接缝**上拿到了可复现反例：ENA 刷新请求在"生效值还没变"时就被消费（**100% 复现，不是概率事件**）、500ms「先锁后脱」窗口可被参数路径提前取消、写 Flash 的 20~40ms 关中断与串口流（尤其参数导入）互踩且丢字节后**不置"本行作废"标志**、`sensEdge=1` 时停带发热被自检漏报；另有一条逻辑瑕疵：`Params_DraftDirty()` 把运行期字段 `lastAngle` 计入差异，使 `Params_DraftSync()` 从上电第一次舵机动作起永久空转。

统计：**致命 0 / 严重 4 / 一般 3 / 建议 3**（其中 3 条的量级或命中率标注"需上板验证"）。

---

## 反例清单

### S1（严重）UI 改「脱机」档：ENA 刷新请求在"生效值还没变"时被消费 → 引脚不跟随（100% 复现）

**反例（调用顺序 → 后果）**

1. 现状：`gParam.sensEdge[0] = 1`（"脱机档=高"），ENA 引脚=高=释放=使能=锁机（现场口径见 `Belt.h:5`）。
2. 操作员：主菜单→传感器→脱机（`Ui.c:733` 进页，`Params_DraftSync()`）→ 选中「上带」短按进编辑态（`Ui.c:767-776`）。
3. 编辑态内**旋转一格**：`OnRotate` 的 `K_ENA` 分支把**草稿**取反并只抬 ENA 刷新请求 —— `ParamSet_ReqEnaRefresh()`，**没有** `ParamSet_ReqCommit()`（`Ui.c:841-849`）。
4. ≤10ms 后 `ParamSet_Task` 跑（`main.c:47` 的 10ms 周期）：`s_commit=0`、`s_reset=0`、`s_save=0`、`s_ena=1` → 安全点满足（不在跑流程/测试/实时调试）→ 跳过提交块 → 执行 s_ena 块：`Belt_EnaApplyIdle(BELT1/2)`。
5. `Belt_EnaApplyIdle` 里 `BeltEnaApply(idx, 0)` 取的电平来自 **`gParam.sensEdge`（生效值，还是旧档 1）**，所以写回引脚的电平与原来**完全一样**；同时 `s_enaOffT[idx] = 0` 被顺带清零。请求就此消费掉。
6. 操作员双击退出编辑（`Ui.c:745-752`）→ `ParamSet_ReqCommit()` → 下一拍 `Params_CommitDraft()` 真正把 `sensEdge[0]` 改成 0（`Params.c:288`）。**但 `s_ena` 已经是 0，不会重抬** → 引脚电平不再跟随。
7. 后果：屏上显示「低」、生效参数=0，而 ENA 引脚仍是**高=锁机**（电机持续吃保持电流发热）；要等**下一次停带**后中断那条延时脱机（`Belt.c:479-489`）才纠正 —— 与 `Belt.c:138-139`（v3.39e 的立法理由："否则现场切完脱机档要等下一次起停带才生效，看不出变化"）想要的效果**恰好相反**。
8. 此时 200ms 周期自检会报 `WARN,ENALOCK`（因为第 5 步已清 `s_enaOffT` → `Belt_EnaSettled()=1`、且影子电平 ≠ 档位，`Cmd.c:709-712`），但系统**不会自愈**；现场表现为"档位改了、屏上变了、串口在报错、电机还在锁机发热"。

**依据**

- `Ui.c:841-849`：`if (k == K_ENA) { ParamSet_ReqEnaRefresh(); }`（只有刷新请求，无提交请求）
- `Ui.c:745-752` / `Ui.c:819-827`：编辑结束（双击/长按）才 `ParamSet_ReqCommit()`
- `ParamSet.c:100-107`、`ParamSet.c:126-142`：`s_ena` 独立于 `s_commit`，且顺序是"先提交块、后 s_ena 块"——两位置同时为 1 时才正确
- `Belt.c:140-146`：`Belt_EnaApplyIdle()` 先 `if (s_running || s_switching) return;`，再 `s_enaOffT[idx]=0; BeltEnaApply(idx, 0);`
- `Belt.c:131` + `Belt.c:105-109`：`BeltEnaApply(enable=0)` 的电平 = `Belt_EnaIdleIsHigh(idx)` = 读 `gParam.sensEdge[idx]`
- `Doc/时序.md:79`：「参数设定不会插进这段时序：改「脱机档」只抬请求位，由 `App/ParamSet.c` 在安全点刷 ENA 电平」；`Doc/架构.md:73`：脱机档刷新 ENA 电平应在"安全点"执行 —— 文档承诺的是"能刷到新档"，实现刷的是旧档

**成立性**：**成立**（纯软件路径，无硬件依赖、无竞态窗口：编辑态旋转 → 下一拍必被消费，`main.c:47` 保证 10ms 内有一次 `ParamSet_Task`）。发热/温升的具体量级需上板验证。

**修法建议**

- 最小改动（与既有串口路径同构）：`Ui.c:848` 处同时抬提交位 —— `ParamSet_ReqEnaRefresh(); ParamSet_ReqCommit();`（串口 `10.1/10.2` 就是这么做的，`Cmd.c:434-435`）。副作用：进入编辑态旋转就会把草稿里其它字段一起提交，与"编辑到一半不流入流程"的初衷有张力。
- 更贴语义的改法：**别让 `s_ena` 在提交之前被消费** —— 在 `ParamSet_Task` 里把 s_ena 块（`ParamSet.c:137-142`）改成"仅当 `s_commit==0` 且 `!Params_DraftDirty()` 时才执行，否则保留到下拍"，或让 `Belt_EnaApplyIdle()` 接收一个显式电平参数（由调用方传草稿档位）。后者与"参数设定只写草稿"的分层一致，且不引入"旋转即提交"。
- 附带：`Belt.c:144` 的 `s_enaOffT[idx]=0` 建议不要无条件下手（见 S2）。

---

### S2（严重）500ms「先锁后脱」窗口可被参数路径提前取消（保持扭矩消失）

**反例（调用顺序 → 后果）**

1. 带 1 正在跑 → `Belt_Stop(0)`：`s_running=0`、PUL 拉高、**ENA 保持使能=锁机**、`s_enaOffT[0] = Time_Now() + 500`（`Belt.c:401-420`）。按设计这 500ms 要靠中断才能在到点时脱机（`Belt.c:479-489`，`Doc/时序.md:74-75`、`Doc/架构.md:96-97`）。
2. 在这 500ms 内发生任一条 ENA 刷新请求：串口 `10.1/10.2`（`Cmd.c:430-437`）、`PARM,END` 导入（`Cmd.c:316-320`）、屏上「初始化」（`ParamSet.c:110-124` 的 `Belt_EnaApplyIdle` 两次调用），或 S1 所述的 UI 改档旋转。
3. 此时**带已停**（`s_running=0 && s_switching=0`）→ 安全点满足 → `Belt_EnaApplyIdle` 不早退 → `s_enaOffT[idx] = 0`（**取消待脱机**）并立即写脱机电平。
4. 后果：停带后**立即脱机**，设计的"500ms 内保持锁机、防溜车"被跳过。对水平传送带影响有限，对带负载/有坡度的机位就是"停车瞬间失去保持扭矩"。

**依据**

- `Belt.c:401-420`（`s_enaOffT[idx] = Time_Now() + BELT_ENA_IDLE_MS;`，`Belt.h:14` 的 500ms）
- `Belt.c:140-146`（`Belt_EnaApplyIdle` 无条件 `s_enaOffT[idx]=0`）
- `ParamSet.c:137-142`（s_ena → 两条带各刷一次）、`ParamSet.c:117-118`（reset 路径直接刷）
- `Cmd.c:434`、`Cmd.c:318`（串口侧触发点）
- `Doc/时序.md:74`「停车瞬间 … **保持使能（高）=锁机** | 停车不动 DIR；500ms 内保持扭矩防溜车」

**成立性**：**成立**（路径与判据确定；"溜车"的实际后果需上板验证——取决于负载与坡度，水平带可忽略）。

**修法建议**：`Belt_EnaApplyIdle()` 里不要清 `s_enaOffT`（或改为"仅当 `s_enaOffT==0 || 已到点` 时才清"）。清它没有任何好处——中断到点后会按**当时的**档位写脱机电平，与立即刷新的最终电平一致，但保留待脱机时刻才能守住 500ms 窗口。

---

### S3（严重）写 Flash 的 20~40ms 关中断撞上串口流：丢字节且**不置"本行作废"**，导入可静默少键而仍回 `PARM,OK`

**反例（调用顺序 → 后果）**

1. 先有一个**被挂起**的写盘请求：例如带在跑时按了屏上「保存参数」（`Ui.c:785` → `ParamSet.c:97`）或串口 `22`（`Cmd.c:472-477`）→ `s_save=1` 一直被 `ParamSet_FlashSafe()` 挡着（`ParamSet.c:144-151`）。
2. 操作员/上位机紧接着开始参数导入：`21` 进入导入态（`Cmd.c:457-466`），随后连续发 `PARM,...` 行（`Cmd.c:333-371`）。**导入态不在安全点判据里**（`ParamSet.c:55-72` 没有 `paramImport` 这一项）。
3. 期间带停了 → 安全点成立 → 挂起的 `Params_Save()` 在**导入流中途**执行：`__disable_irq()` 后擦写 20~40ms（`Params.c:136-146`）。
4. 后果一（丢字节）：USART1 一个字节 87µs（`SerialPort.c:176-177`），接收环只有 128 字节 ≈ 11ms 的吞吐（`SerialPort.c:20-25`），其余字节在 `Ser_IsrRx` 里被丢——**但只加计数，不置任何"本行作废"标志**（`SerialPort.c:35-44`）。
5. 后果二（半行残片被当命令）：`s_lineDrop` 只在"单行超长"分支置位（`SerialPort.c:86-90`），环满丢字节这条路径**不置位**；于是 `Ser_GetLine` 会把断口两端的残片拼成一行交上去（`SerialPort.c:55-93`）。
6. 后果三（静默的错误配置）：导入侧只写"收到的键"（`Cmd.c:288-311`），丢行 = 该键不入草稿，而 `ParamImportEnd` 照旧回 `PARM,OK`（`Cmd.c:316-323`）→ 上位机与操作员都无法察觉"某几项没导进去"（例如带速仍是旧值/默认值）。残片若带逗号会被当非法序号帧拒绝（`Cmd.c:630-634`），但**无逗号的行会落到旧帧执行体**（`Cmd.c:636-640`）——即残片有被当命令执行的可能。
7. 同一机制也解释了文件头承诺的落空：`SerialPort.c:9-10` 声称"溢出（环满/单行超长）按『整行作废 + 计数』处理，绝不把半行残片当命令交上去"——**环满这条路径并没有实现**。

**依据**

- `SerialPort.c:9-10`、`SerialPort.c:33-44`、`SerialPort.c:55-94`
- `Params.c:136-146`（`pm=__get_PRIMASK(); __disable_irq(); FLASH_Unlock(); FLASH_ErasePage(); …`）
- `ParamSet.c:55-72`（安全点/写盘安全点里没有"正在参数导入"这一项）、`ParamSet.c:144-151`
- `Cmd.c:457-466`、`Cmd.c:333-371`、`Cmd.c:316-323`、`Cmd.c:630-640`
- `Doc/时序.md:95`「`Params_Save()` 关中断后擦写约 20~40ms，CPU 取指被拉停」——文档承认了这个窗口，但没盘串口侧的后果

**成立性**：**成立**（机制确定：关中断 + 单字节硬件缓冲 + 环满丢字节不标记）。具体丢多少字节、残片是否恰好错位成一条合法旧帧命令，**需上板/上位机复现确认**。

**修法建议**

- 让 `Ser_IsrRx` 的环满分支置一个 `volatile u8` 的"丢包"标志，由 `Ser_GetLine` 与超长路径合并处理：`s_lineDrop=1` —— 半行残片绝不交上层（这是文件自己承诺的语义）。
- 把导入态纳入互斥：给 `Cmd.c` 加 `u8 Cmd_Importing(void)`（返回 `paramImport`），`ParamSet_FlashSafe()`（`ParamSet.c:66-72`）增加 `if (Cmd_Importing()) return 0u;` —— 写盘推迟到导入结束，代价最小。
- 可选：串口侧对"本次写盘前后 50ms 内的接收"记一次 `Ser_DropCount()` 增量并上报（例如 `WARN,RXDROP`），让上位机知道自己该重发。

---

### S4（严重）「脱机」档=1 时，停带后的"该脱机却锁机（发热）"被自检漏报

**反例（调用顺序 → 后果）**

1. 现场把「脱机」档设成"高"（`gParam.sensEdge=1`，`Params.c:199` 明确允许 0/1）。
2. 跑带：`BeltEnaApply(enable=1)` 写 `!idle = 0 = 导通 = 脱机` → **脉冲照发、电机不转**；此时自检情况①能报 `WARN,ENALOCK`（`Cmd.c:705-708`）。
3. 停带：`Belt_Stop` 不写 ENA（`Belt.c:409-419`），500ms 后中断按档位写"高"（`Belt.c:486`）= 释放 = **使能 = 持续吃保持电流发热**。
4. 此时自检走情况②：`Belt_EnaLevel(i)`（=1）与 `Belt_EnaIdleIsHigh(i)`（=1）**相等** → `bad=0` → **不报**（`Cmd.c:709-712`）。也就是说：跑带时报警、**停带发热时反而静默**，与 `Doc/架构.md:100-102` 声称的"双向自检"不符（②的判据是"电平与档位自洽"，不是"已脱机"）。
5. 后果：现场"该脱机却锁机"（v3.42 的原始事故形态）在停机状态下无告警、无自愈，电机长期通电发热。

**依据**

- `Cmd.c:709-712`：`else if (Belt_EnaSettled(i)) { if (Belt_EnaLevel(i) != Belt_EnaIdleIsHigh(i)) bad = 1; }`
- `Belt.c:105-109`、`Belt.c:131`、`Belt.c:479-489`、`Belt.h:5`、`Params.c:199`
- `Doc/架构.md:100-102`（自检②的定义）、`Doc/时序.md:78`

**成立性**：**成立**（纯逻辑；温升量级需上板验证）。

**修法建议**：情况②的期望值不要取"档位自己"。把"停稳后必须是脱机物理电平"写成常量判据（本机现场口径：低=导通=脱机 → `Belt_EnaLevel(i) != 0` 即报），并把 `sensEdge==1` 视为**档位异常**单独上报（不再需要"跑带"作为前提）。这样既保留档位配置的自由，又能覆盖停机发热。

---

### S5（一般）安全点漏掉"实时调试退出后的舵机回位"（`liveDebug` 已 0、Seq 空闲、三轴仍在走）

**反例（调用顺序 → 后果）**

1. 屏上进「舵机→初始」页，按「实时调试」：`LiveStart()` 置 `liveDebug=1`、`ldRunning=1`，三轴开始"去目标"（`Ui.c:352-371`）。
2. 再按一次「实时调试」：`LiveStop()` 先把 `liveDebug=0`（`Ui.c:378`），再置 `ldRunning=1` 启动"回初始"序列（`Ui.c:380-387`，实测 `LIVE_FLOW_SPEED=60`°/s，三轴依次最长约 4.5s）。
3. 这三轴回位是由 `Servo_Task` 自主插值驱动的（`Servo.c:296-350`），**不占 Seq、不占 Flow、`UI_IsLiveDebug()` 已为 0** → `ParamSet_SafePoint()` 五项全过（`ParamSet.c:55-72`）、`ParamSet_FlashSafe()` 也过（带是停的）→ 此时任何一个挂起的提交/写盘都会执行。
4. 后果：设计声称的安全点语义"参数是流程循环的输入，改在动作块中途会让『一段动作两种速度』"（`ParamSet.c:53`）在这里不成立——参数可以在**舵机正在动**的时候生效；同时 `Params_Save()` 的 20~40ms 关中断会让 `Servo_Task` 的一次插值迟到约 40ms。
5. 危害有限的原因也要写清：`Servo_Task` 是按**真实 dt** 积分且有 200ms 上限（`Servo.c:308-313`），不会丢角度、不会猛冲；实时调试序列读的是**草稿**（`Ui.c:433`、`Ui.c:345`），所以提交本身不会改变正在执行的动作目标。**这条的价值在于"安全点的判据不完整"，而不在于当前后果。**

**依据**：`Ui.c:373-392`、`Servo.c:296-350`、`ParamSet.c:53-72`、`Doc/架构.md:76`（安全点定义只有五项）。

**成立性**：**成立**（判据缺口确定）；关中断造成的一次插值延迟 ≤40ms，实机是否可感知需上板验证。

**修法建议**：`ParamSet_SafePoint()` 增加一条"没有舵机在动"的只读判据——`Servo.c` 已有现成的 `Servo_AnyBusy()`（`Servo.c:276-285`，判据是角度差而不是 busy 位）。加 `if (Servo_AnyBusy()) return 0u;` 即可；若担心"实时调试改值跟随"被自己挡住，可仅在写 Flash 的 `ParamSet_FlashSafe()` 里加（提交可以放宽，写盘不该放宽）。

---

### S6（一般）`Params_DraftDirty()` 把运行期字段 `lastAngle` 计入差异 → `Params_DraftSync()` 永久空转

**反例（调用顺序 → 后果）**

1. 上电后任何一次舵机动作（含上电回正 `SEQ_POWERUP`，`PowerUp.c:15-23`）→ `ParamSet_Task` 每拍把三轴当前角度写进**生效值** `gParam.lastAngle[]`（`ParamSet.c:92-94` → `Params.c:295-301`）。
2. 草稿里的 `lastAngle` 只在同步/丢弃/提交时更新（`Params.c:262`、`Params.c:268`、`Params.c:284`）→ 于是在第一次舵机动作之后，草稿与生效值在 `lastAngle` 上**永久不同**。
3. `Params_DraftDirty()` 从字节 4 一路比到 95（`Params.c:230-241`），`lastAngle` 在偏移 90..95（`Params.h:57`、`Params.c:43` 的偏移断言）→ **恒为 1**。
4. 后果：`Params_DraftSync()`（`Params.c:258-264`）从此永远提前返回，"进入参数页先把生效值同步到草稿"这条保护（`Ui.c:721/722/727/732/733/734` 六处调用）**全部作废**。
5. 附带证据（同一判据的第二个受害者）：上电首次调用时草稿还是 BSS 全 0、`s_draftInit=0`，Dirty 必然为 1 → `Params_Load()` 里的 `Params_DraftSync()`（`Params.c:117`）与 `ParamSet_Init()` 里的那次（`ParamSet.c:39`）**同样是空转**，只因为 `Params_Draft()` 有懒初始化兜底（`Params.c:243-251`）才没出事故；也正因为如此，`Params_CommitDraft()` 在 `s_draftInit==0` 时返回 0 而调用方已经把 `s_commit` 清掉（`ParamSet.c:131-132`）这条"静默吞一次提交"的路径目前无害。
6. 与文档的落差：`Doc/架构.md:83` 明说"`Params_CommitDraft()` 提交时保留 `lastAngle`（运行期状态不回滚）"——作者知道它是运行期字段，但**同一个字段在 dirty 判据里没有同样处理**。当前后果只是"保护失效"；一旦将来有人往 `gParam` 加一个运行期写点，下一次提交就会把那一点静默回滚（这正是本工程一直在防的"两处漂移"形态）。

**依据**：`Params.c:230-241`、`Params.c:253-256`、`Params.c:258-264`、`Params.c:282-290`、`Params.h:57`、`ParamSet.c:92-94`、`Ui.c:721-734`、`Doc/架构.md:83`。

**成立性**：**成立**（纯代码逻辑，无需上板）。

**修法建议**：把 `Params_Same()` 的比较范围改成"跳过 magic/ver（0..3）**与 lastAngle（90..95）**"，或让 `Params_DraftDirty()` 单独用一份"只比可提交字段"的比较函数；改完后 `Params.c:282-284` 那段 `lastAngle` 特判可以保留（无害）也可以删。

---

### S7（一般）「保存参数」在带运行期间静默挂起：无回执、无提示，串口 `22` 还先回 `save ok`

**反例（调用顺序 → 后果）**

1. 进入「步进常动测试」（`TestFlow.c:98-105`：表起带后立即结束，带一直跑、`testActive=1`）或实时调试带组（`Ui.c:342-346`：带在跑、`liveDebug=1`）。
2. 按串口 `22` 或屏上「保存参数」：`ParamSet_ReqSave()` / `reqSaveParam`（`Cmd.c:472-477`、`Ui.c:785`）。
3. `ParamSet_Task` 消费后 `s_commit=s_save=1`，但安全点/写盘安全点不满足 → `s_state=PS_WAIT; return;`（`ParamSet.c:144-151`），**请求位不清（这点是对的）**，可是**没有任何对外反馈**：串口侧在抬位时就已经回了 `save ok`（`Cmd.c:475`，与实际落盘时机无关）；屏上也没有"等待停带"提示。
4. 诊断接口形同虚设：`ParamSet_Pending()/State()/StateName()/Count()/LastWasSave()` 只有定义、**全工程无调用者**（`ParamSet.h:29-34`、`ParamSet.c:47-83`；跨 App/Ui/User/Modules 检索无命中）。
5. 后果：操作员以为已保存，若此时断电则参数丢失（尤其"步进常动测试里刚标定完的值"）。带停后请求会被兑现，所以这是"延迟"而非"丢弃"——但对人来说是**不可见的延迟**。

**依据**：`Cmd.c:472-477`、`Ui.c:785`、`ParamSet.c:97`、`ParamSet.c:144-151`、`ParamSet.h:29-34`、`TestFlow.c:98-105`、`Ui.c:342-346`、`Doc/架构.md:79`（"请求不丢"只保证了不清位，没有保证"有回执"）。

**成立性**：**成立**（"无声挂起"确定；是否真丢参数取决于断电时机）。

**修法建议**：①串口 `22` 的回执改为按状态作答（`save wait` → 落盘后补一帧 `SAVE,OK`），或至少在 `PS_WAIT` 持续超过 N 秒时发 `WARN,SAVEWAIT`；②屏上在 `s_state==PS_WAIT && s_save` 时显示"等待停带"；③把 `ParamSet_State()/Pending()` 接进 `8` 查询帧（`Cmd.c:410-414`）。

---

### S8（建议）中断读 `gParam.sensEdge` 与"开中断的整块提交"无同步（撕裂视图）

**反例（调用顺序 → 后果）**：停带后 500ms 到点的那一拍，恰好撞上一次 `Params_CommitDraft()` → 中断在 96 字节拷贝的中途读 `gParam.sensEdge[i]`（`Belt.c:486` → `Belt.c:105-109`）→ 可能只看到"上带已新档、下带还是旧档"（`sensEdge[0]` 在字 20、`sensEdge[1]` 在字 21，`Params.c:43` 的偏移断言保证 16 位字段不跨字）→ 一条带按旧极性脱机，与生效参数不符，且要等下一次停带才纠正。

**依据**：`Belt.c:486`、`Belt.c:105-109`、`Params.c:272-290`（`gParam = s_draft;` 全程**没有** `__disable_irq`，对比 `Belt.c:335-336` 的做法）。

**成立性**：机制**成立**，命中率极低（需"提交"与"某条带 500ms 脱机判定"落在同一百微秒内）→ **需上板验证**（或按"概率可忽略、但应按本文件自身的中断缓存规范修掉"处理）。

**修法建议**：与 `Belt.c:39-47` 的既有规范一致——在 `Belt_Init`/`ParamSet` 的**非中断**路径把两条带的脱机电平缓存成 `s_enaIdleLv[BELT_NUM]`（参数变更时更新），中断只读缓存；或最小改动：`ParamSet_Task` 调用 `Params_CommitDraft()` 的整段加临界区（`pm=__get_PRIMASK(); __disable_irq(); … __set_PRIMASK(pm);`，与 `Belt_Run` 同式）。

---

### S9（建议）写 Flash 期间 TIM3 丢拍，`Time_Now()` 是**变慢**而不是注释说的"跳过去"

**反例（调用顺序 → 后果）**：`Params_Save()` 关中断 20~40ms（`Params.c:136-146`）→ TIM3 的更新标志是"置位型"，这期间只会补 **1** 个 tick → `s_ms` 相对真实时间**落后**约 30~40ms（`Time.c:66-76`），而不是"跳过去"。于是所有 `TIME_ELAPSED`/`TIME_DUE` 判据（含 500ms 脱机窗口、`BELT_WATCHDOG_MS=60000`、在途 OK 的 15s 兜底）都被整体拉长同样的量，且每次写盘累加。

**依据**：`Params.c:16-17`（注释"1ms 时基会丢约 30ms（`Time_Now` 直接跳过去）"）、`Time.c:61-76`、`Sched.c:152-162`（落后一整拍只重新对表、不补跑，故不会突发连跑）。

**成立性**：机制**成立**；擦写实测时长与可观测影响**需上板验证**（量级 ≤40ms/次，业务上无害）。

**修法建议**：只改注释与文档（把"跳过去"改成"落后"），并在 `Doc/时序.md` §6 登记"每次写盘时基落后 ≤40ms"；不建议在 `Params_Save()` 里手工补 `s_ms`（会破坏"1ms 时基 = 中断计数"的单一真源）。

---

### S10（建议）`Belt_EnaLevel()/Belt_Level()` 是"我们写了什么"（ODR），不是引脚真实电平 → 自检与诊断看不到外部把线拉偏/接错

**反例（调用顺序 → 后果）**：ENA 线接反/驱动器 ENA 输入把开漏线拉低 → 代码影子=1（以为锁机）、引脚实际=0（真脱机）→ `Cmd_EnaLockCheck` 判"正常不报"（`Cmd.c:709-712`）；`BeltSyncLevel()` 想做的"回读引脚真实电平"（`Belt.c:96-100`、`Belt.c:61-65` 的 W09 注释）在 v4 里实际上读的是 ODR，**是恒等操作**。

**依据**：`Bsp.c:171-188`（输出脚走 `GPIO_ReadOutputDataBit`，且 `Bsp.c:181-182` 自认"输出脚的外部真实电平不再能从 `Bsp_Read` 拿到，将来需要请加 `Bsp_ReadPin()`"）、`Belt.c:96-100`、`Belt.c:61-65`、`Cmd.c:709-712`。

**成立性**：机制**成立**；"外部能否真的把开漏线拉偏"**需上板验证**（示波器/万用表量 ENA 空闲电平）。

**修法建议**：按 `Bsp.c:181-182` 的预留，加 `Bsp_ReadPin()`（读 IDR）并让 `Belt_EnaLevel()` 走它（或加一个诊断版 `Belt_EnaPinLevel()`）；`Cmd_EnaLockCheck` 增加"影子 vs IDR 不一致"的独立告警。这样自检才同时覆盖"档位错"和"线接错"。

---

## 未能反驳的设计点

以下是我尽力找反例、但没能攻破的部分（含给结论的证据，供交叉验证）。

1. **`s_enaOffT` 不会残留把正在跑的带脱机。** 现场担心的 `Belt_StopAll()` 紧跟 `Belt_Run()`、"停1起2"（`Flow.c:449-453`、`TestFlow.c:118-126`）都不成立，理由是不变式：**`s_running==1 或 s_switching==1 ⇒ s_enaOffT==0`**。枚举 `s_enaOffT` 的全部写点——`Belt.c:144`（EnaApplyIdle→0）、`Belt.c:267`（Init→0）、`Belt.c:365`（换向取消，紧接着 `s_running=1`）、`Belt.c:395`（正常起带，紧接着 `s_running=1`）、`Belt.c:418`（Stop：置 500ms，同时 `s_running=0/s_switching=0`）、`Belt.c:484`（中断脱机→0）；而 `s_running=1` 只能来自 366/396（前置清 0）与中断分支一 `Belt.c:474`（其前提 `s_switching=1` 只能来自 `Belt.c:342-350`，而那条路径要求 `s_running=1`）。⇒ 残留值不可能与 `s_running` 同时为真。**注意此不变式的前提是"所有写点都在临界区内"**（`Belt.c:335-336/407-408` 确实如此）。
2. **中断"延时脱机"与 `Belt_Run` 的竞态窗口不存在。** `Belt_Run` 全程 `__disable_irq()`（`Belt.c:335-336`、出口 `__set_PRIMASK`），中断分支二另有双闸 `!s_running && !s_switching`（`Belt.c:481`）；`s_enaOffT` 是对齐 u32，单条 STR/LDR，无撕裂写。"刚起带就被脱机"需要"标志非 0 且两闸全开"，而这与第 1 条的不变式矛盾。
3. **停车瞬间 `BeltPulWrite(idx,1)` 不是 W09 那种伪脉冲。** 它只是把中断留下的**半个周期补完**（半周期 100µs~2.36ms，取决于档位与速度，`Belt.c:226-231`），最多 ±1 步（800 步/圈、周长 7.54cm ≈ 0.009mm 量级）；它**不可能**造出"窄脉冲"——那是恒定电平，不是一次翻转对。W09 的教训是"影子硬写 0 → 首拍空翻、边沿数=翻转数−1"（`Belt.c:63-64`），v4 的对应处理是 `BeltSyncLevel()` 回填 + 换向重启前 `BELT_PUL_SET`（`Belt.c:472`），已覆盖。需上板确认驱动器按上升沿还是下降沿计步——两种口径下误差都 ≤1 步。
4. **两条带的延时脱机互不串扰。** 中断分支二逐带索引判定与写脚（`Belt.c:479-489` 的 `i` 与 `BELT_ENA_HOT(i,…)`），带 1 的待脱机不会拖住带 2；`Belt_EnaSettled()/Belt_EnaLevel()` 也都是按索引取影子（`Belt.c:122-126`、`Belt.c:440-444`）。
5. **`Belt_EnaSettled()` 在"从没起过带"时不误报。** 上电 `Belt_Init` 已按档位落脱机电平、并清 `s_enaOffT`（`Belt.c:261-268`），且 `Params_Load()`（`main.c:74`）在 `PowerUp_Init()→Belt_Init()`（`main.c:85`）之前 → 档位已是 Flash 值 ⇒ 自检判据②在静止态自洽，不报。
6. **换向缓冲（`s_switching=1`）让自检少判 200ms 不算缺陷。** `Belt_EnaSettled()` 把 switching 排除（`Belt.c:125`），这段窗口恰好是"设计要求保持使能"的换向停顿（`BELT_DIR_SWITCH_MS=200`，`Belt.h:17`）。
7. **换向完成重启时没重写 ENA，不是漏写。** `s_switching=1` ⇒ 唯一来源 `Belt.c:342-350`（要求 `s_running==1`）⇒ ENA 必在使能电平；期间也没有其它 ENA 写者（`Belt_EnaApplyIdle` 在 switching 时直接 return，`Belt.c:143`；中断脱机分支要求 `!switching`，`Belt.c:481`）。
8. **安全点没漏 `ldRunning==2`（带组待启动）与 `homeActive`（测试退出回正）。** 前者：`LiveStart()` 在置 `ldRunning=2` 的同一个函数里已经置了 `liveDebug=1`（`Ui.c:352-371`），而安全点查 `UI_IsLiveDebug()`（`ParamSet.c:61`）；后者：`Flow_Home()` 先 `Seq_Start(&SEQ_HOME)`（`Flow.c:740`）→ `Seq_Busy()` 挡住，`homeActive` 只在 Seq 空闲的那一拍被清（`Flow.c:844-852`），且任务表里 Flow 在 Param 之前（`main.c:43` vs `main.c:47`）。（真正漏掉的是"实时调试退出后的舵机回位"，已单列 S5。）
9. **带在跑时不会写 Flash。** `ParamSet_FlashSafe()` 查两条带（`ParamSet.c:66-72`），`Belt_IsRunning()` 把换向缓冲也算在用（`Belt.c:428-432`）；同一拍内可能起带的四个任务（Seq/Flow/Ui/Cmd）都排在 Param 之前（`main.c:41-47`），中断也不能凭空起带（`Belt.c:466-475` 只在 switching 时重启，而 switching 已计入 `IsRunning`）⇒ 判定与擦写之间没有可插入的执行体。
10. **"步进常动测试里手动起带绕过安全点"不成立。** 该模式的带由测试态维持（`TestFlow.c:98-105`、`Flow.c:615/639`），`Flow_TestActive()` 为 1 挡提交（`Flow.c:919-920/938-941`），写盘另由 `Belt_IsRunning()` 挡（`ParamSet.c:69-70`）。
11. **整块提交不会回滚 `lastAngle` 之外的运行期字段（逐字段核对）。** 全工程（App/Ui/User/Modules/Core/Bsp，排除 `_legacy`）对 `gParam` 的写点只有四处：`Params.c:130-131`（Save 写 magic/ver）、`Params.c:288`（提交）、`Params.c:300`（`lastAngle`）、`Params.c:184-185`（`Params_ClampAll` 就地钳位）。逐字段看：`magic/ver` 由提交方维护且在比较中被跳过（`Params.c:236` 从字节 4 起）；`lastAngle` 已特判（`Params.c:282-284`）；`rsvd/P_CMASS_MS`、`pos[9][3]`、`runSpeed`、`debugSpeed`、`beltSpeed[2]`、`beltDir[2]`、`sensDelay[2]`、`sensEdge[2]`、`sensOutMode[2]` 的写点全在草稿侧（`Ui.c:243-265` 的 `CurVal`→`D()`、`Cmd.c:293-311` 的导入、`Params.c:52-84` 的默认值）与默认值填充；唯一被读取者是流程循环（`Blocks.c:153-158`、`Flow.c:449`、`Belt.c:108`、`Sensor.c:49`）。`sensMode[2]` 是"仅保留兼容、不参与判定"（`Params.h:56`、`Sensor.c:109`），回滚它无后果。⇒ 除 `lastAngle` 外没有可回滚对象（`lastAngle` 本身也没被回滚，问题在 dirty 判据，见 S6）。
12. **UI 请求位与 `ParamSet_Task` 的消费没有"丢请求/重复执行"。** 单一消费者（全工程只有 `ParamSet.c:97-98` 调 `UI_ConsumeSaveParam/UI_ConsumeReset`）；三处 `return` 都不清 `s_commit/s_save/s_reset`（`ParamSet.c:110-112`、`126`、`147`）；`Params_Save()` 只有在 `s_save` 清零后调用一次，无法重入（`ParamSet.c:148-150`）。`s_reset` 会清掉在途的 `s_commit/s_save`（`ParamSet.c:114-115`），但同一次 reset 自己就写 Flash 并把草稿一起回默认（`Params.c:152-157`）⇒ 后果只是"保存被初始化合并"，不构成丢请求。真正"消失"的只有 S1/S2 描述的 `s_ena` 提前消费。
13. **`Cmd_EnaLockCheck` 情况①的判据与实现一致**（`Cmd.c:705-708` + `Belt.c:114-118` + `Belt.c:428-432`），换向中报"跑带却脱机"是**正确**的（换向后确实要继续跑）。

---

### 附：本报告未覆盖/无法判定的部分

- 本审阅为静态读码 + 调用顺序推演，未运行 Keil、未上板、未跑仿真台；凡标"需上板验证"的量级（温升、溜车、丢字节数、关中断实测时长、开漏线能否被外部拉偏）均需实测确认。
- `Doc/时序.md` §5 的表格用"高=锁机"表述 ENA，`Belt.c:104` 与 `Belt.h:5` 用"释放=使能、导通=脱机"；两套说法在本报告中按物理电平对齐（高=释放=使能=锁机），未发现代码与任何一种说法冲突——除 S1/S2 描述的"刷新时机"问题。
