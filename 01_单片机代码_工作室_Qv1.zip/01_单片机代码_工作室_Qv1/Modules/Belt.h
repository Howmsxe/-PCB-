#ifndef __MOD_BELT_H
#define __MOD_BELT_H

#include "Core/Types.h"

#define BELT_NUM            2
#define BELT1               0
#define BELT2               1
#define BELT_MICROSTEP      4
#define BELT_RAMP_MS        200
#define BELT_DIR_SWITCH_MS  200
#define BELT_SWITCH_TIMEOUT_MS  (3u * BELT_DIR_SWITCH_MS)
#define BELT_STALL_MS       3000u
#define BELT_SPEED_MIN      1
#define BELT_SPEED_MAX      20

#define BELT_LEN_MM         170u

void    Belt_Init(void);

u8      Belt1_Run(u8 cmps);
u8      Belt1_RunDir(u8 cmps, u8 dir);
u8      Belt1_Stop(void);
u8      Belt1_IsRunning(void);
u8      Belt2_Run(u8 cmps);
u8      Belt2_RunDir(u8 cmps, u8 dir);
u8      Belt2_Stop(void);
u8      Belt2_IsRunning(void);

void Motion_Lock(u8 target, u8 unlock);
u8   Motion_BeltLocked(u8 idx);
u8   Motion_ServoLocked(void);
void    Belt_Run(u8 idx, u8 cmPerSec, u8 dir);
void    Belt_Stop(u8 idx);
void    Belt_StopAll(void);
u8      Belt_IsRunning(u8 idx);
u8      Belt_IsSwitching(u8 idx);
u8      Belt_IsBusy(u8 idx);
void    Belt_Watchdog(void);
u8      Belt_EffCmps(u8 idx);
u16     Belt_PulseHzAt(u8 idx, u8 cmPerSec);
u32     Belt_StepCount(u8 idx);
void    Belt_IsrTick(void);

extern volatile u16 g_beltIsrLastUs;
extern volatile u16 g_beltIsrMaxUs;
extern u16          g_beltSwitchTimeout;

STATIC_ASSERT(BELT_MICROSTEP == 4, belt_microstep_matches_tb6600_dip);
#endif
