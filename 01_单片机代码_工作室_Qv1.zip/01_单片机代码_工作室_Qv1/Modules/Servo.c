#include "Core/Types.h"
#include "Core/Time.h"
#include "Modules/Servo.h"
#include "Modules/Params.h"
#include "Modules/Belt.h"
#include "Bsp/Bsp.h"
#include "Delay.h"
#include "Modules/Display/MyI2C.h"
#include "Core/ProtoTx.h"
#include "Core/ErrCode.h"

#define PCA_ADDR        0x40
#define PCA_MODE1       0x00
#define PCA_PRESCALE    0xFE
#define PCA_LED0_ON_L   0x06
#define MODE1_SLEEP     0x10
#define MODE1_AI        0x20
#define MODE1_RESTART   0x80
#define PCA_OSC_FREQ    25000000UL
#define PCA_PSC_MIN     3
#define PCA_PSC_MAX     255

#define SRV_FREQ_HZ     50
#define SRV_PULSE_MID   1500
#define SRV_PULSE_MIN   500
#define SRV_PULSE_MAX   2500
#define SRV_ANGLE_ABS   SERVO_ANGLE_LIMIT

#define SRV_DEAD_180_US    5
#define SRV_DEAD_360_DEG   3
#define SRV_SPAN_360_DEG   357
#define SRV_SPAN180_X100   17955
#define SRV_DB180_BIAS_US  2.5f
#define SRV_DB360_BIAS_DEG 1.5f
#define SRV_SPEED_MAX   180

#define SRV_SPEED_MIN       30
#define SRV_ARRIVE_TOL  1.0f
#define SRV_TASK_MS     10
#define SRV_DT_MAX_MS   200
#define SRV_PCA_OSC_MS   5u
#define SRV_PCA_RESET_MS 10u

#define PCA_FAIL_LIMIT  3u
#define PCA_PSC_RETRY   3u

STATIC_ASSERT(SRV_PULSE_MID == 1500, srv_mid_must_be_1500us);
STATIC_ASSERT(SRV_PULSE_MIN == 500,  srv_low_must_be_500us);
STATIC_ASSERT(SRV_PULSE_MAX == 2500, srv_high_must_be_2500us);
STATIC_ASSERT(SRV_ANGLE_ABS == 90,   srv_180_limit_must_be_90deg);

STATIC_ASSERT(((SRV_PULSE_MID - SRV_PULSE_MIN) * 180) == (SRV_ANGLE_ABS * 2000), srv_180_full_span_2000us);

STATIC_ASSERT(SRV_SPAN180_X100 == (180 * 100 - (SRV_DEAD_180_US * 180 * 100) / 2000), srv_180_span_179_55deg);

STATIC_ASSERT((SRV_SPAN_360_DEG + SRV_DEAD_360_DEG) == 360, srv_360_span_plus_deadband_360);
STATIC_ASSERT((SRV_PULSE_MAX - SRV_PULSE_MIN) == 2000, srv_full_span_must_be_2000us);

static float s_cur[SRV_NUM];
static float s_dst[SRV_NUM];
static u8    s_speed[SRV_NUM];
static u8    s_busy[SRV_NUM];

#define SERVO_PLAN_MAX  240u
#define SERVO_PLAN_TICK 10u
static s16   s_plan[SRV_NUM][SERVO_PLAN_MAX];
static u16   s_planLen[SRV_NUM];
static u16   s_planIdx[SRV_NUM];
static u32   s_planAcc[SRV_NUM];
static u8    s_planWhole[SRV_NUM];
static u16   s_lastCnt[SRV_NUM];
static u8    s_typeSeen[SRV_NUM];

static u8    s_resend[SRV_NUM];

static float s_perStep = 5.0f;
static u8    s_pcaFailRun    = 0;
static u8    s_pcaFailReport = 0;

static u16   s_wrTry[SRV_NUM];
static u16   s_wrOk[SRV_NUM];
static u16   s_rsCnt[SRV_NUM];
static u8    s_freqBad = 0;

static u8 PcaAckBad(void)
{
    return (u8)((MyI2C_ReceiveAck() == 0u) ? 0u : 1u);
}

static void PcaNoteBus(u8 bad)
{
    if (bad == 0u)
    {
        s_pcaFailRun    = 0;
        s_pcaFailReport = 0;
        return;
    }

    if (s_pcaFailRun < 0xFFu) s_pcaFailRun++;
    if ((s_pcaFailRun >= (u8)PCA_FAIL_LIMIT) && (s_pcaFailReport == 0u))
    {
        s_pcaFailReport = 1;
        Proto_SendIntErr((u8)ERR_PCA_FAIL);
    }
}

static void PcaWriteReg(u8 reg, u8 data)
{
    u8 bad = 0;

    MyI2C_BusEnter();
    MyI2C_Start();
    MyI2C_SendByte((u8)(PCA_ADDR << 1));
    bad |= PcaAckBad();
    MyI2C_SendByte(reg);
    bad |= PcaAckBad();
    MyI2C_SendByte(data);
    bad |= PcaAckBad();
    MyI2C_Stop();
    MyI2C_BusLeave();

    PcaNoteBus(bad);
}

static u8 PcaReadReg(u8 reg)
{
    u8 val;
    u8 bad = 0;

    MyI2C_BusEnter();
    MyI2C_Start();
    MyI2C_SendByte((u8)(PCA_ADDR << 1));
    bad |= PcaAckBad();
    MyI2C_SendByte(reg);
    bad |= PcaAckBad();
    MyI2C_Start();
    MyI2C_SendByte((u8)((PCA_ADDR << 1) | 0x01));
    bad |= PcaAckBad();
    val = MyI2C_ReceiveByte();
    MyI2C_SendAck(1);
    MyI2C_Stop();
    MyI2C_BusLeave();

    PcaNoteBus(bad);
    return val;
}

static u8 PcaSetPwm(u8 ch, u16 on, u16 off)
{
    u8 reg = (u8)(PCA_LED0_ON_L + 4 * ch);
    u8 bad = 0;

    MyI2C_BusEnter();
    MyI2C_Start();
    MyI2C_SendByte((u8)(PCA_ADDR << 1));
    bad |= PcaAckBad();
    MyI2C_SendByte(reg);
    bad |= PcaAckBad();
    MyI2C_SendByte((u8)(on & 0xFF));    bad |= PcaAckBad();
    MyI2C_SendByte((u8)(on >> 8));      bad |= PcaAckBad();
    MyI2C_SendByte((u8)(off & 0xFF));   bad |= PcaAckBad();
    MyI2C_SendByte((u8)(off >> 8));     bad |= PcaAckBad();
    MyI2C_Stop();
    MyI2C_BusLeave();

    PcaNoteBus(bad);

    if (ch < (u8)SRV_NUM)
    {
        if (s_wrTry[ch] != 0xFFFFu) s_wrTry[ch]++;
        if ((bad == 0u) && (s_wrOk[ch] != 0xFFFFu)) s_wrOk[ch]++;
    }

    return (u8)((bad == 0u) ? 1u : 0u);
}

static void PcaSetFreq(u16 freq)
{
    u8  oldmode;
    u8  newmode;
    u8  prescale;
    float prescaleval;

    if (freq < 1)    freq = 1;
    if (freq > 3500) freq = 3500;

    prescaleval = ((float)PCA_OSC_FREQ / ((float)freq * 4096.0f) + 0.5f) - 1.0f;
    if (prescaleval < (float)PCA_PSC_MIN) prescaleval = (float)PCA_PSC_MIN;
    if (prescaleval > (float)PCA_PSC_MAX) prescaleval = (float)PCA_PSC_MAX;
    prescale = (u8)prescaleval;

    oldmode = PcaReadReg(PCA_MODE1);

    oldmode &= (u8)(MODE1_AI | MODE1_SLEEP);

    newmode = (u8)((oldmode & (u8)(~MODE1_RESTART)) | MODE1_SLEEP);
    PcaWriteReg(PCA_MODE1, newmode);
    PcaWriteReg(PCA_PRESCALE, prescale);

    {
        u8 k;

        for (k = 0u; k < PCA_PSC_RETRY; k++)
        {
            if (PcaReadReg(PCA_PRESCALE) == prescale) break;
            PcaWriteReg(PCA_PRESCALE, prescale);
        }
        if (PcaReadReg(PCA_PRESCALE) != prescale) s_freqBad = 1u;
    }

    s_perStep = 1000000.0f * (float)(prescale + 1) / (float)PCA_OSC_FREQ;

    oldmode = (u8)(oldmode & (u8)(~MODE1_SLEEP));
    PcaWriteReg(PCA_MODE1, oldmode);
    Delay_ms((u32)SRV_PCA_OSC_MS);
    PcaWriteReg(PCA_MODE1, (u8)(oldmode | MODE1_RESTART | MODE1_AI));
}

static u16 ServoAngleToCount(u8 ch, float ang, s8 dir)
{
    float us;
    float cnt;

    if (ch >= (u8)SRV_NUM) ch = 0u;

    if (gParam.srvType[ch] == (u8)SRV_TYPE_360)
    {
        us = (float)SRV_PULSE_MIN + (ang + 180.0f) * (2000.0f / (float)SRV_SPAN_360_DEG);
        if (dir != 0)
        {

            us += ((float)dir) * (SRV_DB360_BIAS_DEG * (2000.0f / (float)SRV_SPAN_360_DEG));
        }
    }
    else
    {
        us = (float)SRV_PULSE_MID + ang * (2000.0f * 100.0f / (float)SRV_SPAN180_X100);
        if (dir != 0)
        {
            us += ((float)dir) * SRV_DB180_BIAS_US;
        }
    }

    if (us < (float)SRV_PULSE_MIN) us = (float)SRV_PULSE_MIN;
    if (us > (float)SRV_PULSE_MAX) us = (float)SRV_PULSE_MAX;

    cnt = us / s_perStep;

    if (cnt < 0.0f)    cnt = 0.0f;
    if (cnt > 4095.0f) cnt = 4095.0f;
    return (u16)(cnt + 0.5f);
}

static s8 ServoMoveDir(u8 ch)
{
    if (ch >= (u8)SRV_NUM) return 0;
    if (s_cur[ch] > s_dst[ch]) return -1;
    if (s_cur[ch] < s_dst[ch]) return 1;
    return 0;
}

static s16 ServoRound(float ang)
{
    return (s16)(ang + (ang >= 0.0f ? 0.5f : -0.5f));
}

void Servo_Init(void)
{
    u8  i;
    s16 ang;

    MyI2C_Init();

    PcaWriteReg(PCA_MODE1, MODE1_RESTART);
    Delay_ms((u32)SRV_PCA_RESET_MS);
    PcaSetFreq(SRV_FREQ_HZ);

    for (i = 0; i < SRV_NUM; i++)
    {
        s_speed[i]    = 5;
        s_busy[i]     = 0;
        s_lastCnt[i]  = 0xFFFF;
        s_typeSeen[i] = gParam.srvType[i];

        ang = Params_ClampAngle(i, gParam.pos[POS_INIT][i]);
        s_cur[i] = (float)ang;
        s_dst[i] = (float)ang;
    }

    if (!gParamResetFlag)
    {
        for (i = 0; i < SRV_NUM; i++)
        {
            s_lastCnt[i] = ServoAngleToCount(i, s_cur[i], 0);

            if (PcaSetPwm(i, 0u, s_lastCnt[i]) == 0u) s_resend[i] = 1u;
        }
    }
}

static u8 Servo_PlanFill(u8 ch)
{
    s32 a0, a1, step10, i, n;

    a0 = (s32)(s_cur[ch] * 100.0f);
    a1 = (s32)(s_dst[ch] * 100.0f);
    if (a0 == a1)
    {
        s_planLen[ch] = 0u;
        s_planIdx[ch] = 0u;
        return 0u;
    }

    step10 = (s32)s_speed[ch];
    if (step10 < 1) step10 = 1;

    n = ((a1 > a0) ? (a1 - a0) : (a0 - a1)) / step10;
    s_planWhole[ch] = (u8)((n < (s32)SERVO_PLAN_MAX) ? 1u : 0u);
    if (n > (s32)SERVO_PLAN_MAX) n = (s32)SERVO_PLAN_MAX;
    if (n < 1) n = 1;

    for (i = 0; i < n; i++)
    {
        s32 v = (a1 > a0) ? (a0 + step10 * (i + 1)) : (a0 - step10 * (i + 1));
        if ((a1 > a0) && (v > a1)) v = a1;
        if ((a1 < a0) && (v < a1)) v = a1;
        s_plan[ch][i] = (s16)v;
    }
    s_planLen[ch] = (u16)n;
    s_planIdx[ch] = 0u;
    return 1u;
}

static u8 Servo_SpeedApply(u8 ch, u8 degPerSec)
{
    (void)ch;
    if (degPerSec < (u8)SRV_SPEED_MIN) degPerSec = (u8)SRV_SPEED_MIN;
    if (degPerSec > (u8)SRV_SPEED_MAX) degPerSec = (u8)SRV_SPEED_MAX;
    return degPerSec;
}

void Servo_MoveTo(u8 ch, s16 angle, u8 degPerSec)
{
    if (ch >= SRV_NUM) return;

    angle = Params_ClampAngle(ch, angle);
    degPerSec = Servo_SpeedApply(ch, degPerSec);

    s_dst[ch]    = (float)angle;
    s_speed[ch]  = degPerSec;
    s_planAcc[ch] = 0u;
    s_busy[ch]   = Servo_PlanFill(ch);
}

void Servo_SetImmediate(u8 ch, s16 angle)
{
    u16 cnt;

    if (ch >= SRV_NUM) return;

    angle = Params_ClampAngle(ch, angle);

    s_cur[ch]  = (float)angle;
    s_dst[ch]  = (float)angle;
    s_busy[ch] = 0;

    cnt = ServoAngleToCount(ch, s_cur[ch], 0);

    if ((cnt == s_lastCnt[ch]) && (s_resend[ch] == 0u)) return;

    if (PcaSetPwm(ch, 0u, cnt) != 0u) s_lastCnt[ch] = cnt;
    else                              s_resend[ch]  = 1u;
}

s16 Servo_GetAngle(u8 ch)
{
    if (ch >= SRV_NUM) return 0;
    return ServoRound(s_cur[ch]);
}

u32 Servo_MoveMs(u8 ch, s16 ang, u8 degPerSec)
{
    s32 d;
    u32 sp;

    if (ch >= SRV_NUM) return 0;

    if ((s_busy[ch] != 0u) && (s_planWhole[ch] != 0u) &&
        (ang == ServoRound(s_dst[ch])) && (s_planLen[ch] > s_planIdx[ch]))
    {
        return ((u32)(s_planLen[ch] - s_planIdx[ch])) * (u32)SERVO_PLAN_TICK;
    }

    sp = (u32)Servo_SpeedApply(ch, degPerSec);

    d = (s32)ang - (s32)Servo_GetAngle(ch);
    if (d < 0) d = -d;

    return (((u32)d * 1000u) + sp - 1u) / sp;
}

u8 Servo_Arrived(u8 ch)
{
    float d;

    if (ch >= SRV_NUM) return 1;
    d = s_cur[ch] - s_dst[ch];
    if (d < 0.0f) d = -d;
    return (u8)((d <= SRV_ARRIVE_TOL) ? 1 : 0);
}

u8 Servo_AnyBusy(void)
{
    u8 i;

    for (i = 0; i < (u8)SRV_NUM; i++)
    {
        if (!Servo_Arrived(i)) return 1u;
    }
    return 0u;
}

void Servo_Hold(u8 ch)
{
    if (ch >= SRV_NUM) return;
    s_dst[ch]  = s_cur[ch];
    s_busy[ch] = 0;
}

u8 Servo_Motor(PinDef p, u8 ch, s16 angle, u8 degPerSec)
{

    if (Motion_ServoLocked() != 0u) return 0u;

    if (!((p.port == PIN_PCA_SDA.port) && (p.pin == PIN_PCA_SDA.pin))
        && !((p.port == PIN_PCA_SCL.port) && (p.pin == PIN_PCA_SCL.pin))) return 0u;
    if (ch >= (u8)SRV_NUM)                          return 0u;
    if (degPerSec == 0u) degPerSec = (u8)gParam.runSpeed[ch];

    Servo_MoveTo(ch, angle, (u8)((degPerSec != 0u) ? degPerSec : 1u));
    return 1u;
}

void Servo_Task(void)
{
    static u32 lastMs = 0;
    static u8  lastValid = 0;
    u32 now;
    u32 dt;
    u8  i;

    if (Motion_ServoLocked() != 0u) { lastMs = Time_Now(); lastValid = 1u; return; }

    now = Time_Now();

    if (lastValid == 0u) { lastMs = now; lastValid = 1u; return; }

    dt  = (u32)(now - lastMs);
    if (dt < (u32)SRV_TASK_MS) return;
    lastMs = now;

    if (dt > (u32)SRV_DT_MAX_MS) dt = (u32)SRV_DT_MAX_MS;

    for (i = 0; i < SRV_NUM; i++)
    {
        u16      cnt;

        u8 sent = 0u;

        if (s_typeSeen[i] != gParam.srvType[i])
        {
            s_typeSeen[i] = gParam.srvType[i];
            s_resend[i]   = 1u;
        }

        if (s_resend[i] != 0u)
        {
            cnt = ServoAngleToCount(i, s_cur[i], ServoMoveDir(i));
            if (s_rsCnt[i] != 0xFFFFu) s_rsCnt[i]++;
            if (PcaSetPwm(i, 0u, cnt) != 0u)
            {
                s_lastCnt[i] = cnt;
                s_resend[i]  = 0u;
                continue;
            }
            sent = 1u;
        }

        if (!s_busy[i]) continue;

        s_planAcc[i] += dt;
        {
            u32 adv = s_planAcc[i] / (u32)SERVO_PLAN_TICK;
            s_planAcc[i] = s_planAcc[i] % (u32)SERVO_PLAN_TICK;

            while ((adv-- != 0u) && (s_planIdx[i] < s_planLen[i]))
            {
                s_planIdx[i]++;
            }
        }

        if (s_planIdx[i] >= s_planLen[i])
        {
            s_cur[i] = (float)s_plan[i][(s_planLen[i] != 0u) ? (s_planLen[i] - 1u) : 0u] * 0.01f;
            if (s_cur[i] == s_dst[i]) { s_busy[i] = 0; }
            else if (Servo_PlanFill(i) == 0u) { s_busy[i] = 0; }
        }
        else if (s_planIdx[i] != 0u)
        {
            s_cur[i] = (float)s_plan[i][s_planIdx[i] - 1u] * 0.01f;
        }
        else
        {
            s_cur[i] = (float)s_plan[i][0] * 0.01f;
        }

        cnt = ServoAngleToCount(i, s_cur[i], ServoMoveDir(i));
        if (!sent && (cnt != s_lastCnt[i]))
        {

            if (PcaSetPwm(i, 0u, cnt) != 0u) s_lastCnt[i] = cnt;
            else                             s_resend[i]  = 1u;
        }
    }
}

u16 Servo_DiagWriteCnt(u8 ch)
{
    if (ch >= (u8)SRV_NUM) return 0u;
    return s_wrTry[ch];
}

u16 Servo_DiagWriteOkCnt(u8 ch)
{
    if (ch >= (u8)SRV_NUM) return 0u;
    return s_wrOk[ch];
}

u16 Servo_DiagResendCnt(u8 ch)
{
    if (ch >= (u8)SRV_NUM) return 0u;
    return s_rsCnt[ch];
}

u8 Servo_DiagFreqBad(void)
{
    return s_freqBad;
}
