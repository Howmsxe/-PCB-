#ifndef __OLED_H
#define __OLED_H

void OLED_Init(void);
void OLED_Clear(void);
void OLED_Refresh(void);

uint8_t OLED_RefreshPending(void);

void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t color);
void OLED_DrawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h);
void OLED_FillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h);

void OLED_ClearRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h);
void OLED_MarkRow(uint8_t line);

void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, const char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);

void OLED_ShowChinese(uint8_t Line, uint8_t Column, uint8_t Index);
void OLED_ShowCnStr(uint8_t Line, uint8_t Column, const char *s);
void OLED_ShowCnStrInv(uint8_t Line, uint8_t Column, const char *s);
void OLED_ShowCharInv(uint8_t Line, uint8_t Column, char Char);

#endif
