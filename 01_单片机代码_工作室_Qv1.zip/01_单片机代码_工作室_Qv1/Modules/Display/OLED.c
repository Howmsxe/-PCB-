#include "stm32f10x.h"
#include "OLED_Font.h"
#include "ChineseFont.h"
#include "Core/Types.h"
#include "Bsp/Bsp.h"
#include "MyI2C.h"
#include "Delay.h"

#define OLED_W_SCL(x)		Bsp_Write(PIN_OLED_SCL, (u8)((x) ? 1u : 0u))
#define OLED_W_SDA(x)		Bsp_Write(PIN_OLED_SDA, (u8)((x) ? 1u : 0u))

#define OLED_NOP1()     do { __NOP(); } while (0)
#define OLED_NOP4()     do { OLED_NOP1(); OLED_NOP1(); OLED_NOP1(); OLED_NOP1(); } while (0)
#define OLED_NOP8()     do { OLED_NOP4(); OLED_NOP4(); } while (0)
#define OLED_NOP16()    do { OLED_NOP8(); OLED_NOP8(); } while (0)
#define OLED_NOP32()    do { OLED_NOP16(); OLED_NOP16(); } while (0)
#define OLED_NOP64()    do { OLED_NOP32(); OLED_NOP32(); } while (0)
#define OLED_NOP40()    do { OLED_NOP32(); OLED_NOP8(); } while (0)
#define OLED_NOP96()    do { OLED_NOP64(); OLED_NOP32(); } while (0)

static void OledSclHoldHigh(void)
{
	OLED_NOP40();
}

static void OledSclHoldLow(void)
{
	OLED_NOP96();
}

#define OLED_SCL_HIGH()	do { OLED_W_SCL(1); OledSclHoldHigh(); } while (0)
#define OLED_SCL_LOW()		do { OLED_W_SCL(0); OledSclHoldLow(); } while (0)

uint8_t OLED_GRAM[8][128];

void OLED_I2C_Init(void)
{

	OLED_SCL_HIGH();
	OLED_W_SDA(1);
}

void OLED_I2C_Start(void)
{
	OLED_W_SDA(1);
	OLED_SCL_HIGH();
	OLED_W_SDA(0);
	OLED_SCL_LOW();
}

void OLED_I2C_Stop(void)
{
	OLED_W_SDA(0);
	OLED_SCL_HIGH();
	OLED_W_SDA(1);
}

void OLED_I2C_SendByte(uint8_t Byte)
{
	uint8_t i;
	for (i = 0; i < 8; i++)
	{
		OLED_W_SDA(!!(Byte & (0x80 >> i)));
		OLED_SCL_HIGH();
		OLED_SCL_LOW();
	}
	OLED_SCL_HIGH();
	OLED_SCL_LOW();
}

void OLED_WriteCommand(uint8_t Command)
{
	MyI2C_BusEnter();
	OLED_I2C_Start();
	OLED_I2C_SendByte(0x78);
	OLED_I2C_SendByte(0x00);
	OLED_I2C_SendByte(Command);
	OLED_I2C_Stop();
	MyI2C_BusLeave();
}

static void OledMarkAll(void);

void OLED_Clear(void)
{
	uint8_t i, j;
	for (i = 0; i < 8; i++)
		for (j = 0; j < 128; j++)
			OLED_GRAM[i][j] = 0x00;
	OledMarkAll();
}

static void OLED_WriteDataBurst(const uint8_t *data, uint16_t len)
{
	uint16_t i;
	MyI2C_BusEnter();
	OLED_I2C_Start();
	OLED_I2C_SendByte(0x78);
	OLED_I2C_SendByte(0x40);
	for (i = 0; i < len; i++)
		OLED_I2C_SendByte(data[i]);
	OLED_I2C_Stop();
	MyI2C_BusLeave();
}

#ifndef OLED_RF_PAGES
#define OLED_RF_PAGES  1u

#endif

static uint8_t s_rfMask = 0xFF;
static uint8_t s_rfNext = 0;

static void OledMarkAll(void)
{
	s_rfMask = 0xFF;
}

uint8_t OLED_RefreshPending(void)
{
	return (uint8_t)((s_rfMask != 0u) ? 1u : 0u);
}

void OLED_Refresh(void)
{
	uint8_t n = 0u;
	uint8_t i;

	for (i = 0u; (i < 8u) && (n < (uint8_t)OLED_RF_PAGES); i++)
	{
		uint8_t pg = (uint8_t)((s_rfNext + i) & 7u);
		if ((s_rfMask & (uint8_t)(1u << pg)) == 0u) continue;
		OLED_WriteCommand(0xB0 | pg);
		OLED_WriteCommand(0x10);
		OLED_WriteCommand(0x00);
		OLED_WriteDataBurst(&OLED_GRAM[pg][0], 128);
		s_rfMask = (uint8_t)(s_rfMask & (uint8_t)~(1u << pg));
		s_rfNext = (uint8_t)((pg + 1u) & 7u);
		n++;
	}
}

void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t color)
{
	if (x > 127 || y > 63) return;
	if (color) OLED_GRAM[y / 8][x] |=  (1 << (y % 8));
	else       OLED_GRAM[y / 8][x] &= ~(1 << (y % 8));
}

void OLED_DrawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h)
{
	uint8_t i;
	if (w == 0 || h == 0) return;
	for (i = 0; i < w; i++)
	{
		OLED_DrawPixel(x + i, y, 1);
		OLED_DrawPixel(x + i, y + h - 1, 1);
	}
	for (i = 0; i < h; i++)
	{
		OLED_DrawPixel(x, y + i, 1);
		OLED_DrawPixel(x + w - 1, y + i, 1);
	}
}

void OLED_FillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h)
{
	uint8_t i, j;
	for (i = 0; i < w; i++)
		for (j = 0; j < h; j++)
			OLED_DrawPixel(x + i, y + j, 1);
}

void OLED_ClearRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h)
{
	uint8_t i, j;
	for (i = 0; i < w; i++)
		for (j = 0; j < h; j++)
			OLED_DrawPixel(x + i, y + j, 0);
}

void OLED_MarkRow(uint8_t line)
{
	uint8_t pg;
	if (line < 1u || line > 4u) return;
	pg = (uint8_t)((line - 1u) * 2u);
	s_rfMask = (uint8_t)(s_rfMask | (uint8_t)(1u << pg) | (uint8_t)(1u << (pg + 1u)));
}

void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char)
{
	uint8_t i;
	uint8_t page = (Line - 1) * 2;
	uint8_t x = (Column - 1) * 8;
	if (Line < 1 || Line > 4 || Column < 1 || Column > 16) return;

	if (Char < ' ' || Char > '~') return;
	for (i = 0; i < 8; i++)
	{
		OLED_GRAM[page][x + i]     = OLED_F8x16[Char - ' '][i];
		OLED_GRAM[page + 1][x + i] = OLED_F8x16[Char - ' '][i + 8];
	}
}

void OLED_ShowString(uint8_t Line, uint8_t Column, const char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i++)
		OLED_ShowChar(Line, Column + i, String[i]);
}

uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--) Result *= X;
	return Result;
}

void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0');
}

void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length)
{
	uint8_t i;
	uint32_t Number1;
	if (Number >= 0)
	{
		OLED_ShowChar(Line, Column, '+');
		Number1 = Number;
	}
	else
	{
		OLED_ShowChar(Line, Column, '-');
		Number1 = -Number;
	}
	for (i = 0; i < Length; i++)
		OLED_ShowChar(Line, Column + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0');
}

void OLED_ShowChinese(uint8_t Line, uint8_t Column, uint8_t Index)
{
	uint8_t i;
	uint8_t page = (Line - 1) * 2;
	uint8_t x = (Column - 1) * 8;
	if (Index >= CN_COUNT || Line < 1 || Line > 4 || Column < 1 || Column > 15) return;
	for (i = 0; i < 16; i++)
	{
		OLED_GRAM[page][x + i]     = CN_Font[Index][i];
		OLED_GRAM[page + 1][x + i] = CN_Font[Index][i + 16];
	}
}

void OLED_ShowCnStr(uint8_t Line, uint8_t Column, const char *s)
{
	while (*s)
	{

		if (Column > 16u) break;

		if ((uint8_t)(*s) < 0x80)
		{
			OLED_ShowChar(Line, Column, *s);
			s++;
			Column++;
		}
		else
		{
			uint16_t code;
			uint8_t idx;

			if (s[1] == '\0') break;

			code = ((uint16_t)(uint8_t)s[0] << 8) | (uint8_t)s[1];
			idx = CN_Lookup(code);
			if (idx != 0xFF) OLED_ShowChinese(Line, Column, idx);
			s += 2;
			Column += 2;
		}
	}
}

void OLED_ShowCharInv(uint8_t Line, uint8_t Column, char Char)
{
	uint8_t i;
	uint8_t page = (Line - 1) * 2;
	uint8_t x = (Column - 1) * 8;
	if (Line < 1 || Line > 4 || Column < 1 || Column > 16) return;

	if (Char < ' ' || Char > '~') return;
	for (i = 0; i < 8; i++)
	{
		OLED_GRAM[page][x + i]     = (uint8_t)~OLED_F8x16[Char - ' '][i];
		OLED_GRAM[page + 1][x + i] = (uint8_t)~OLED_F8x16[Char - ' '][i + 8];
	}
}

static void OLED_DrawCnInv(uint8_t Line, uint8_t Column, uint8_t Index)
{
	uint8_t i;
	uint8_t page = (Line - 1) * 2;
	uint8_t x = (Column - 1) * 8;
	if (Index >= CN_COUNT || Line < 1 || Line > 4 || Column < 1 || Column > 15) return;
	for (i = 0; i < 16; i++)
	{
		OLED_GRAM[page][x + i]     = (uint8_t)~CN_Font[Index][i];
		OLED_GRAM[page + 1][x + i] = (uint8_t)~CN_Font[Index][i + 16];
	}
}

void OLED_ShowCnStrInv(uint8_t Line, uint8_t Column, const char *s)
{
	while (*s)
	{

		if (Column > 16u) break;

		if ((uint8_t)(*s) < 0x80)
		{
			OLED_ShowCharInv(Line, Column, *s);
			s++;
			Column++;
		}
		else
		{
			uint16_t code;
			uint8_t idx;

			if (s[1] == '\0') break;

			code = ((uint16_t)(uint8_t)s[0] << 8) | (uint8_t)s[1];
			idx = CN_Lookup(code);
			if (idx != 0xFF) OLED_DrawCnInv(Line, Column, idx);
			s += 2;
			Column += 2;
		}
	}
}

void OLED_Init(void)
{

	Delay_ms(50u);

	OLED_I2C_Init();

	OLED_WriteCommand(0xAE);
	OLED_WriteCommand(0xD5);
	OLED_WriteCommand(0x80);
	OLED_WriteCommand(0xA8);
	OLED_WriteCommand(0x3F);
	OLED_WriteCommand(0xD3);
	OLED_WriteCommand(0x00);
	OLED_WriteCommand(0x40);
	OLED_WriteCommand(0xA1);
	OLED_WriteCommand(0xC8);
	OLED_WriteCommand(0xDA);
	OLED_WriteCommand(0x12);
	OLED_WriteCommand(0x81);
	OLED_WriteCommand(0xCF);
	OLED_WriteCommand(0xD9);
	OLED_WriteCommand(0xF1);
	OLED_WriteCommand(0xDB);
	OLED_WriteCommand(0x30);
	OLED_WriteCommand(0xA4);
	OLED_WriteCommand(0xA6);
	OLED_WriteCommand(0x8D);
	OLED_WriteCommand(0x14);
	OLED_WriteCommand(0xAF);

	OLED_Clear();
	OLED_Refresh();
}
