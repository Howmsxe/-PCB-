#ifndef __MOD_SERVO_H
#define __MOD_SERVO_H

#include "Core/Types.h"
#include "Core/PinMap.h"

#define SRV_ARM1   0
#define SRV_ARM2   1
#define SRV_TRAY   2
#define SRV_NUM    3

#define POS_INIT   0
#define POS_BOX1   1
#define POS_BOX6   6
#define POS_LUMP   7
#define POS_COUNT  8

void    Servo_Init(void);

u8      Servo_Motor(PinDef p, u8 ch, s16 angle, u8 degPerSec);
void    Servo_MoveTo(u8 ch, s16 angle, u8 degPerSec);
void    Servo_SetImmediate(u8 ch, s16 angle);
void    Servo_Task(void);
s16     Servo_GetAngle(u8 ch);
u32     Servo_MoveMs(u8 ch, s16 ang, u8 degPerSec);
u8      Servo_Arrived(u8 ch);
u8      Servo_AnyBusy(void);
void    Servo_Hold(u8 ch);

u16     Servo_DiagWriteCnt(u8 ch);
u16     Servo_DiagWriteOkCnt(u8 ch);
u16     Servo_DiagResendCnt(u8 ch);
u8      Servo_DiagFreqBad(void);

#endif
