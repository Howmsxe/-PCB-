#ifndef __BOARDCFG_H
#define __BOARDCFG_H

#define CFG_T_BEAT_MS        10u
#define CFG_BELT_SETTLE_MS   10u
#define CFG_WDG_TIMEOUT_MS   1000u

#define CFG_ANGLE_MAX        90
#define CFG_SERVO_MIN_US     500u
#define CFG_SERVO_MAX_US     2500u

#define CFG_POS_SLOTS        9u
#define CFG_AXIS_SLOTS       3u

#endif
