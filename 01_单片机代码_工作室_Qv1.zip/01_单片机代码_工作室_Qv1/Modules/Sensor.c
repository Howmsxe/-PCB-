#include "Core/Types.h"
#include "Core/Time.h"
#include "Bsp/Bsp.h"
#include "Modules/Sensor.h"
#include "Modules/Params.h"

static PinDef SensPin(u8 idx)
{
    return (idx == (u8)SENS_DOWN) ? PIN_SENS_DOWN : PIN_SENS_UP;
}

static volatile u8  s_rawLevel[SENSOR_NUM]  = { 0, 0 };
static volatile u32 s_rawMs[SENSOR_NUM]     = { 0, 0 };
static volatile u8  s_lastLevel[SENSOR_NUM] = { 0, 0 };
static volatile u32 s_lastEdgeMs[SENSOR_NUM] = { 0, 0 };

static volatile u32 s_glitch[SENSOR_NUM]    = { 0u, 0u };
static volatile u32 s_glitchAll[SENSOR_NUM] = { 0u, 0u };
static volatile u8  s_fresh[SENSOR_NUM]     = { 0u, 0u };

static u8 SensNormLv(u8 idx, u8 lv)
{
    (void)idx;

#if (SENS_ACTIVE_LOW != 0u)
    return (u8)((lv == 0u) ? 1u : 0u);   /* �͵�ƽ=���� */
#else
    return (u8)((lv != 0u) ? 1u : 0u);   /* �ߵ�ƽ=���� */
#endif
}

static u8 SensNorm(u8 idx)
{
    return SensNormLv(idx, s_lastLevel[idx]);
}

void Sensor_Init(void)
{
    u8  i;
    u32 now;

    /* �ڲ��������ף�����ʱ���������� 3.3V���ⲿ 4.7~10k �����������Ӳ�� */
    Bsp_SetMode(PIN_SENS_UP, (u8)PDIR_IN_FLOAT);
    Bsp_SetMode(PIN_SENS_DOWN, (u8)PDIR_IN_FLOAT);
    Bsp_ExtiConfig(PIN_SENS_UP, 1, 1);
    Bsp_ExtiConfig(PIN_SENS_DOWN, 1, 1);

    now = Time_Now();
    for (i = 0; i < SENSOR_NUM; i++)
    {

        s_rawLevel[i]   = (u8)(Bsp_Read(SensPin(i)) ? 1 : 0);
        s_lastLevel[i]  = s_rawLevel[i];
        s_rawMs[i]      = now;
        s_lastEdgeMs[i] = now;
        s_glitch[i]     = 0u;
        s_glitchAll[i]  = 0u;
    }

}

void Sensor_IsrEdge(u8 idx)
{
    if (idx >= SENSOR_NUM) return;

    /* �ж�ֻ������ͳ�ƣ���ƽ�ж�һ���� Sensor_Poll ֱ�Ӷ���ʵ���� */
    if ((u32)(Time_Now() - s_rawMs[idx]) < (u32)SENS_DEBOUNCE_MS) s_glitch[idx]++;
    s_glitchAll[idx]++;
}

void Sensor_Poll(void)
{
    u8  idx;
    u8  lv;
    u32 now;

    now = Time_Now();

    for (idx = 0; idx < SENSOR_NUM; idx++)
    {
        lv = (u8)(Bsp_Read(SensPin(idx)) ? 1 : 0);   /* ֱ�Ӷ���ʵ���� */

        if (lv == s_lastLevel[idx])
        {
            s_rawLevel[idx] = lv;
            s_rawMs[idx]    = now;
            continue;
        }

        if (lv != s_rawLevel[idx])
        {
            s_rawLevel[idx] = lv;
            s_rawMs[idx]    = now;
            continue;
        }

        if ((u32)(now - s_rawMs[idx]) < (u32)SENS_DEBOUNCE_MS) continue;

        s_lastLevel[idx]  = lv;
        s_lastEdgeMs[idx] = now;
        s_rawMs[idx]      = now;

        {
            u8 nlv = SensNormLv(idx, lv);
            u8 up  = 1u;   /* ֻ���½��أ���������ʱ�������� */

            if (nlv == up) s_fresh[idx] = 1u;
        }
    }
}

void Sensor_Task(void)
{
    Sensor_Poll();
}

u8 Sensor_Active(u8 idx)
{
    if (idx >= SENSOR_NUM) return 0;
    return SensNorm(idx);
}

u8 Sensor_RawLevel(u8 idx)
{
    u8 i;
    u8 hi = 0u;

    if (idx >= SENSOR_NUM) return 1;

    /* 8 �β����������������Ƶ�Դ�Ʋ������ĵ���ë�̣�ȫ��ʵʱ������������ */
    for (i = 0u; i < (u8)SENS_SAMPLE_N; i++)
    {
        if (Bsp_Read(SensPin(idx)) != 0u) hi++;
    }

    return (u8)((hi > (u8)((u8)SENS_SAMPLE_N / 2u)) ? 1u : 0u);
}

void Sensor_ResyncOne(u8 idx)
{
    if (idx >= SENSOR_NUM) return;
    s_rawLevel[idx]  = (u8)(Bsp_Read(SensPin(idx)) ? 1 : 0);
    s_lastLevel[idx] = s_rawLevel[idx];
    s_fresh[idx]     = 0u;
}

void Sensor_ForceIdle(u8 idx)
{
    if (idx >= SENSOR_NUM) return;
    s_lastLevel[idx] = (u8)((SENS_ACTIVE_LOW != 0u) ? 1u : 0u);
    s_fresh[idx]     = 0u;
}

void Sensor_Resync(void)
{
    u8 i;
    for (i = 0; i < SENSOR_NUM; i++) Sensor_ResyncOne(i);
}

u32 Sensor_TakeGlitch(u8 idx)
{
    u32 v;
    u32 pm;

    if (idx >= SENSOR_NUM) return 0u;

    pm = __get_PRIMASK();
    __disable_irq();
    v = s_glitch[idx];
    s_glitch[idx] = 0u;
    __set_PRIMASK(pm);
    return v;
}

u32 Sensor_GlitchTotal(u8 idx)
{
    if (idx >= SENSOR_NUM) return 0u;
    return s_glitchAll[idx];
}

void Sensor_ArmEdge(u8 idx)
{
    if (idx >= SENSOR_NUM) return;
    s_fresh[idx] = 0u;
}

u8 Sensor_TakeFreshEdge(u8 idx)
{
    u8 v;

    if (idx >= SENSOR_NUM) return 0u;
    v = s_fresh[idx];
    s_fresh[idx] = 0u;
    return v;
}
