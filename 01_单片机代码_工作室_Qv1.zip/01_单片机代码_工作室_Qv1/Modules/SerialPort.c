#include "Core/Types.h"
#include "Modules/SerialPort.h"

#define SER_RX_RING   128
#define SER_RX_MASK   (SER_RX_RING - 1)

static volatile u8  s_rxBuf[SER_RX_RING];
static volatile u8  s_rxHead = 0;
static volatile u8  s_rxTail = 0;
static volatile u16 s_dropCount = 0;

void Ser_IsrRx(u8 b, u16 sr)
{
    u8 next;

    if ((sr & (u16)(USART_FLAG_FE | USART_FLAG_NE | USART_FLAG_ORE)) != 0u)
    {
        s_dropCount++;
        return;
    }

    next = (u8)((s_rxHead + 1u) & SER_RX_MASK);

    if (next == s_rxTail)
    {
        s_dropCount++;

        return;
    }
    s_rxBuf[s_rxHead] = b;
    s_rxHead = next;
}

u8 Ser_GetByte(u8* b)
{
    if (b == 0) return 0u;
    if (s_rxTail == s_rxHead) return 0u;
    *b = s_rxBuf[s_rxTail];
    s_rxTail = (u8)((s_rxTail + 1u) & SER_RX_MASK);
    return 1u;
}

u16 Ser_DropCount(void)
{
    return s_dropCount;
}

void Ser_Flush(void)
{
    u32 guard = 20000u;

    __disable_irq();
    s_rxHead = 0u;
    s_rxTail = 0u;
    (void)USART_GetFlagStatus(USART1, USART_FLAG_RXNE);
    (void)USART_ReceiveData(USART1);
    /* Bounded drain: PA10 is floating (serial unused) so the receiver can keep
     * re-asserting RXNE faster than this loop drains it. With interrupts disabled
     * an unbounded loop here locks the whole system up before __enable_irq().
     * The guard makes the worst case a few ms and always re-enables interrupts. */
    while ((USART_GetFlagStatus(USART1, USART_FLAG_RXNE) != RESET) && (guard != 0u))
    {
        (void)USART_ReceiveData(USART1);
        guard--;
    }
    __enable_irq();
}

void Ser_SendByte(u8 b)
{
    u32 guard = 20000u;

    /* Bounded wait: if USART clock or peripheral is ever disabled, TXE never
     * asserts and an unbounded loop would hang the caller (same class of bug as
     * Ser_Flush). Dropping one byte is preferable to locking up. */
    while ((USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET) && (guard != 0u))
    {
        guard--;
    }
    USART_SendData(USART1, (u16)b);
}

void Ser_SendStr(const char *s)
{
    while (*s != '\0')
    {
        Ser_SendByte((u8)(*s));
        s++;
    }
}

void Ser_SendInt(s32 v)
{
    char t[12];
    u8   n = 0;
    u32  mag;

    if (v < 0)
    {
        Ser_SendByte((u8)'-');
        mag = (u32)(-(v + 1)) + 1u;
    }
    else
    {
        mag = (u32)v;
    }

    if (mag == 0u)
    {
        Ser_SendByte((u8)'0');
        return;
    }
    while ((mag > 0u) && (n < (u8)sizeof(t)))
    {
        t[n] = (char)('0' + (u8)(mag % 10u));
        n++;
        mag = mag / 10u;
    }
    while (n > 0u)
    {
        n--;
        Ser_SendByte((u8)t[n]);
    }
}

void Ser_Init(void)
{
    USART_InitTypeDef u;
    NVIC_InitTypeDef  n;
    GPIO_InitTypeDef  g;

    /* USART1 ���ţ���� CH340 �� USB<->TTL ͨѶ��
     *   PA9  = USART1_TX -> CH340 RXD�����븴����������������򷢲�������
     *   PA10 = USART1_RX <- CH340 TXD���������루δ�� CH340 ʱ���ֿ��иߵ�ƽ��
     * ��д��������·��ST-Link SWD��PA13/PA14���򴮿� ISP��BOOT0=1 �������ڣ���
     */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);

    g.GPIO_Pin   = GPIO_Pin_9;
    g.GPIO_Mode  = GPIO_Mode_AF_PP;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &g);

    g.GPIO_Pin   = GPIO_Pin_10;
    g.GPIO_Mode  = GPIO_Mode_IPU;     /* pull-up: keeps RX idle-high when CH340 unplugged */
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &g);

    u.USART_BaudRate            = 115200;
    u.USART_WordLength          = USART_WordLength_8b;
    u.USART_StopBits            = USART_StopBits_1;
    u.USART_Parity              = USART_Parity_No;
    u.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    u.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART1, &u);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    n.NVIC_IRQChannel                   = USART1_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 3;
    n.NVIC_IRQChannelSubPriority        = 0;
    n.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&n);

    USART_Cmd(USART1, ENABLE);

    Ser_Flush();
}
