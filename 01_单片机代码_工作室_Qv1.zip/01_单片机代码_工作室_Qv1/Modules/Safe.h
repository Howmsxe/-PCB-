#ifndef __SAFE_H
#define __SAFE_H

#include "stm32f10x.h"

static __inline s16* Pos_At(s16 (*arr)[3], u8 grp, u8 sub)
{
    if (grp >= 8u) grp = 0u;
    if (sub >= 3u) sub = 0u;
    return &arr[grp][sub];
}

#define IGN_OK(expr)  ((void)(expr))

#ifndef CLAMP
#define CLAMP(v, lo, hi)  (((v) < (lo)) ? (lo) : (((v) > (hi)) ? (hi) : (v)))
#endif
#endif
