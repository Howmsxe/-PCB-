#include "Core/Types.h"
#include "Core/Time.h"
#include "Modules/Params.h"
#include "stm32f10x_flash.h"
#include <stddef.h>

#define PARAM_OFF(field)  ((u16)offsetof(SysParams, field))
#define PARAM_TICKS_PER_MS  100u

STATIC_ASSERT(PARAM_OFF(magic)       == 0,  params_off_magic);
STATIC_ASSERT(PARAM_OFF(ver)         == 4,  params_off_ver);
STATIC_ASSERT(PARAM_OFF(pos)         == 6,  params_off_pos);
STATIC_ASSERT(PARAM_OFF(runSpeed)    == 54, params_off_runspeed);
STATIC_ASSERT(PARAM_OFF(beltSpeed)   == 60, params_off_beltspeed);
STATIC_ASSERT(PARAM_OFF(beltDir)     == 64, params_off_beltdir);
STATIC_ASSERT(PARAM_OFF(sensDelay)   == 68, params_off_sensdelay);
STATIC_ASSERT(PARAM_OFF(srvType)     == 72, params_off_srvtype);
STATIC_ASSERT(PARAM_OFF(beltMicro)   == 76, params_off_beltmicro);
STATIC_ASSERT(sizeof(SysParams)      == 80, params_chk_size_80);
STATIC_ASSERT((sizeof(SysParams) % 4) == 0, params_size_word_aligned);

SysParams gParam;
u8        gParamResetFlag = 0;

static const u8 kSrvTypeFixed[CFG_AXIS_SLOTS] =
{
    (u8)SRV_TYPE_360,
    (u8)SRV_TYPE_180,
    (u8)SRV_TYPE_180
};

static void Params_FillDefault(SysParams *p)
{
    u8 i, j;

    p->magic = SAVE_MAGIC;
    p->ver   = (s16)PARAM_VER;

    for (i = 0; i < (u8)POS_COUNT; i++)
    {
        for (j = 0; j < 3u; j++)
        {
            p->pos[i][j] = 0;
        }
    }

    p->runSpeed[0] = (s16)DEF_RUN_SPEED_ARM1;
    p->runSpeed[1] = (s16)DEF_RUN_SPEED_ARM2;
    p->runSpeed[2] = (s16)DEF_RUN_SPEED_TRAY;

    for (i = 0; i < 2u; i++)
    {
        p->beltSpeed[i]   = (s16)DEF_BELT_SPEED;
        p->beltDir[i]     = (s16)DEF_BELT_DIR;
        p->sensDelay[i]   = (s16)DEF_SENS_DELAY;
        p->beltMicro[i]   = (s16)DEF_BELT_MICRO;
    }

    for (i = 0; i < (u8)CFG_AXIS_SLOTS; i++)
    {
        p->srvType[i] = kSrvTypeFixed[i];
    }
}

void Params_SetDefault(void)
{
    Params_FillDefault(&gParam);
}

void Params_Load(void)
{
    const u8 *src = (const u8 *)PARAM_ADDR;
    u8       *dst = (u8 *)&gParam;
    u16       i;

    if ((*(volatile u32 *)PARAM_ADDR == (u32)SAVE_MAGIC) &&
        (*(volatile s16 *)(PARAM_ADDR + 4u) == (s16)PARAM_VER))
    {
        for (i = 0; i < (u16)sizeof(SysParams); i++)
        {
            dst[i] = src[i];
        }
    }
    else
    {
        Params_SetDefault();
        gParamResetFlag = 1;
    }

    for (i = 0; i < (u16)CFG_AXIS_SLOTS; i++)
    {
        gParam.srvType[i] = kSrvTypeFixed[i];
    }

    Params_ClampAll(&gParam);

    Params_DraftSync();

}

u8 Params_Save(void)
{
    const u32 *p;
    u16        words;
    u16        i;
    u32        pm;
    u32        t0, t1, el;
    u16        dticks;
    u8         ok = 1u;

    gParam.magic = SAVE_MAGIC;
    gParam.ver   = (s16)PARAM_VER;

    p     = (const u32 *)&gParam;
    words = (u16)(((u32)sizeof(SysParams) + 3u) / 4u);

    t0 = Time_RawUs();
    pm = __get_PRIMASK();
    __disable_irq();

    FLASH_Unlock();
    if (FLASH_ErasePage(PARAM_ADDR) == FLASH_COMPLETE)
    {
        for (i = 0; i < words; i++)
        {
            if (FLASH_ProgramWord(PARAM_ADDR + (u32)i * 4u, p[i]) != FLASH_COMPLETE)
            {
                ok = 0u;
                break;
            }
        }
    }
    else
    {
        ok = 0u;
    }
    FLASH_Lock();

    __set_PRIMASK(pm);

    t1 = Time_RawUs();
    dticks = (u16)((u16)(t1 / 10u) - (u16)(t0 / 10u));
    el = (u32)dticks / PARAM_TICKS_PER_MS;
    if (el > 1u) Time_AddMs(el - 1u);

    return ok;
}

u8 Params_ResetDefault(void)
{
    u8 ok;

    Params_SetDefault();
    ok = Params_Save();
    Params_DraftDiscard();
    return ok;
}

u8 Params_BeltMicroValid(s16 v)
{
    if (v == 0) return 1u;
    if (v == 4 || v == 8 || v == 16 || v == 32) return 1u;
    return 0u;
}

typedef struct {
    s16 lo;
    s16 hi;
    s16 step;
} ParamRange;

static const ParamRange g_paramRng[] = {
    { (s16)RUN_SPEED_MIN,   (s16)RUN_SPEED_MAX,   1               },
    { (s16)RUN_SPEED_MIN,   (s16)RUN_SPEED_MAX,   1               },
    { (s16)RUN_SPEED_MIN,   (s16)RUN_SPEED_MAX,   1               },
    { (s16)BELT_SPEED_MIN,  (s16)BELT_SPEED_MAX,  1               },
    { (s16)SENS_DELAY_MIN,  (s16)SENS_DELAY_MAX,  (s16)SENS_DELAY_STEP },
    { (s16)SENS_DELAY_MIN,  (s16)SENS_DELAY_MAX,  (s16)SENS_DELAY_STEP },
};

#define PARAM_RNG_N  ((u8)(sizeof(g_paramRng) / sizeof(g_paramRng[0])))

void Params_Range(u8 id, s16 *lo, s16 *hi)
{
    if (lo == 0 || hi == 0) return;
    if (id >= PARAM_RNG_N) { *lo = 0; *hi = 0; return; }
    *lo = g_paramRng[id].lo;
    *hi = g_paramRng[id].hi;
}

s16 Params_Limit(u8 id, s16 v)
{
    const ParamRange *r;

    if (id >= PARAM_RNG_N) return v;
    r = &g_paramRng[id];
    if (v < r->lo) v = r->lo;
    if (v > r->hi) v = r->hi;
    if (r->step > 1)
    {
        s16 half;

        if (v == r->lo) return r->lo;

        half = (s16)(r->step / 2);
        v = (s16)(((v + half) / r->step) * r->step);
        if (v > r->hi) v = r->hi;
        if (v < r->lo) v = r->lo;
    }
    return v;
}

void Params_ServoRangeOf(const SysParams *p, u8 ch, s16 *lo, s16 *hi)
{
    if ((lo == 0) || (hi == 0)) return;
    if ((p == 0) || (ch >= (u8)CFG_AXIS_SLOTS))
    {
        *lo = (s16)(-SERVO_ANGLE_LIMIT);
        *hi = (s16)SERVO_ANGLE_LIMIT;
        return;
    }
    if (p->srvType[ch] == (u8)SRV_TYPE_360)
    {
        *lo = (s16)SERVO_ANGLE_360_MIN;
        *hi = (s16)SERVO_ANGLE_360_MAX;
    }
    else
    {
        *lo = (s16)(-SERVO_ANGLE_LIMIT);
        *hi = (s16)SERVO_ANGLE_LIMIT;
    }
}

void Params_ServoRange(u8 ch, s16 *lo, s16 *hi)
{
    Params_ServoRangeOf(&gParam, ch, lo, hi);
}

s16 Params_ClampAngleOf(const SysParams *p, u8 ch, s16 ang)
{
    s16 lo;
    s16 hi;

    Params_ServoRangeOf(p, ch, &lo, &hi);
    if (ang < lo) ang = lo;
    if (ang > hi) ang = hi;
    return ang;
}

s16 Params_ClampAngle(u8 ch, s16 ang)
{
    return Params_ClampAngleOf(&gParam, ch, ang);
}

void Params_ClampAll(SysParams *p)
{
    u16 i;
    u8  j;

    for (j = 0; j < (u8)CFG_AXIS_SLOTS; j++)
    {
        if (p->srvType[j] > (u8)SRV_TYPE_360) p->srvType[j] = (u8)SRV_TYPE_180;
    }
    for (i = 0; i < (u16)POS_COUNT; i++)
    {
        for (j = 0; j < (u8)CFG_AXIS_SLOTS; j++)
        {

            p->pos[i][j] = Params_ClampAngleOf(p, j, p->pos[i][j]);
        }
    }

    for (i = 0; i < 2u; i++)
    {

        if (!Params_BeltMicroValid(p->beltMicro[i]))          p->beltMicro[i] = 0;
        if (p->beltDir[i] != 0 && p->beltDir[i] != 1)         p->beltDir[i] = (s16)DEF_BELT_DIR;

        p->beltSpeed[i] = Params_Limit((u8)PARAM_BELT, p->beltSpeed[i]);
        {
            s16 mm = p->beltMicro[i];
            if (!(mm == 0 || mm == 4 || mm == 8 || mm == 16 || mm == 32)) p->beltMicro[i] = 0;
        }
        p->sensDelay[i] = Params_Limit((u8)((i == 0u) ? PARAM_DELAY_UP : PARAM_DELAY_DOWN), p->sensDelay[i]);
    }

    p->runSpeed[0] = Params_Limit((u8)(PARAM_RUN_BASE + 0u), p->runSpeed[0]);
    p->runSpeed[1] = Params_Limit((u8)(PARAM_RUN_BASE + 1u), p->runSpeed[1]);
    p->runSpeed[2] = Params_Limit((u8)(PARAM_RUN_BASE + 2u), p->runSpeed[2]);
}

static SysParams s_draft;
static u8        s_draftInit = 0;

#define PARAMS_CMP_END  ((u16)sizeof(SysParams))

static u8 Params_Same(const SysParams *a, const SysParams *b)
{
    const u8 *pa = (const u8 *)a;
    const u8 *pb = (const u8 *)b;
    u16 i;

    for (i = 4u; i < (u16)PARAMS_CMP_END; i++)
    {
        if (pa[i] != pb[i]) return 0u;
    }
    return 1u;
}

SysParams* Params_Draft(void)
{
    if (!s_draftInit)
    {
        s_draft = gParam;
        s_draftInit = 1u;
    }
    return &s_draft;
}

u8 Params_DraftDirty(void)
{

    if (!s_draftInit) return 0u;
    return (u8)(Params_Same(&s_draft, &gParam) ? 0u : 1u);
}

void Params_DraftSync(void)
{

    if (!s_draftInit)
    {
        s_draft     = gParam;
        s_draftInit = 1u;
        return;
    }

    if (Params_DraftDirty()) return;
    s_draft     = gParam;
    s_draftInit = 1u;
}

void Params_DraftDiscard(void)
{
    s_draft     = gParam;
    s_draftInit = 1u;
}

u8 Params_CommitDraft(void)
{
    u32 pm;

    if (!s_draftInit)
    {
        s_draft     = gParam;
        s_draftInit = 1u;
        return 0u;
    }

    Params_ClampAll(&s_draft);
    s_draft.magic = SAVE_MAGIC;
    s_draft.ver   = (s16)PARAM_VER;

    if (Params_Same(&s_draft, &gParam)) return 0u;

    pm = __get_PRIMASK();
    __disable_irq();
    gParam = s_draft;
    __set_PRIMASK(pm);
    return 1u;
}


