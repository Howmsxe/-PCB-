#ifndef __MOD_SERIALPORT_H
#define __MOD_SERIALPORT_H

#include "Core/Types.h"

void    Ser_Init(void);
void    Ser_SendByte(u8 b);
void    Ser_SendStr(const char* s);
void    Ser_SendInt(s32 v);
u8      Ser_GetByte(u8* b);
void    Ser_Flush(void);
u16     Ser_DropCount(void);
void    Ser_IsrRx(u8 b, u16 sr);

#endif
