#ifndef __MOD_ENCODER_H
#define __MOD_ENCODER_H

#include "Core/Types.h"

#define ENC_EV_NONE   0
#define ENC_EV_SHORT  1
#define ENC_EV_LONG   2
#define ENC_EV_DOWN   3
#define ENC_EV_UP     4

#define ENC_STEP_DIV   4
#define ENC_REVERSE    1
#define ENC_KEY_ACTIVE_HIGH 1   /* PB15 ����=�ߣ�v10.22 �ɰ壬���½� 3.3V�� */

void    Enc_Init(void);
s16     Enc_TakeRotate(void);
u8      Enc_TakeEvent(void);
u8      Enc_KeyDown(void);
void    Enc_IsrTick(void);
void    Enc_Task(void);

#endif
