#ifndef __UI_UI_H
#define __UI_UI_H

#include "Core/Types.h"

void UI_Init(void);
void UI_Task(void);
void UI_RunStep(void);

void UI_Clear(void);
void UI_List(const char **items, u8 n);
void UI_ListFrom(const char **items, u8 n, u8 from);
void UI_ListN(const char **items, u8 n, u8 from, u8 rows);
void UI_Box(u8 row, u8 blink);
void UI_BoxW(u8 row, u8 w, u8 blink);
void UI_Center1(const char *t1);
void UI_Center2(const char *t1, const char *t2);
void UI_Center3(const char *t1, const char *t2, const char *t3);
void UI_Tip(const char *text);
void UI_Push(void);

s16 UI_Rotate(void);
u8  UI_Key(void);
u8  UI_KeyDown(void);
void UI_Tick(void);
u8  UI_TakeRedraw(void);
u8  UI_InTick(void);

s16 UI_Menu(const char **items, u8 n, u8 *pSel);
s16 UI_MenuHold(const char **items, u8 n, u8 *pSel, u8 *longSel);
u8  UI_Confirm(const char *l1, const char *l2);
void UI_PageParam(u8 grp);

u8   UI_PageBoxStep(void);

void UI_ShowTestExit(u8 mode);

void UI_ShowBootSplash(void);
void UI_HideBootSplash(void);
u8   UI_IsLiveDebug(void);
void UI_GotoMain(void);
void UI_EStop(void);
void UI_ShowBoxSelect(void);
void UI_HideBoxSelect(void);
void UI_RefreshNow(void);
u8   UI_CurrentPage(void);

u8   UI_PageId(void);

u8   UI_PageSel(void);
u8   UI_PageGrp(void);
u8   UI_PageValCnt(void);
u8   UI_PageParamCount(void);
u8   UI_PageLiveIdx(void);
u8   UI_IsEditing(void);
u8   UI_MenuActive(void);

u8  UI_ConsumeSaveParam(void);
u8  UI_ConsumeReset(void);
u8  UI_ConsumeReset2(void);
u8  UI_ConsumeTestExit(void);
u8  UI_ConsumeStopAll(void);
s16 UI_ConsumeBoxSelect(void);

#endif
