#include "Ui/Ui.h"
#include "Core/Time.h"
#include "Modules/Display/OLED.h"
#include "Modules/Encoder.h"
#include "Modules/Params.h"
#include "Modules/Servo.h"
#include "Modules/Belt.h"
#include "Modules/Sensor.h"
#include "Core/PinMap.h"
#include "Modules/Safe.h"
#include "App/ParamSet.h"
#include "App/Flow.h"
#include "App/PowerUp.h"
#include "App/Cmd.h"
#include "Bsp/Bsp.h"
#include "Core/ProtoRx.h"

#define PAGE_IDLE    0u
#define PAGE_RUN     1u
#define PAGE_BOX     2u
#define PAGE_BOOT    3u

#define PG_MAIN    0u
#define PG_SERVO   1u
#define PG_BELT    2u
#define PG_SENSOR  3u
#define PG_PARAM   4u

#define PG_TEST    6u
#define PG_CONFIRM 7u
#define PG_RUN     8u
#define PG_BOX     9u
#define PG_BOOT    10u
#define PG_SENSLIVE 11u

#define DOUBLE_MS    400u
#define BLINK_MS     300u
#define MENU_ROWS    4u
#define HOLD_ROWS    3u
#define BOX_W_WIDE   120u
#define ROW_H        16u
#define BOX_X        4u
#define BOX_W        104u

#define UI_LIVE_MIN_WAIT_MS   100u
#define UI_NUM_4DIGIT_MIN     1000u
#define UI_NUM_3DIGIT_MIN     100u
#define UI_NUM_2DIGIT_MIN     10u
#define UI_MICRO_TAB_CNT      5u
#define UI_BOX_COUNT          6u
/* ѡ��ҳ��ȡ�������ѡ 1~6 */

#define GRP_INIT       0
#define GRP_BOX1       1
#define GRP_BOX2       2
#define GRP_BOX3       3
#define GRP_BOX4       4
#define GRP_BOX5       5
#define GRP_BOX6       6
#define GRP_LUMP       7
#define GRP_SERVO_SPD  8
#define GRP_BELT1      9
#define GRP_BELT2      10
#define GRP_SENS_UP    11
#define GRP_SENS_DOWN  12

#define K_ANGLE     0
#define K_SRV_SPD   1
#define K_BLT_SPD   2
#define K_DELAY     3
#define K_ENUM      4

#define K_MICRO     7

static const char *MI[]  = { "���", "���ʹ�", "������", "����", "��λ" };
static const char *SI[]  = { "��ʼ", "����1", "����2", "����3", "����4", "����5", "����6", "����", "�ٶ�", "����" };
static const char *BI[]  = { "�������1", "�������2", "����" };
static const char *NI[]  = { "�Ϲ�紫����", "�¹�紫����", "ʵʱ����", "����" };
static const char *TI[]  = { "�����", "������������", "������������", "������ѭ��", "�������", "�ָ�Ĭ�ϲ���", "����" };
static const char *TE[]  = { "�����", "������������", "������������" };
static const char *CI[]  = { "��", "��" };
static const char *BSI[] = { "��1", "��2", "��3", "��4", "��5", "��6" };

#define MAIN_CNT    5u
#define SERVO_CNT   10u
#define BELT_CNT    3u
#define SENS_CNT    4u
#define SENS_LIVE   2u
#define SENS_LIVE_R 3u
#define TEST_CNT    7u
#define BOXSEL_CNT  6u

STATIC_ASSERT(ARRAY_LEN(MI)  == MAIN_CNT,   ui_mi_cnt);
STATIC_ASSERT(ARRAY_LEN(SI)  == SERVO_CNT,  ui_si_cnt);
STATIC_ASSERT(ARRAY_LEN(BI)  == BELT_CNT,   ui_bi_cnt);
STATIC_ASSERT(ARRAY_LEN(NI)  == SENS_CNT,   ui_ni_cnt);
STATIC_ASSERT(ARRAY_LEN(TI)  == TEST_CNT,   ui_ti_cnt);
STATIC_ASSERT(ARRAY_LEN(BSI) == BOXSEL_CNT, ui_bsi_cnt);

STATIC_ASSERT(ARRAY_LEN(TE)  >= 3u,         ui_te_rows);

static u8  bootSplash  = 0;
static u8  runPage     = 0;
static u8  runSig      = 0xFFu;
static u8  boxSig      = 0xFFu;
static u8  runMode     = 0;
static u8  boxShow     = 0;
static u8  boxSelRes   = 0;
static u8  blinkOn     = 0;
static u32 blinkT      = 0;
static u8  blinkDirty  = 0;
static u8  dirty       = 1;
static u8  liveDebug   = 0;
static u8  menuActive  = 0;
static u8  pageGrp     = 0;
static u8  pageSel     = 0;
static u8  pageEditing = 0;
static u8  editDigit   = 0;
static u8  boxSelIdx   = 0;
static u8  pageRedraw  = 0;
static u8  pageId      = PG_MAIN;
static u8  uiInTick    = 0;

static u8  reqReset     = 0;
static u8  reqReset2    = 0;
static u8  reqSaveParam = 0;
static u8  reqTestExit  = 0;
static u8  reqStopAll   = 0;

static const u8 LdSeqOpen[3][2]  = { { 0, 1 }, { 1, 1 }, { 2, 1 } };
static const u8 LdSeqClose[3][2] = { { 2, 0 }, { 1, 0 }, { 0, 0 } };

STATIC_ASSERT(ARRAY_LEN(LdSeqOpen)  >= 3u, ui_ld_open_rows);
STATIC_ASSERT(ARRAY_LEN(LdSeqClose) >= 3u, ui_ld_close_rows);
static const u8 (*ldSeq)[2] = 0;
static u8   ldLen     = 0;
static u8   ldStep    = 0;
static u8   ldStarted = 0;
static u32  ldWaitT   = 0;
static u8   ldRunning = 0;

#ifdef SIM_BUILD

unsigned SimCnt_UIBoxShow = 0, SimCnt_UIBoxHide = 0;
unsigned SimCnt_TestExitShow = 0, SimCnt_TestExitConsumed = 0;
unsigned SimCnt_Refresh = 0;
#endif

static void PageBootTick(void);
static void PageRunTick(void);
static void LiveStop(void);
static void LiveTask(void);
static void LiveApplyValue(u8 liveOn);
static void DrawParamPage(u8 sel, u8 top, u8 editing, u8 live);

static SysParams* D(void) { return Params_Draft(); }

static u8 CnW(const char *s)
{
    u8 w = 0;
    while (*s)
    {
        if ((u8)(*s) < 0x80) { w += 8;  s++; }
        else                 { w += 16; s += 2; }
    }
    return w;
}

static u8 CnCol(const char *s)
{
    return (u8)((128u - CnW(s)) / 16u + 1u);
}

static const char* GrpName(u8 g)
{
    switch (g)
    {
        case GRP_INIT:      return "��ʼ";
        case GRP_BOX1:      return "����1";
        case GRP_BOX2:      return "����2";
        case GRP_BOX3:      return "����3";
        case GRP_BOX4:      return "����4";
        case GRP_BOX5:      return "����5";
        case GRP_BOX6:      return "����6";
        case GRP_LUMP:      return "����";
        case GRP_SERVO_SPD: return "�ٶ�";
        case GRP_BELT1:     return "����1";
        case GRP_BELT2:     return "����2";
        case GRP_SENS_UP:   return "�Ϲ��";
        case GRP_SENS_DOWN: return "�¹��";

    }
    return "";
}

static u8 ValCnt(void)
{
    if (pageGrp == GRP_BELT1 || pageGrp == GRP_BELT2) return 3;

    if (pageGrp == GRP_INIT) return 3;
    if ((pageGrp >= GRP_BOX1) && (pageGrp <= GRP_BOX6)) return 1;
    if (pageGrp == GRP_LUMP) return 2;
    if (pageGrp == GRP_SERVO_SPD) return 3;
    if (pageGrp == GRP_SENS_UP)   return 1;
    if (pageGrp == GRP_SENS_DOWN) return 1;
    return 1;
}
static u8 LiveIsServoGroup(void) { return (u8)((pageGrp <= GRP_LUMP) ? 1u : 0u); }
static u8 LiveIsBeltGroup(void)  { return (u8)((pageGrp == GRP_BELT1) || (pageGrp == GRP_BELT2)); }
static u8 LiveBeltIdx(void)      { return (u8)((pageGrp == GRP_BELT2) ? 1 : 0); }
static u8 HasLiveRow(void)       { return (u8)((LiveIsServoGroup() || LiveIsBeltGroup()) ? 1u : 0u); }
static u8 LiveIdx(void)          { return (u8)(HasLiveRow() ? ValCnt() : 0xFFu); }
static u8 BackIdx(void)          { return (u8)(ValCnt() + HasLiveRow()); }
static u8 ParamCount(void)       { return (u8)(ValCnt() + HasLiveRow() + 1u); }

static const char* SubName(u8 g, u8 sub)
{
    if (sub == BackIdx()) return "����";
    if (sub == LiveIdx()) return "ʵʱ����";

    switch (g)
    {
        case GRP_INIT:
            if (sub == 0u) return "��1��";
            if (sub == 1u) return "��2��";
            return "����";
        case GRP_BOX1: case GRP_BOX2: case GRP_BOX3:
        case GRP_BOX4: case GRP_BOX5: case GRP_BOX6:
            return "��1��";
        case GRP_LUMP:
            return (sub == 0u) ? "���2" : "����";
        case GRP_SERVO_SPD:
            if (sub == 0u) return "���1";
            if (sub == 1u) return "���2";
            return "����";
        case GRP_BELT1: case GRP_BELT2:
            if (sub == 0u) return "�ٶ�";
            return (sub == 1u) ? "ת��" : "ϸ��";
        case GRP_SENS_UP:
            (void)sub; return "�ӳ�";
        case GRP_SENS_DOWN:
            (void)sub; return "�ӳ�";
    }
    return "";
}

static u8 PageServoCh(u8 sub)
{
    if ((pageGrp >= GRP_BOX1) && (pageGrp <= GRP_BOX6)) return (u8)SRV_ARM1;
    if (pageGrp == GRP_LUMP) return (u8)((sub == 0u) ? SRV_ARM2 : SRV_TRAY);
    return sub;
}

static s16* CurVal(u8 sub)
{
    if (sub >= ValCnt()) return 0;

    switch (pageGrp)
    {
        case GRP_INIT:
        case GRP_BOX1: case GRP_BOX2: case GRP_BOX3:
        case GRP_BOX4: case GRP_BOX5: case GRP_BOX6:
        case GRP_LUMP:
            return Pos_At(D()->pos, pageGrp, PageServoCh(sub));
        case GRP_SERVO_SPD:
            return &D()->runSpeed[sub];
        case GRP_BELT1:
            if (sub == 0u) return &D()->beltSpeed[0];
            return (sub == 1u) ? &D()->beltDir[0] : &D()->beltMicro[0];
        case GRP_BELT2:
            if (sub == 0u) return &D()->beltSpeed[1];
            return (sub == 1u) ? &D()->beltDir[1] : &D()->beltMicro[1];
        case GRP_SENS_UP:   (void)sub; return &D()->sensDelay[0];
        case GRP_SENS_DOWN: (void)sub; return &D()->sensDelay[1];
    }
    return 0;
}

static u8 ValKind(u8 sub)
{
    switch (pageGrp)
    {
        case GRP_INIT:
        case GRP_BOX1: case GRP_BOX2: case GRP_BOX3:
        case GRP_BOX4: case GRP_BOX5: case GRP_BOX6:
        case GRP_LUMP:
            return K_ANGLE;
        case GRP_SERVO_SPD:
            return K_SRV_SPD;
        case GRP_BELT1: case GRP_BELT2:
            if (sub == 0u) return K_BLT_SPD;
            return (sub == 1u) ? K_ENUM : K_MICRO;
        case GRP_SENS_UP:   (void)sub; return K_DELAY;
        case GRP_SENS_DOWN: (void)sub; return K_DELAY;
    }
    return K_ANGLE;
}

static void ValRange(u8 sub, s16 *mn, s16 *mx)
{
    switch (ValKind(sub))
    {
        case K_ANGLE:
        {
            u8 ch = PageServoCh(sub);

            Params_ServoRangeOf(D(), ch, mn, mx);
            break;
        }
        case K_SRV_SPD:
            Params_Range((u8)(PARAM_RUN_BASE + sub), mn, mx);
            break;
        case K_BLT_SPD: Params_Range((u8)PARAM_BELT, mn, mx); break;
        case K_MICRO:   *mn = 0;              *mx = 32;        break;
        case K_DELAY:
            Params_Range((u8)((pageGrp == GRP_SENS_UP) ? PARAM_DELAY_UP : PARAM_DELAY_DOWN), mn, mx);
            break;
        default:        *mn = 0; *mx = 1; break;
    }
}

static void NumLayout(u8 sub, u8 *cs, u8 *dg)
{
    switch (ValKind(sub))
    {
        case K_ANGLE:   *cs = 9u; *dg = 2u; break;

        case K_SRV_SPD: *cs = 7u; *dg = 3u; break;

        case K_BLT_SPD: *cs = 8u; *dg = 2u; break;
        case K_DELAY:   *cs = 8u; *dg = 4u; break;
        default:        *cs = 8u; *dg = 2u; break;
    }
}

static const char* EnumText(s16 v)
{
    if (pageGrp == GRP_BELT1 || pageGrp == GRP_BELT2)
        return v ? "��ת" : "��ת";
    return v ? "�½���" : "������";
}

void UI_Clear(void)
{
    OLED_Clear();
}

void UI_List(const char **items, u8 n)
{
    UI_ListN(items, n, 0u, MENU_ROWS);
}

void UI_ListFrom(const char **items, u8 n, u8 from)
{
    UI_ListN(items, n, from, MENU_ROWS);
}

void UI_ListN(const char **items, u8 n, u8 from, u8 rows)
{
    u8 i;

    if (rows == 0u || rows > MENU_ROWS) rows = MENU_ROWS;

    for (i = 0u; i < rows; i++)
    {
        u8 idx = (u8)(from + i);
        if (idx >= n) break;
        OLED_ShowCnStr((u8)(i + 1u), 2u, items[idx]);
    }
}

void UI_Box(u8 row, u8 blink)
{
    UI_BoxW(row, BOX_W, blink);
}

void UI_BoxW(u8 row, u8 w, u8 blink)
{
    u8 y;

    if (row < 1u || row > MENU_ROWS) return;
    if (w > 124u) w = 124u;

    y = (u8)((row - 1u) * ROW_H);

    if (!blink) return;
    OLED_DrawRect(BOX_X, y, w, ROW_H);
}

void UI_Center1(const char *t1)
{
    OLED_ShowCnStr(2u, CnCol(t1), t1);
}

void UI_Center2(const char *t1, const char *t2)
{
    OLED_ShowCnStr(2u, CnCol(t1), t1);
    OLED_ShowCnStr(3u, CnCol(t2), t2);
}

void UI_Center3(const char *t1, const char *t2, const char *t3)
{
    OLED_ShowCnStr(1u, CnCol(t1), t1);
    OLED_ShowCnStr(2u, CnCol(t2), t2);
    OLED_ShowCnStr(3u, CnCol(t3), t3);
}

void UI_Tip(const char *text)
{
    OLED_ShowCnStr(4u, 3u, text);
}

void UI_Push(void)
{
    OLED_Refresh();
}

s16 UI_Rotate(void)
{
    return Enc_TakeRotate();
}

u8 UI_Key(void)
{
    return Enc_TakeEvent();
}

u8 UI_KeyDown(void)
{
    return Enc_KeyDown();
}

void UI_Tick(void)
{
    uiInTick = 1u;

    Sensor_Task();
    Servo_Task();
    LiveTask();
    Cmd_Task();
    ParamSet_Task();
    Enc_Task();

    if (TIME_ELAPSED(blinkT, BLINK_MS))
    {
        blinkT = Time_Now();
        blinkOn = (u8)(!blinkOn);
        blinkDirty = 1u;
    }

    if (bootSplash)      PageBootTick();
    else if (boxShow)
    {

    }
    else if (runPage)    { PageRunTick(); dirty = 0u; }

    if (dirty)
    {
        dirty = 0u;
        UI_Push();
    }
    else if (OLED_RefreshPending() != 0u)
    {
        OLED_Refresh();
    }

    if (bootSplash && (UI_Key() == 2u)) reqStopAll = 1u;

    uiInTick = 0u;
}

u8 UI_InTick(void)
{
    return uiInTick;
}

u8 UI_TakeRedraw(void)
{
    u8 v = pageRedraw;
    pageRedraw = 0u;
    return v;
}

static void WaitStep(void)
{

    Bsp_WdgFeed();
    Proto_Poll();
    UI_Tick();
    Flow_IdleService();
}

static void PageBootTick(void)
{
    OLED_Clear();
    UI_Center1("�Լ츴λ��");
    UI_Push();
}

static void PageRunTick(void)
{
    u8 sig;

    sig  = Sensor_Active((u8)SENS_UP);
    sig |= (u8)(Sensor_Active((u8)SENS_DOWN) << 1);
    sig |= (u8)((Belt1_IsRunning() != 0u) ? 0x04u : 0u);
    sig |= (u8)((Belt2_IsRunning() != 0u) ? 0x08u : 0u);
    if (runMode != 0u) sig |= 0x10u;

    if (sig == runSig)
    {
        if (UI_Key() == 2u) reqTestExit = 1u;
        return;
    }
    runSig = sig;

    OLED_Clear();

    if (runMode == 0u)
    {
        UI_Center2("����������", "ȡ��");
    }
    else
    {
        UI_Center3(TE[runMode - 1u], "������", "ȡ��");
    }

    OLED_DrawRect(40u, 32u, 48u, ROW_H);
    if (blinkOn) OLED_DrawRect(41u, 33u, 46u, (u8)(ROW_H - 2u));

    OLED_ShowString(4u, 1u, "U");
    OLED_ShowChar(4u, 2u, (char)('0' + Sensor_Active((u8)SENS_UP)));
    OLED_ShowString(4u, 4u, "D");
    OLED_ShowChar(4u, 5u, (char)('0' + Sensor_Active((u8)SENS_DOWN)));

    OLED_ShowString(4u, 11u, "D");
    OLED_ShowString(4u, 12u, "1");
    OLED_ShowChar(4u, 13u, (char)('0' + (Belt1_IsRunning() ? 1u : 0u)));
    OLED_ShowString(4u, 14u, "D");
    OLED_ShowString(4u, 15u, "2");
    OLED_ShowChar(4u, 16u, (char)('0' + (Belt2_IsRunning() ? 1u : 0u)));

    if (UI_Key() == 2u) reqTestExit = 1u;
}

u8 UI_PageBoxStep(void)
{
    u8 top;
    u8 sig;

    Proto_Poll();

    top = 0u;
    if (boxSelIdx >= HOLD_ROWS) top = (u8)(boxSelIdx - (HOLD_ROWS - 1u));

    sig = (u8)(boxSelIdx ^ (u8)(top << 4));
    if (blinkOn != 0u) sig |= 0x80u;

    if (sig != boxSig)
    {
        boxSig = sig;
        OLED_Clear();
        UI_ListN(BSI, BOXSEL_CNT, top, HOLD_ROWS);
        UI_Tip("ѡ��");
        UI_BoxW((u8)(boxSelIdx - top + 1u), BOX_W_WIDE, blinkOn);
        UI_Push();
    }

    {
        s16 r = UI_Rotate();
        if (r != 0)
        {
            s16 s = (s16)boxSelIdx + r;
            while (s < 0) s += (s16)BOXSEL_CNT;
            while (s >= (s16)BOXSEL_CNT) s -= (s16)BOXSEL_CNT;
            boxSelIdx = (u8)s;
        }
    }

    if (UI_Key() == 1u)
    {
        boxSelRes = (u8)(boxSelIdx + 1u);
    }

    return (u8)((boxSelRes != 0u) ? 1u : 0u);
}

static u8 LiveServoSpeed(void)
{
    u8  ch = PageServoCh(pageSel);
    s16 v  = D()->runSpeed[ch];

    if (v < (s16)RUN_SPEED_MIN) v = (s16)RUN_SPEED_MIN;
    if (v > (s16)RUN_SPEED_MAX) v = (s16)RUN_SPEED_MAX;
    return (u8)v;
}

static void LiveBeltApply(void)
{
    u8 idx = LiveBeltIdx();

    if (idx == 0u)
    {
        (void)Belt1_RunDir((u8)D()->beltSpeed[0], (u8)D()->beltDir[0]);
    }
    else
    {
        (void)Belt2_RunDir((u8)D()->beltSpeed[1], (u8)D()->beltDir[1]);
    }
}

static void LiveStart(void)
{
    if (!LiveIsServoGroup() && !LiveIsBeltGroup()) return;
    if (Flow_Running()) return;

    if (PowerUp_Busy() || Flow_HomeActive())
    {
        reqStopAll = 1u;
        return;
    }

    liveDebug = 1u;

    reqStopAll = 1u;

    if (LiveIsServoGroup())
    {
        u8 n = ValCnt();

        if (n > 3u) n = 3u;
        ldSeq = LdSeqOpen; ldLen = n; ldStep = 0u; ldStarted = 0u; ldRunning = 1u;
    }
    else
    {
        ldRunning = 2u;
    }
}

static void LiveStop(void)
{

    IGN_OK(UI_ConsumeStopAll());

    if (Params_DraftDirty()) ParamSet_ReqCommit();

    if (!LiveIsServoGroup() && !LiveIsBeltGroup()) { liveDebug = 0u; return; }

    liveDebug = 0u;

    if (LiveIsServoGroup())
    {
        u8 n = ValCnt();

        if (n > 3u) n = 3u;
        ldSeq = LdSeqClose; ldLen = n; ldStep = 0u; ldStarted = 0u; ldRunning = 1u;
    }
    {
        if (LiveBeltIdx() == 0u) (void)Belt1_Stop();
        else                     (void)Belt2_Stop();
    }
}

static void LiveApplyValue(u8 liveOn)
{
    if (!liveDebug)
    {

        if (liveOn == 0u) return;
        LiveStart();
        if (!liveDebug) return;
    }
    if (Flow_Running() || Flow_TestActive() || Flow_HomeActive() || PowerUp_Busy()) return;
    if (pageSel >= ValCnt()) return;

    if (LiveIsServoGroup())
    {
        u8  ch = PageServoCh(pageSel);
        s16 tg = *Pos_At(D()->pos, pageGrp, ch);

        ldRunning = 0u;
        Servo_Motor(PIN_PCA_SDA, ch, tg, LiveServoSpeed());
        Flow_HomedMark(0u);
    }
    else if (LiveIsBeltGroup())
    {
        LiveBeltApply();
    }
}

static void LiveTask(void)
{
    u8  ch, pos;
    s16 angv;

    if ((Flow_Running() || Flow_TestActive() || Flow_HomeActive() || PowerUp_Busy()) &&
        ((ldRunning != 0u) || (ldSeq != 0)))
    {
        ldRunning = 0u; ldStarted = 0u; return;
    }

    if (ldRunning == 2u)
    {
        ldRunning = 0u;
        if (liveDebug && LiveIsBeltGroup()) LiveBeltApply();
        return;
    }

    if (!ldRunning || !ldSeq) return;
    if (ldStep >= ldLen)
    {
        ldRunning = 0u;
        if (ldSeq == LdSeqClose) Flow_HomedMark(1u);
        return;
    }
    if (!LiveIsServoGroup()) { ldRunning = 0u; return; }

    pos = ldSeq[ldStep][0];
    if (pos >= ValCnt()) { ldStep++; ldStarted = 0u; return; }
    ch   = PageServoCh(pos);
    angv = (ldSeq[ldStep][1] == 0u) ? D()->pos[POS_INIT][ch]
                                    : *Pos_At(D()->pos, pageGrp, ch);

    if (!ldStarted)
    {
        u32 ms;

        Servo_Motor(PIN_PCA_SDA, ch, angv, LiveServoSpeed());
        if (ldSeq != LdSeqClose) Flow_HomedMark(0u);

        ms = (u32)Servo_MoveMs(ch, angv, LiveServoSpeed());
        if (ms < UI_LIVE_MIN_WAIT_MS) ms = UI_LIVE_MIN_WAIT_MS;

        ldStarted = 1u;
        ldWaitT = Time_Now() + ms;
        return;
    }

    if (!Servo_Arrived(ch)) return;
    if (!TIME_DUE(ldWaitT)) return;

    ldStep++;
    ldStarted = 0u;
}

static s16 MicNext(s16 v, s16 dir)
{
    static const s16 tab[UI_MICRO_TAB_CNT] = { 0, 4, 8, 16, 32 };
    u8 i, cur = 0u;

    for (i = 0; i < UI_MICRO_TAB_CNT; i++) if (tab[i] == v) { cur = i; break; }
    if (dir > 0) return tab[(u8)((cur + 1u) % UI_MICRO_TAB_CNT)];
    return tab[(u8)((cur + UI_MICRO_TAB_CNT - 1u) % UI_MICRO_TAB_CNT)];
}

static void DrawValueRow(u8 row, u8 sub, u8 hiDigit)
{
    u8  k = ValKind(sub);
    u8  col = 8u;
    u8  cs, dg, dcol;
    s16 *pp = CurVal(sub);
    s16 v;

    if (!pp) return;
    v = *pp;

    if (k == K_ENUM)  { OLED_ShowCnStr(row, col, EnumText(v)); return; }

    if (k == K_MICRO) { cs = 7u; dg = 3u; }
    else              NumLayout(sub, &cs, &dg);

    switch (k)
    {
        case K_ANGLE:
        {

            u8 dgA = (u8)(((v >= 100) || (v <= -100)) ? 3u : 2u);

            OLED_ShowSignedNum(row, col, (s32)v, dgA);
            OLED_ShowCnStr(row, (u8)(col + 1u + dgA), "��");
            break;
        }
        case K_SRV_SPD:

            OLED_ShowNum(row, cs, (u32)v, 3u);
            OLED_ShowCnStr(row, (u8)(cs + 3u), "��/��");
            break;
        case K_BLT_SPD:
            OLED_ShowNum(row, cs, (u32)v, 2u);
            OLED_ShowCnStr(row, (u8)(cs + 2u), "����/��");
            break;
        case K_DELAY:
            {
                u8 dg2 = (u8)((v >= UI_NUM_4DIGIT_MIN) ? 4u : (v >= UI_NUM_3DIGIT_MIN) ? 3u : (v >= UI_NUM_2DIGIT_MIN) ? 2u : 1u);
                OLED_ShowNum(row, (u8)(cs + 4u - dg2), (u32)v, dg2);
            }
            OLED_ShowCnStr(row, (u8)(cs + 4u), "����");
            break;
        case K_MICRO:

            if (v == 0) { OLED_ShowCnStr(row, col, "Ĭ��"); }
            else
            {
                u8 dg3 = (u8)((v >= UI_NUM_3DIGIT_MIN) ? 3u : (v >= UI_NUM_2DIGIT_MIN) ? 2u : 1u);
                OLED_ShowNum(row, (u8)(cs + 3u - dg3), (u32)v, dg3);
            }
            break;
        default:
            break;
    }

    if (hiDigit != 0xFFu)
    {
        s32 a = (v < 0) ? -(s32)v : (s32)v;
        u8  j, d;
        u8  dgH = dg;

        if (k == K_ANGLE)
        {
            dgH = (u8)(((v >= 100) || (v <= -100)) ? 3u : 2u);
        }

        dcol = (u8)(cs + dgH - 1u - hiDigit);
        for (j = 0u; j < hiDigit; j++) a /= 10;
        d = (u8)(a % 10);

        OLED_FillRect((u8)((dcol - 1u) * 8u), (u8)((row - 1u) * ROW_H), 8u, ROW_H);
        OLED_ShowCharInv(row, dcol, (char)('0' + d));
    }
}

static void DrawParamRow(u8 row, u8 idx, u8 editing, u8 sel, u8 live)
{
    if (idx >= ParamCount()) return;

    if (idx == LiveIdx())
    {
        OLED_ShowCnStr(row, 2u, (live != 0u) ? "ֹͣʵʱ" : "ʵʱ����");
        return;
    }
    if (idx == BackIdx())
    {
        OLED_ShowCnStr(row, 2u, "����");
        return;
    }

    OLED_ShowCnStr(row, 2u, SubName(pageGrp, idx));

    DrawValueRow(row, idx, (u8)((editing && (sel == idx)) ? editDigit : 0xFFu));
}

static void DrawGrpName(void)
{
    const char *g = GrpName(pageGrp);
    u8 w = (u8)(CnW(g) / 8u);

    if (w == 0u || w >= 15u) return;
    OLED_ShowCnStr(4u, (u8)(16u - w), g);
}

static void DrawParamPage(u8 sel, u8 top, u8 editing, u8 live)
{
    u8 i;

    OLED_Clear();

    for (i = 0u; i < MENU_ROWS; i++)
    {
        DrawParamRow((u8)(i + 1u), (u8)(top + i), editing, sel, live);
    }

    DrawGrpName();
    if (!editing) UI_BoxW((u8)(sel - top + 1u), BOX_W_WIDE, blinkOn);
    UI_Push();
}

static void DrawParamRowNow(u8 sel, u8 top, u8 editing, u8 live)
{
    u8 rrow = (u8)(sel - top + 1u);

    OLED_ClearRect(0u, (u8)((rrow - 1u) * ROW_H), 128u, ROW_H);
    DrawParamRow(rrow, sel, editing, sel, live);

    if (rrow == MENU_ROWS) DrawGrpName();
    if (!editing) UI_BoxW(rrow, BOX_W_WIDE, blinkOn);
    OLED_MarkRow(rrow);
    UI_Push();
}

typedef struct
{
    u8  sel;
    u8  top;
    u8  need;
    u8  editing;
    u32 lastShort;
    u8  liveOn;
} ParamPageCtx;

static void PageParam_Tick(ParamPageCtx* c)
{
    WaitStep();

    if (UI_TakeRedraw() != 0u) { blinkDirty = 0u; c->need = 1u; }
    else if (blinkDirty != 0u)
    {
        blinkDirty = 0u;
        if (c->need == 0u)
        {
            if (c->liveOn != 0u) c->need = 1u;
            else              DrawParamRowNow(c->sel, c->top, c->editing, c->liveOn);
        }
    }

    if (c->sel < c->top)                     c->top = c->sel;
    if (c->sel >= (u8)(c->top + MENU_ROWS))  c->top = (u8)(c->sel - (MENU_ROWS - 1u));

    if (c->need)
    {
        c->need = 0u;
        DrawParamPage(c->sel, c->top, c->editing, c->liveOn);
    }

}

static void PageParam_Edit(ParamPageCtx* c)
{
    s16 *p = CurVal(c->sel);
    s16 r  = UI_Rotate();
    u8  k  = UI_Key();

    if (p && r != 0)
    {
        u8 kind = ValKind(c->sel);

        if (kind == K_ENUM)
        {
            *p = (s16)(*p ? 0 : 1);
        }
        else
        {
            s16 mn, mx, step;

            ValRange(c->sel, &mn, &mx);

            if (kind == K_DELAY)      step = (s16)SENS_DELAY_STEP;
            else                      step = (s16)(editDigit ? 10 : 1);
            if (kind == K_MICRO)
            {
                *p = MicNext(*p, (s16)((r > 0) ? 1 : -1));
            }
            else
            {
                *p = (s16)(*p + (s16)(r * step));
                if (*p > mx) *p = mx;
                if (*p < mn) *p = mn;
            }
            LiveApplyValue(c->liveOn);
        }

        {
            u8 rrow = (u8)(c->sel - c->top + 1u);

            OLED_ClearRect(56u, (u8)((rrow - 1u) * ROW_H), 72u, ROW_H);
            DrawValueRow(rrow, c->sel, editDigit);
            OLED_MarkRow(rrow);
        }

    }

    if (k == 2u)
    {
        c->editing = 0u;
        pageEditing = 0u;
        LiveApplyValue(c->liveOn);
        ParamSet_ReqCommit();
        c->need = 1u;
    }
    else if (k == 1u)
    {
        if (c->lastShort != 0u && !TIME_ELAPSED(c->lastShort, DOUBLE_MS))
        {
            c->lastShort = 0u;
            c->editing = 0u;
            pageEditing = 0u;
            LiveApplyValue(c->liveOn);
            ParamSet_ReqCommit();
        }
        else
        {
            editDigit = (u8)(!editDigit);
            c->lastShort = Time_Now();
        }
        c->need = 1u;
    }
}

static void PageParam_Rotate(ParamPageCtx* c)
{
    s16 r = UI_Rotate();
    if (r != 0)
    {
        s16 s = (s16)c->sel + r;
        u8  cnt = ParamCount();
        while (s < 0) s += (s16)cnt;
        while (s >= (s16)cnt) s -= (s16)cnt;
        c->sel = (u8)s;
        c->need = 1u;
    }
}

static u8 PageParam_Key(ParamPageCtx* c, u8 saved)
{
    u8 k = UI_Key();

    if (k == 2u)
    {
        if (liveDebug) LiveStop();
        c->liveOn = 0u;
        ParamSet_ReqCommit();
        pageId = saved;
        return 1u;
    }

    if (k == 1u)
    {
        if (c->sel == BackIdx())
        {
            if (liveDebug) LiveStop();
            c->liveOn = 0u;
            ParamSet_ReqCommit();
            pageEditing = 0u;
            pageId = saved;
            return 1u;
        }
        if (HasLiveRow() && c->sel == LiveIdx())
        {

            if (c->liveOn == 0u)
            {
                c->editing = 0u;
                pageEditing = 0u;
                LiveStart();
                if (liveDebug != 0u) c->liveOn = 1u;
            }
            else
            {
                LiveStop();
                c->liveOn = 0u;
            }
            c->need = 1u;
        }
        else
        {

            {
                u8 kind = ValKind(c->sel);

                if (kind == K_DELAY)
                {
                    s16 *pv = CurVal(c->sel);
                    u8   id = (u8)((pageGrp == GRP_SENS_UP) ? PARAM_DELAY_UP : PARAM_DELAY_DOWN);

                    if (pv) *pv = Params_Limit(id, *pv);
                }
            }
            pageSel = c->sel;
            c->editing = 1u;
            pageEditing = 1u;
            editDigit = 0u;
            c->lastShort = 0u;
            c->need = 1u;
        }
    }

    return 0u;
}

void UI_PageParam(u8 grp)
{
    ParamPageCtx c;
    u8 saved = pageId;

    c.sel = 0u;
    c.top = 0u;
    c.need = 1u;
    c.editing = 0u;
    c.lastShort = 0u;
    c.liveOn = 0u;

    pageId  = PG_PARAM;
    pageGrp = grp;
    pageSel = 0u;
    editDigit = 0u;
    Params_DraftSync();

    for (;;)
    {
        PageParam_Tick(&c);

        if (c.editing != 0u)
        {
            PageParam_Edit(&c);
            continue;
        }

        PageParam_Rotate(&c);

        if (PageParam_Key(&c, saved) != 0u) return;
    }
}

s16 UI_Menu(const char **items, u8 n, u8 *pSel)
{
    u8 sel = (pSel ? *pSel : 0u);

    u8 top = 0u;
    if (sel >= MENU_ROWS) top = (u8)(sel - (MENU_ROWS - 1u));
    u8 need = 1u;

    if (n == 0u) return -1;

    for (;;)
    {
        WaitStep();
        if (blinkDirty || UI_TakeRedraw()) { blinkDirty = 0u; need = 1u; }

        if (sel < top)                    top = sel;
        if (sel >= (u8)(top + MENU_ROWS)) top = (u8)(sel - (MENU_ROWS - 1u));

        if (need)
        {
            need = 0u;
            UI_Clear();
            UI_ListFrom(items, n, top);
            UI_Box((u8)(sel - top + 1u), blinkOn);
            UI_Push();
        }

        {
            s16 r = UI_Rotate();
            if (r != 0)
            {
                s16 s = (s16)sel + r;
                while (s < 0) s += (s16)n;
                while (s >= (s16)n) s -= (s16)n;
                sel = (u8)s;
                need = 1u;
            }
        }

        if (UI_Key() == 1u)
        {
            if (pSel) *pSel = sel;
            return (s16)sel;
        }
    }
}

static const char* MenuTip(void)
{
    u8 hint = ParamSet_SaveHint();

    if (hint == 1u) return "�����";
    if (hint == 2u) return "����";
    return "����ȷ��";
}

s16 UI_MenuHold(const char **items, u8 n, u8 *pSel, u8 *longSel)
{
    u8 sel = (pSel ? *pSel : 0u);

    u8 top = 0u;
    if (sel >= HOLD_ROWS) top = (u8)(sel - (HOLD_ROWS - 1u));
    u8 need = 1u;

    if (n == 0u) return -1;

    for (;;)
    {
        WaitStep();
        if (blinkDirty || UI_TakeRedraw()) { blinkDirty = 0u; need = 1u; }

        if (sel < top)                     top = sel;
        if (sel >= (u8)(top + HOLD_ROWS))  top = (u8)(sel - (HOLD_ROWS - 1u));

        if (need)
        {
            need = 0u;
            UI_Clear();
            UI_ListN(items, n, top, HOLD_ROWS);
            UI_Tip(MenuTip());
            UI_Box((u8)(sel - top + 1u), blinkOn);
            UI_Push();
        }

        {
            s16 r = UI_Rotate();
            if (r != 0)
            {
                s16 s = (s16)sel + r;
                while (s < 0) s += (s16)n;
                while (s >= (s16)n) s -= (s16)n;
                sel = (u8)s;
                need = 1u;
            }
        }

        {
            u8 k = UI_Key();
            if (k == 2u)
            {
                if (pSel)    *pSel    = sel;
                if (longSel) *longSel = sel;
                return -2;
            }
            if (k == 1u)
            {
                if (pSel) *pSel = sel;
                return (s16)sel;
            }
        }
    }
}

u8 UI_Confirm(const char *l1, const char *l2)
{
    u8 saved = pageId;
    u8 sel = 0u;
    u8 need = 1u;

    pageId = PG_CONFIRM;

    for (;;)
    {
        WaitStep();
        if (blinkDirty || UI_TakeRedraw()) { blinkDirty = 0u; need = 1u; }

        if (need)
        {
            need = 0u;
            UI_Clear();

            OLED_ShowCnStr(1u, CnCol(l1), l1);
            OLED_ShowCnStr(2u, CnCol(l2), l2);
            OLED_ShowCnStr(3u, 3u, CI[0]);
            OLED_ShowCnStr(3u, 8u, CI[1]);

            OLED_DrawRect(8u, 32u, 40u, 16u);
            OLED_DrawRect(56u, 32u, 40u, 16u);
            if (blinkOn)
            {
                u8 bx = sel ? 57u : 9u;
                OLED_DrawRect(bx, 33u, 38u, 14u);
            }
            UI_Push();
        }

        {
            s16 r = UI_Rotate();
            if (r != 0) { sel = (u8)(sel ? 0u : 1u); need = 1u; }
        }

        if (UI_Key() == 1u)
        {
            pageId = saved;
            return (u8)(sel ? 1u : 0u);
        }
    }
}

static void PageServo(void)
{
    static u8 sSel = 0u;
    u8 saved = pageId;

    pageId = PG_SERVO;
    for (;;)
    {
        s16 s = UI_Menu(SI, SERVO_CNT, &sSel);

        if (s < 0 || s == (s16)(SERVO_CNT - 1u)) break;

        if (s == 0)      UI_PageParam(GRP_INIT);
        else if (s <= 6) UI_PageParam((u8)(GRP_BOX1 + (u8)(s - 1)));
        else if (s == 7) UI_PageParam(GRP_LUMP);
        else             UI_PageParam(GRP_SERVO_SPD);

    }
    pageId = saved;
}

static void PageBelt(void)
{
    static u8 sSel = 0u;
    u8 saved = pageId;

    pageId = PG_BELT;
    for (;;)
    {
        s16 s = UI_Menu(BI, BELT_CNT, &sSel);

        if (s < 0 || s == (s16)(BELT_CNT - 1u)) break;
        UI_PageParam((u8)(GRP_BELT1 + (u8)s));
    }
    pageId = saved;
}

static void UI_PageSensLive(void)
{
    u8 saved = pageId;
    u8 shown = 0xFFu;
    u8 first = 1u;
    u8 i;

    pageId = PG_SENSLIVE;
    for (;;)
    {
        u8 v, w, nv, changed;

        WaitStep();

        v  = Sensor_Active((u8)SENS_UP);
        w  = Sensor_Active((u8)SENS_DOWN);
        nv = (u8)((v << 1) | w);

        if (first != 0u)
        {
            first = 0u;
            shown = nv;

            UI_Clear();
            UI_ListN(NI, SENS_CNT, 0u, MENU_ROWS);
            OLED_ShowChar((u8)SENS_LIVE_R, 10u, 'U');
            OLED_ShowChar((u8)SENS_LIVE_R, 11u, (char)('0' + v));
            OLED_ShowChar((u8)SENS_LIVE_R, 12u, 'D');
            OLED_ShowChar((u8)SENS_LIVE_R, 13u, (char)('0' + w));
            UI_Box((u8)SENS_LIVE_R, blinkOn);

            for (i = 0u; i < 8u; i++) UI_Push();
        }
        else
        {
            changed = (u8)(nv ^ shown);

            if (changed != 0u)
            {
                shown = nv;

                if ((changed & 0x2u) != 0u) OLED_ShowChar((u8)SENS_LIVE_R, 11u, (char)('0' + v));
                if ((changed & 0x1u) != 0u) OLED_ShowChar((u8)SENS_LIVE_R, 13u, (char)('0' + w));

                OLED_MarkRow((u8)SENS_LIVE_R);
                UI_Push();
                UI_Push();
            }

            if (blinkDirty != 0u)
            {
                blinkDirty = 0u;

                OLED_ClearRect(BOX_X, (u8)(((u8)SENS_LIVE_R - 1u) * ROW_H), 124u, ROW_H);
                OLED_ShowChar((u8)SENS_LIVE_R, 10u, 'U');
                OLED_ShowChar((u8)SENS_LIVE_R, 11u, (char)('0' + v));
                OLED_ShowChar((u8)SENS_LIVE_R, 12u, 'D');
                OLED_ShowChar((u8)SENS_LIVE_R, 13u, (char)('0' + w));
                UI_Box((u8)SENS_LIVE_R, blinkOn);

                OLED_MarkRow((u8)SENS_LIVE_R);
                UI_Push();
                UI_Push();
            }

            if (UI_TakeRedraw() != 0u) first = 1u;
        }

        {
            u8 k = UI_Key();
            if (k == 1u || k == 2u) break;
        }
    }

    pageId = saved;
}

static void PageSensor(void)
{
    static u8 sSel = 0u;
    u8 saved = pageId;

    pageId = PG_SENSOR;
    for (;;)
    {
        s16 s = UI_Menu(NI, SENS_CNT, &sSel);

        if (s < 0 || s == (s16)(SENS_CNT - 1u)) break;
        if (s == (s16)SENS_LIVE) UI_PageSensLive();
        else                     UI_PageParam((u8)(GRP_SENS_UP + (u8)s));
    }
    pageId = saved;
}

static void PageTest(void)
{
    static u8 sSel = 0u;
    u8 saved = pageId;

    pageId = PG_TEST;
    for (;;)
    {
        u8  ls = 0u;
        s16 s = UI_MenuHold(TI, TEST_CNT, &sSel, &ls);

        if (s < 0 && s != -2)                    { pageId = saved; return; }
        if (s >= 0 && s == (s16)(TEST_CNT - 1u)) { pageId = saved; return; }
        if (s >= 0) continue;

        if (ls <= 2u)
        {
            if (UI_Confirm("��������", TI[ls]) == 1u)
            {
                if (Flow_StartTest((u8)(ls + 1u)) == 1u) Flow_RunTestNow();
            }
        }
        else if (ls == 3u)
        {
            if (UI_Confirm("������ѭ��", "ȷ��?") == 1u)
            {
                if (Flow_Start() == 1u) Flow_RunMainNow();
            }
        }
        else if (ls == 4u)
        {
            if (UI_Confirm("�������", "ȷ��?") == 1u) reqSaveParam = 1u;
        }
        else if (ls == 5u)
        {
            if (UI_Confirm("�ָ�Ĭ��", "�����?") == 1u) reqReset = 1u;
        }
        else
        {

            pageId = saved;
            return;
        }

        continue;
    }
}

void UI_RunStep(void)
{
    s16 s;

    u8 mSel = 0u;

    menuActive = 1u;
    pageId     = PG_MAIN;
    dirty = 1u;
    s = UI_Menu(MI, MAIN_CNT, &mSel);

    switch (s)
    {
        case 0:  PageServo();  break;
        case 1:  PageBelt();   break;
        case 2:  PageSensor(); break;
        case 3:  PageTest();   break;
        case 4:
            if (UI_Confirm("��λ����", "ȷ��?") == 1u) reqReset2 = 1u;
            break;
        default: break;
    }
}

void UI_Init(void)
{
    bootSplash = 0u; runPage = 0u; runMode = 0u; boxShow = 0u; boxSelRes = 0u;
    blinkOn = 0u; blinkT = Time_Now(); blinkDirty = 0u; dirty = 1u;
    liveDebug = 0u; menuActive = 0u; pageGrp = 0u; pageSel = 0u;
    editDigit = 0u; boxSelIdx = 0u;
    reqReset = 0u; reqReset2 = 0u;
    reqSaveParam = 0u; reqTestExit = 0u; reqStopAll = 0u;
    ldSeq = 0; ldLen = 0u; ldStep = 0u; ldStarted = 0u; ldRunning = 0u;

    UI_Clear();
    UI_List(MI, MAIN_CNT);
    UI_Push();
}

void UI_Task(void)
{
    UI_Tick();
}

void UI_ShowTestExit(u8 mode)
{
    if (liveDebug) LiveStop();

    runMode = mode;
    runPage = 1u;
    dirty   = 1u;
    runSig  = 0xFFu;
#ifdef SIM_BUILD
    SimCnt_TestExitShow++;
#endif
}

void UI_ShowBootSplash(void)
{
    bootSplash = 1u;
    dirty      = 1u;
}

void UI_HideBootSplash(void)
{
    bootSplash = 0u;

    (void)UI_Rotate();
    (void)UI_Key();
    pageRedraw = 1u;
    dirty      = 1u;
}

u8 UI_IsLiveDebug(void)
{
    return liveDebug;
}

void UI_GotoMain(void)
{
    if (liveDebug) LiveStop();
    boxShow    = 0u;
    boxSelRes  = 0u;
    runPage    = 0u;
    pageRedraw = 1u;
    dirty      = 1u;
}

void UI_EStop(void)
{

    Belt_StopAll();

    liveDebug = 0u;
    ldRunning = 0u;
    ldStarted = 0u;
    boxSelRes = 0u;
    boxShow   = 0u;
    runPage   = 0u;
    dirty     = 1u;
}

void UI_ShowBoxSelect(void)
{
    boxSig = 0xFFu;
    if (liveDebug) LiveStop();

    boxSelRes = 0u;
    boxSelIdx = 0u;
    boxShow   = 1u;
    dirty     = 1u;
#ifdef SIM_BUILD
    SimCnt_UIBoxShow++;
#endif
}

void UI_HideBoxSelect(void)
{
    if (boxShow)
    {
        boxShow    = 0u;
        boxSelRes  = 0u;
        pageRedraw = 1u;
        dirty      = 1u;
#ifdef SIM_BUILD
        SimCnt_UIBoxHide++;
#endif
    }
}

s16 UI_ConsumeBoxSelect(void)
{
    s16 v;

    if (boxSelRes == 0u) v = -1;
    else                 v = (s16)boxSelRes;

    boxSelRes = 0u;
    return v;
}

void UI_RefreshNow(void)
{
    dirty = 1u;
#ifdef SIM_BUILD
    SimCnt_Refresh++;
#endif
}

u8 UI_CurrentPage(void)
{
    if (bootSplash) return PAGE_BOOT;
    if (boxShow)    return PAGE_BOX;
    if (runPage)    return PAGE_RUN;
    return PAGE_IDLE;
}

u8 UI_PageSel(void)        { return pageSel; }
u8 UI_PageGrp(void)        { return pageGrp; }
u8 UI_PageValCnt(void)     { return ValCnt(); }
u8 UI_PageParamCount(void) { return ParamCount(); }
u8 UI_PageLiveIdx(void)    { return LiveIdx(); }
u8 UI_IsEditing(void)      { return pageEditing; }

u8 UI_PageId(void)
{

    if (bootSplash) return PG_BOOT;
    if (boxShow)    return PG_BOX;
    if (runPage)    return PG_RUN;
    return pageId;
}

u8 UI_MenuActive(void)
{
    return menuActive;
}

u8 UI_ConsumeSaveParam(void)
{
    u8 v = reqSaveParam;
    reqSaveParam = 0u;
    return v;
}

u8 UI_ConsumeReset(void)
{
    u8 v = reqReset;
    reqReset = 0u;
    return v;
}

u8 UI_ConsumeReset2(void)
{
    u8 v = reqReset2;
    reqReset2 = 0u;
    return v;
}

u8 UI_ConsumeTestExit(void)
{
    u8 v = reqTestExit;
    reqTestExit = 0u;
#ifdef SIM_BUILD
    if (v) SimCnt_TestExitConsumed++;
#endif
    return v;
}

u8 UI_ConsumeStopAll(void)
{
    u8 v = reqStopAll;
    reqStopAll = 0u;
    return v;
}
