#include "App/Flow.h"
#include "App/Handshake.h"
#include "App/Cmd.h"
#include "Modules/Belt.h"
#include "Modules/Servo.h"
#include "Modules/Sensor.h"
#include "Modules/Params.h"
#include "Core/PinMap.h"
#include "Modules/Safe.h"
#include "Bsp/Bsp.h"
#include "Modules/Encoder.h"
#include "Core/Time.h"
#include "Ui/Ui.h"
#include "App/PowerUp.h"
#include "Core/Sched.h"
#include "App/ParamSet.h"
#include "Core/ProtoRx.h"

#define T_WAIT_FEED_MS  60000u
#define T_WAIT_FOREVER      0xFFFFFFFFu

#define QV_LOW_MS       10u
#define QV_DUP_MS       4000u

#define QV_KIND_NORMAL  0u
#define QV_KIND_DENSE   1u

#define T_BEAT_MS           10u

#define DENSE_PROBE_MS      30u

#define EXTRA_LOOP_MS       1000u
#define EXTRA_NOMAT_MS      2000u
#define T_MOVE_SLACK_MS     200u
#define BELT_HZ_WARN        2000u
#define MS_PER_SEC          1000u
#define SERVO_MIN_MOVE_MS   20u
#define BOX_NUM             6u

#define T_FWD_MS            1000u
#define T_REV_MS            1000u

static FlowState st           = FLOW_PREP;
static RunMode   mode         = RUN_IDLE;
static u8        homeActive   = 0;
static u8        startPending = 0;

static u8        testPending  = 0;

static u8        testActive   = 0;
static u8        testMode     = 0;
static u8        denseMode    = 0;
static u8        recogValid   = 0;
static u8        selectWait   = 0;
static u8        boxCmd       = 0;
static u8        s_boxPending = 0;
static u8        s_boxWin     = 0;

static void Flow_WatchSensOpen(void);
static void Flow_DensePoll(void);
static u8   Flow_ProbeDense(void);
static void Flow_DenseMode(u8 on);

static void Flow_Enter(FlowState s)
{
    st = s;
    if (s == FLOW_CLASSIFY)
    {
        recogValid = 0;
        selectWait = 0;
        boxCmd     = 0;
        s_boxPending = 0;
        s_boxWin     = 1;
    }
}

static void Flow_SafeExit(u16 code)
{
    u8 i;

    Belt_StopAll();
    for (i = 0u; i < (u8)SRV_NUM; i++) Servo_Hold(i);
    Hs_Init();
    if (code != 0u) Cmd_SendStall(code);
}

static void Flow_FailStop(u16 code, u8 report)
{
    Belt_StopAll();
    Flow_SafeExit(report ? code : 0u);

    denseMode  = 0;
    recogValid = 0;
    selectWait = 0;
    boxCmd     = 0;
    s_boxPending = 0;

    startPending = 0u;
    testPending  = 0u;

    UI_GotoMain();
    Flow_Home();
}

static u8  s_cancel  = 0;
static u16 s_err     = 0;

static u8  s_inMain  = 0;
static u8  s_puHome  = 0;
static u8  s_homeOk  = 0;
static u8  s_homed   = 0;

static u8 Flow_Stopped(void) { return (u8)(((s_cancel != 0u) || (s_err != 0u)) ? 1u : 0u); }

static void Flow_PollCancel(void)
{
    if (UI_ConsumeStopAll()) s_cancel = 1u;

    if (testActive)
    {
        if (UI_ConsumeTestExit()) s_cancel = 1u;
    }
    else if (s_inMain)
    {

        if (UI_ConsumeTestExit()) s_cancel = 1u;
    }
    else
    {
        IGN_OK(UI_ConsumeTestExit());
    }
}

void Flow_Service(void)
{
    Sensor_Task();
    Servo_Task();

    if (UI_InTick() == 0u) UI_Task();
    Cmd_Task();
    Enc_Task();
    ParamSet_Task();
    Flow_WatchSensOpen();
    Belt_Watchdog();

}

static void Flow_Beat(void)
{
    Bsp_WdgFeed();
    Proto_Poll();
    Flow_Service();
    Flow_PollCancel();
}

static void Flow_BeatThrottled(void)
{
    static u32 lastBeat = 0;
    u32 now = Time_Now();

    if ((u32)(now - lastBeat) >= (u32)T_BEAT_MS)
    {
        lastBeat = now;
        Flow_Beat();
        Flow_DensePoll();
    }
}

u8 Flow_PowerUpBeat(void)
{
    Proto_Poll();
    Flow_Service();
    if (UI_ConsumeStopAll()) s_cancel = 1u;
    return (u8)((s_cancel != 0u) ? 1u : 0u);
}

void Flow_VoidPending(void)
{
    startPending = 0u;
    testPending  = 0u;
    s_cancel     = 0u;

}

static u32 Flow_SensDelay(u8 idx)
{
    s16 v = gParam.sensDelay[idx];
    return (v > 0) ? (u32)v : 0u;
}

static void Flow_WarnSpeedCap(u8 idx)
{
    static u8  warned[2]  = { 0u, 0u };
    static s16 lastSpd[2] = { 0, 0 };
    static s16 lastMic[2] = { 0, 0 };

    if ((lastSpd[idx] != gParam.beltSpeed[idx]) || (lastMic[idx] != gParam.beltMicro[idx]))
    {
        lastSpd[idx] = gParam.beltSpeed[idx];
        lastMic[idx] = gParam.beltMicro[idx];
        warned[idx]  = 0u;
    }
    if (warned[idx] != 0u) return;
    if (Belt_EffCmps(idx) != (u8)gParam.beltSpeed[idx])
    {
        warned[idx] = 1u;
        Cmd_SendWarn((idx == 0u) ? "SPEEDCAP,1" : "SPEEDCAP,2");
    }
}

static void Flow_WarnBeltHz(u8 idx)
{

    static u8 hzWarned[2] = { 0u, 0u };
    u16 hz;

    if (idx >= (u8)BELT_NUM) return;
    if (hzWarned[idx] != 0u) return;
    hz = Belt_PulseHzAt(idx, (u8)Belt_EffCmps(idx));
    if (hz <= (u16)BELT_HZ_WARN) return;

    hzWarned[idx] = 1u;
    Cmd_SendWarnU32((idx == 0u) ? "BMHZ,1" : "BMHZ,2", (u32)hz);
}

#define SENS_OPEN_CHECK_MS  3000u

static void Flow_WatchSensOpen(void)
{
    static u8  done = 0u;
    static u32 t0   = 0u;

    if (done != 0u) return;
    if (!PowerUp_Done()) return;
    if (t0 == 0u) { t0 = Time_Now(); return; }
    if (!TIME_ELAPSED(t0, SENS_OPEN_CHECK_MS)) return;

    done = 1u;
    if (Sensor_Active(SENS_UP) && Sensor_Active(SENS_DOWN))
        Cmd_SendWarn("SENSOPEN");
}

static void Flow_PickStep(void);

static void Flow_ExtraLoopStep(void);
static void Flow_ExtraLoopEnd(void);
static u8   Flow_ExtraLoopDone(void);
static u8   Flow_OnePiece(u8 kind);

static void Flow_Belt(u8 idx, u8 on);
static void Flow_BeltRev(u8 idx);

static u8 Flow_WaitSensor(u8 idx, u8 want, u32 toMs, u16 errCode)
{
    u32 t0   = Time_Now();

    Sensor_ArmEdge(idx);

    for (;;)
    {
        Flow_BeatThrottled();
        Flow_PickStep();
        if (Flow_Stopped()) return 0u;

        if (Sensor_TakeFreshEdge(idx) != 0u)
        {
            if ((u8)(Sensor_Active(idx) ? 1u : 0u) == want) return 1u;
        }
        if (STEP_EXPIRED()) { s_err = errCode; return 0u; }
        if (TIME_ELAPSED(t0, toMs)) { s_err = errCode; return 0u; }
    }
}

static u8 Flow_WaitMs(u32 ms)
{
    u32 t0   = Time_Now();

    for (;;)
    {
        Flow_BeatThrottled();
        Flow_PickStep();
        if (Flow_Stopped()) return 0u;
        if (STEP_EXPIRED()) return 0u;
        if (TIME_ELAPSED(t0, ms)) return 1u;
    }
}

static u8 Flow_WaitDownWithBelt(u16 errCode)
{
    u32 t0     = Time_Now();
    u32 lastOk = Time_Now();

    Sensor_ArmEdge((u8)SENS_DOWN);

    for (;;)
    {
        Flow_BeatThrottled();
        Flow_PickStep();
        if (Flow_Stopped()) return 0u;

        if (Sensor_TakeFreshEdge((u8)SENS_DOWN) != 0u)
        {
            if ((u8)(Sensor_Active((u8)SENS_DOWN) ? 1u : 0u) == 1u) return 1u;
        }

        if (Belt_IsRunning((u8)BELT2) == 0u)
        {
            if (Belt_IsSwitching((u8)BELT2) == 0u)
            {
                (void)Flow_Belt((u8)BELT2, 1u);
            }

            if ((u32)(Time_Now() - lastOk) > (u32)BELT_STALL_MS)
            {
                s_err = (u16)ERR_BELT;
                return 0u;
            }
        }
        else
        {
            lastOk = Time_Now();
        }

        if (STEP_EXPIRED()) { s_err = (u16)ERR_BELT; return 0u; }
        if (TIME_ELAPSED(t0, T_WAIT_FEED_MS)) { s_err = errCode; return 0u; }
    }
}

static u8 Flow_TestStop(void)
{
    if (UI_ConsumeStopAll())  return 1u;

    if (UI_ConsumeTestExit()) return 1u;
    return (s_cancel != 0u) ? 1u : 0u;
}

static u8 Flow_MoveAngleAt(u8 ch, s16 ang, u8 spd)
{
    u32 exp;
    u32 t0;

    if (ch >= (u8)SRV_NUM) return 0u;

    ang = Params_ClampAngle(ch, ang);
    if (spd == 0u) spd = 1u;

    Servo_Motor(PIN_PCA_SDA, ch, ang, spd);
    exp = Servo_MoveMs(ch, ang, spd);
    if (exp < SERVO_MIN_MOVE_MS) exp = SERVO_MIN_MOVE_MS;
    t0 = Time_Now();

    for (;;)
    {
        Flow_BeatThrottled();
        Flow_ExtraLoopStep();
        if (Flow_Stopped()) return 0u;
        if (Servo_Arrived(ch)) return 1u;
        if (STEP_EXPIRED()) return 0u;
        if (TIME_ELAPSED(t0, exp + T_MOVE_SLACK_MS)) return 1u;
    }
}

static u8 Flow_MoveAngle(u8 ch, s16 ang)
{
    if (ch >= (u8)SRV_NUM) return 0u;
    return Flow_MoveAngleAt(ch, ang, (u8)gParam.runSpeed[ch]);
}

#define HOME_SPEED_FIRST 90u

#define PICK_IDLE   0u
#define PICK_ARM1   1u
#define PICK_ARM2   2u
#define PICK_DONE   3u

static u8  s_firstHome = 1u;
static u8  s_pickSeq = PICK_IDLE;
static u32 s_pickT0  = 0u;
static u32 s_pickMs  = 0u;

static u32 s_pickMs1 = 0u;
static u32 s_pickMs2 = 0u;

static void Flow_SendAngle(u8 ch, s16 ang)
{
    u8 spd;

    if (ch >= (u8)SRV_NUM) return;

    spd = (u8)gParam.runSpeed[ch];
    ang = Params_ClampAngle(ch, ang);
    if (spd == 0u) spd = 1u;
    Servo_Motor(PIN_PCA_SDA, ch, ang, spd);
}

static u32 Flow_PickMoveMs(void)
{
    u32 m1;
    u32 m2;

    m1 = Servo_MoveMs((u8)SRV_ARM1, gParam.pos[POS_INIT][SRV_ARM1], (u8)gParam.runSpeed[SRV_ARM1]);
    m2 = Servo_MoveMs((u8)SRV_ARM2, gParam.pos[POS_INIT][SRV_ARM2], (u8)gParam.runSpeed[SRV_ARM2]);

    return m1 + m2;
}

static void Flow_PickDepart(void)
{
    s_pickMs1 = Servo_MoveMs((u8)SRV_ARM1, gParam.pos[POS_INIT][SRV_ARM1], (u8)gParam.runSpeed[SRV_ARM1]);
    s_pickMs2 = Servo_MoveMs((u8)SRV_ARM2, gParam.pos[POS_INIT][SRV_ARM2], (u8)gParam.runSpeed[SRV_ARM2]);
    s_pickMs  = s_pickMs1 + s_pickMs2;
    s_pickT0  = Time_Now();
    s_pickSeq = PICK_ARM1;
}

static void Flow_PickStep(void)
{
    u32 elapsed = 0u;
    u8  timed   = 0u;

    if (s_pickT0 != 0u)
    {
        elapsed = (u32)(Time_Now() - s_pickT0);
        timed   = 1u;
    }

    if (s_pickSeq == PICK_ARM1)
    {

        if ((Servo_Arrived((u8)SRV_ARM1) != 0u) ||
            ((timed != 0u) && (elapsed >= (s_pickMs1 + (u32)T_MOVE_SLACK_MS))))
        {
            s_pickSeq = PICK_ARM2;
            Flow_SendAngle((u8)SRV_ARM2, gParam.pos[POS_INIT][SRV_ARM2]);
        }
    }
    else if (s_pickSeq == PICK_ARM2)
    {
        if ((Servo_Arrived((u8)SRV_ARM2) != 0u) ||
            ((timed != 0u) && (elapsed >= (s_pickMs + (u32)T_MOVE_SLACK_MS))))
        {
            s_pickSeq = PICK_DONE;
        }
    }
}

static u8 Flow_PickArrived(void)
{
    Flow_PickStep();

    if (s_pickSeq == PICK_DONE) return 1u;

    if ((Servo_Arrived((u8)SRV_ARM1) != 0u) && (Servo_Arrived((u8)SRV_ARM2) != 0u))
    {
        s_pickSeq = PICK_DONE;
        return 1u;
    }

    if (s_pickT0 != 0u)
    {
        if ((u32)(Time_Now() - s_pickT0) >= (s_pickMs + (u32)T_MOVE_SLACK_MS))
        {
            s_pickSeq = PICK_DONE;
            return 1u;
        }
    }
    return 0u;
}

static u8 Flow_PickTimerRunning(void)
{
    if (s_pickT0 == 0u) return 0u;
    return (u8)(((u32)(Time_Now() - s_pickT0) < s_pickMs) ? 1u : 0u);
}

static u8 Flow_PickTimerWaitEnd(void)
{
    for (;;)
    {
        Flow_BeatThrottled();
        if (Flow_Stopped()) return 0u;
        if (!Flow_PickTimerRunning()) break;
        if (STEP_EXPIRED()) return 0u;
    }
    s_pickT0 = 0u;
    s_pickMs = 0u;
    return 1u;
}

static u8 Flow_PickGo(u8 wait)
{
    if (wait == 0u)
    {
        Flow_PickDepart();
        return 1u;
    }

    u32 pickMs = Flow_PickMoveMs();
    u32 pickT0;

    Flow_SendAngle((u8)SRV_ARM2, gParam.pos[POS_INIT][SRV_ARM2]);
    pickT0 = Time_Now();
    for (;;)
    {
        Flow_BeatThrottled();
        Flow_ExtraLoopStep();
        if (Flow_Stopped()) { Flow_ExtraLoopEnd(); return 0u; }
        if (STEP_EXPIRED()) { Flow_ExtraLoopEnd(); return 0u; }

        if (Flow_ExtraLoopDone() != 0u)
        {
            if ((Flow_PickArrived() != 0u) ||
                TIME_ELAPSED(pickT0, pickMs + (u32)T_MOVE_SLACK_MS))
            {
                Flow_ExtraLoopEnd();
                return 1u;
            }
        }
    }
}

#define EX_PHASE_WAIT     0u
#define EX_PHASE_FEED     1u
#define EX_PHASE_SEEK     2u
static u8  s_exOn    = 0u;
static u8  s_exPhase = EX_PHASE_WAIT;
static u8  s_downApprove = 1u;
static u32 s_exT0    = 0u;
static u32 s_exNoMat = 0u;

static u32 s_boxT0 = 0u;
static u32 s_boxMs = 0u;

#define PIECE_MAIN   0u
#define PIECE_EXTRA  1u

static u8  s_cycleKind = QV_KIND_NORMAL;
static u8  Flow_GoRecog(void);

u8 Flow_CycleKind(void)
{
    return s_cycleKind;
}

static u8 Qv_HasMat(u8 idx)
{
    /* Single source of truth: Sensor_Active() already applies SENS_ACTIVE_LOW.
     * Never re-invert the raw pin level here - that creates a second polarity. */
    return Sensor_Active(idx);
}

static u8 Qv_WaitLow(u8 idx)
{
    u32 t0 = 0u;
    u8  on = 0u;

    for (;;)
    {
        Flow_BeatThrottled();
        Sensor_Task();
        Flow_PickStep();
        if (Flow_Stopped()) return 0u;

        if (Qv_HasMat(idx) != 0u)
        {
            if (on == 0u)
            {
                on = 1u;
                t0 = Time_Now();
            }
            if ((u32)(Time_Now() - t0) >= (u32)QV_LOW_MS) return 1u;
        }
        else
        {
            on = 0u;
        }
    }
}

static u8 Qv_DelayStop(u8 idx)
{
    s16 d = gParam.sensDelay[idx];

    if (d <= 0) return 1u;
    return Flow_WaitMs((u32)d);
}

static void Qv_ReleaseCh(u8 idx)
{
    Sensor_ForceIdle(idx);
}

static u8 Qv_Deposit(void)
{
    u8  box;
    s16 a1;
    s16 a2;

    Flow_Enter(FLOW_CLASSIFY);
    Flow_Belt((u8)BELT1, 0u);
    Flow_Belt((u8)BELT2, 0u);

    if (!Flow_GoRecog()) return 0u;

    recogValid = 1u;
    selectWait = 1u;
    boxCmd     = 0u;

    if (s_boxPending != 0u)
    {
        boxCmd = s_boxPending;
        s_boxPending = 0u;
    }

    UI_ShowBoxSelect();

    for (;;)
    {
        s16 sel;

        Flow_BeatThrottled();
        Sensor_Task();
        if (Flow_Stopped())
        {
            UI_HideBoxSelect();
            recogValid = 0u;
            selectWait = 0u;
            s_boxWin   = 0u;
            return 0u;
        }

        IGN_OK(UI_PageBoxStep());
        sel = UI_ConsumeBoxSelect();
        if (sel >= 0) IGN_OK(Flow_SetBox((u8)sel));
        box = boxCmd;
        if (box != 0u) break;
    }

    UI_HideBoxSelect();
    recogValid = 0u;
    selectWait = 0u;
    boxCmd     = 0u;
    s_boxWin   = 0u;
    s_boxPending = 0u;

    if ((box < 1u) || (box > BOX_NUM)) return 1u;

    a1 = gParam.pos[POS_BOX(box)][SRV_ARM1];
    a2 = gParam.pos[POS_LUMP][SRV_ARM2];

    if (!Flow_MoveAngle((u8)SRV_ARM1, a1)) return 0u;
    if (!Flow_MoveAngle((u8)SRV_ARM2, a2)) return 0u;
    if (!Flow_MoveAngle((u8)SRV_ARM2, gParam.pos[POS_INIT][SRV_ARM2])) return 0u;

    return 1u;
}

static u8 Qv_DupCheck(void);

static u8 Qv_DupCheck(void)
{
    u32 rem;
    u32 t0;

    t0  = Time_Now();
    rem = (u32)QV_DUP_MS;

    Sensor_ArmEdge((u8)SENS_DOWN);
    Flow_Belt((u8)BELT2, 1u);

    for (;;)
    {
        u32 used;

        Flow_BeatThrottled();
        Sensor_Task();
        Flow_PickStep();
        if (Flow_Stopped()) return 0u;

        used = (u32)(Time_Now() - t0);
        if (used >= rem) break;

        if (Sensor_TakeFreshEdge((u8)SENS_DOWN) != 0u)
        {
            if (!Qv_WaitLow((u8)SENS_DOWN)) return 0u;
            if (!Qv_DelayStop((u8)SENS_DOWN)) return 0u;

            used = (u32)(Time_Now() - t0);
            if (used < rem) rem -= used;
            else            rem  = 0u;

            Flow_Belt((u8)BELT2, 0u);
            Qv_ReleaseCh((u8)SENS_DOWN);

            if (!Qv_Deposit()) return 0u;

            t0 = Time_Now();
            Flow_Belt((u8)BELT2, 1u);

            if (rem == 0u) break;
        }
    }

    Flow_Belt((u8)BELT2, 0u);
    return 1u;
}

static u8 Qv_PieceTail(void)
{
    Flow_Belt((u8)BELT2, 1u);

    if (!Qv_WaitLow((u8)SENS_DOWN)) return 0u;
    if (!Qv_DelayStop((u8)SENS_DOWN)) return 0u;

    /* �¹���⵽���Ϻ󣬵� 1 ������������ʶ��λ���ӻ�����
     * ��0xAC��0xD6��0xA3����֪ͨ��λ��ץ��ʶ������ͷ���¹�磩�� */
    if (!Flow_WaitMs(1000u)) return 0u;
    Proto_SlaveShot();

    Flow_Belt((u8)BELT2, 0u);
    Qv_ReleaseCh((u8)SENS_DOWN);

    if (!Qv_Deposit()) return 0u;
    if (!Qv_DupCheck()) return 0u;

    return 1u;
}

/* �����㵹��Ŀ��Ǿ��ʼ�� >40 ��ʱ����ʽ��ǰ40�������ٶȣ�ʣ������15��/�룬�س����٣�������ԭ���㵹 */
static u8 Qv_TrayLumpTwoStage(void)
{
    s16 init = gParam.pos[POS_INIT][SRV_TRAY];
    s16 tgt  = gParam.pos[POS_LUMP][SRV_TRAY];
    s16 sign = (tgt > init) ? 1 : -1;
    s16 mid  = init + sign * 40;

    /* ��һ�Σ������趨�ٶȵ� 40 �� */
    if (!Flow_MoveAngle((u8)SRV_TRAY, mid)) return 0u;
    /* �ڶ��Σ�ʣ��Ƕ����� 15 ��/�뵹��Ŀ�� */
    if (!Flow_MoveAngleAt((u8)SRV_TRAY, tgt, 15u)) return 0u;
    /* �س̣����� 15 ��/��س�ʼ�� */
    if (!Flow_MoveAngleAt((u8)SRV_TRAY, init, 15u)) return 0u;
    return 1u;
}

static u8 Qv_TrayLump(void)
{
    s16 init = gParam.pos[POS_INIT][SRV_TRAY];
    s16 tgt  = gParam.pos[POS_LUMP][SRV_TRAY];
    s16 d    = tgt - init;
    if (d < 0) d = -d;

    if (d > 40)
        return Qv_TrayLumpTwoStage();
    else
    {
        if (!Flow_MoveAngle((u8)SRV_TRAY, gParam.pos[POS_LUMP][SRV_TRAY])) return 0u;
        if (!Flow_MoveAngle((u8)SRV_TRAY, gParam.pos[POS_INIT][SRV_TRAY])) return 0u;
        return 1u;
    }
}

static u8 Qv_CycleFront(void)
{
    Flow_Enter(FLOW_FEED);

    Flow_Belt((u8)BELT1, 1u);

    if (!Qv_WaitLow((u8)SENS_UP)) return 0u;
    if (!Qv_DelayStop((u8)SENS_UP)) return 0u;

    Flow_Belt((u8)BELT1, 0u);
    Qv_ReleaseCh((u8)SENS_UP);

    /* ͣ��1 ���2 ����֮�䣬���� 1 �뻺���ӳ� */
    if (!Flow_WaitMs(1000u)) return 0u;

    return Qv_PieceTail();
}

static u8 Qv_DenseJudge(void)
{
    u32 t0 = 0u;
    u8  on = 0u;

    for (;;)
    {
        Flow_BeatThrottled();
        Sensor_Task();
        Flow_PickStep();
        if (Flow_Stopped()) return 0u;

        if (Qv_HasMat((u8)SENS_UP) != 0u)
        {
            if (on == 0u)
            {
                on = 1u;
                t0 = Time_Now();
            }
            if ((u32)(Time_Now() - t0) >= (u32)QV_LOW_MS) return 1u;
        }
        else
        {
            return 0u;
        }
    }
}

static u32 Flow_BoxToPickMs(u8 box)
{
    u8  spd = (u8)gParam.runSpeed[SRV_ARM1];
    s32 d1;
    s32 d2;
    s32 d;

    if (spd == 0u) spd = 1u;
    if ((box < 1u) || (box > BOX_NUM)) return 0u;
    d1 = (s32)gParam.pos[POS_BOX(box)][SRV_ARM1] - (s32)gParam.pos[POS_INIT][SRV_ARM1];
    d2 = (s32)gParam.pos[POS_BOX(box)][SRV_ARM2] - (s32)gParam.pos[POS_INIT][SRV_ARM2];
    if (d1 < 0) d1 = -d1;
    if (d2 < 0) d2 = -d2;
    d = (d1 > d2) ? d1 : d2;
    return (u32)((d * (s32)MS_PER_SEC) / (s32)spd);
}

static void Flow_BoxToPickMark(u8 box)
{
    s_boxT0 = Time_Now();
    s_boxMs = Flow_BoxToPickMs(box);
    if (s_boxMs == 0u) s_boxT0 = 0u;
}

static void Flow_ExtraLoopBegin(void)
{
    s_exOn    = 1u;
    s_exPhase = EX_PHASE_FEED;
    s_exT0    = Time_Now();
    s_exNoMat = 0u;
    s_boxT0   = 0u;
    s_boxMs   = 0u;
    Sensor_ArmEdge((u8)SENS_DOWN);
}

static void Flow_ExtraLoopStep(void)
{
    u8 hasMat = 0u;

    if (s_exOn == 0u) return;

    hasMat = (u8)(((s_downApprove != 0u) && (Sensor_TakeFreshEdge((u8)SENS_DOWN) != 0u)) ? 1u : 0u);

    if (s_exPhase == EX_PHASE_WAIT)
    {
        if (s_boxT0 != 0u)
        {
            if (!TIME_ELAPSED(s_boxT0, s_boxMs)) return;
        }
        else if (Flow_PickTimerRunning())
        {
            return;
        }
        else
        {
            if (!TIME_ELAPSED(s_exT0, EXTRA_LOOP_MS)) return;
        }
        (void)Flow_Belt((u8)BELT2, 1u);
        s_exPhase = EX_PHASE_FEED;
        s_exT0    = Time_Now();
        return;
    }

    if (s_exPhase == EX_PHASE_FEED)
    {
        if ((hasMat == 0u) || TIME_ELAPSED(s_exT0, EXTRA_LOOP_MS))
        {
            s_exPhase = EX_PHASE_SEEK;
            s_exNoMat = Time_Now();
        }
        return;
    }

    if (hasMat != 0u)
    {

        Flow_Belt((u8)BELT2, 0u);
        s_exPhase = EX_PHASE_WAIT;
        s_exT0    = Time_Now();
        s_exNoMat = 0u;
        return;
    }

    if (TIME_ELAPSED(s_exNoMat, EXTRA_NOMAT_MS))
    {
        Flow_ExtraLoopEnd();
    }
}

static u8 Flow_ExtraLoopDone(void)
{
    return (u8)((s_exOn == 0u) ? 1u : 0u);
}

static void Flow_ExtraLoopEnd(void)
{
    if (s_exOn != 0u) Flow_Belt((u8)BELT2, 0u);
    s_exOn    = 0u;
    s_exPhase = EX_PHASE_WAIT;
    s_exT0    = 0u;
    s_exNoMat = 0u;
    s_boxT0   = 0u;
    s_boxMs   = 0u;
}

u8 Flow_P2P1(s16 arm1, s16 arm2, s16 tray)
{
    if (!Flow_MoveAngle((u8)SRV_ARM1, arm1)) return 0u;
    if (!Flow_MoveAngle((u8)SRV_ARM2, arm2)) return 0u;
    if (!Flow_MoveAngle((u8)SRV_TRAY, tray)) return 0u;
    return 1u;
}

u8 Flow_P2P2(s16 tray, s16 arm2, s16 arm1)
{
    if (!Flow_MoveAngle((u8)SRV_TRAY, tray)) return 0u;
    if (!Flow_MoveAngle((u8)SRV_ARM2, arm2)) return 0u;
    if (!Flow_MoveAngle((u8)SRV_ARM1, arm1)) return 0u;
    return 1u;
}

static u8 Flow_AllInit(void)
{
    /* ֻ����������2�����1 �����ڲ���λ */
    if (!Flow_MoveAngle((u8)SRV_TRAY, gParam.pos[POS_INIT][SRV_TRAY])) return 0u;
    if (!Flow_MoveAngle((u8)SRV_ARM2, gParam.pos[POS_INIT][SRV_ARM2])) return 0u;
    return 1u;
}

static u8 Flow_GoRecog(void)
{
    /* ʶ����תλ��ֻ���¼���������ֵ�ǰ��̬ */
    Cmd_SendEvt(15);
    return 1u;
}

static u8 Flow_BoxTrip(u8 n)
{
    if ((n < 1u) || (n > BOX_NUM)) return 0u;
    if (!Flow_AllInit()) return 0u;
    if (!Flow_P2P1(gParam.pos[POS_BOX(n)][SRV_ARM1],
                   gParam.pos[POS_LUMP][SRV_ARM2],
                   gParam.pos[POS_INIT][SRV_TRAY])) return 0u;
    if (!Flow_AllInit()) return 0u;
    return 1u;
}

static u8 Flow_GoBox(u8 n)
{
    if (!Flow_BoxTrip(n)) return 0u;

    Flow_BoxToPickMark(n);
    Cmd_SendEvt(17);
    return 1u;
}

static u8  s_denseRun = 0u;
static u32 s_denseT0  = 0u;

static u8 Flow_ProbeDense(void)
{
    s_denseRun = 0u;
    if (!Sensor_Active(SENS_UP)) { Flow_DenseMode(0u); return 0u; }
    s_denseRun = 1u;
    s_denseT0  = Time_Now();
    return 0u;
}

static void Flow_DensePoll(void)
{
    u32 win;

    if (s_denseRun == 0u) return;
    if (!Sensor_Active(SENS_UP)) { s_denseRun = 0u; Flow_DenseMode(0u); return; }
    win = (u32)DENSE_PROBE_MS;
    if (win < (u32)DENSE_PROBE_MS) win = (u32)DENSE_PROBE_MS;
    if ((u32)(Time_Now() - s_denseT0) >= win) { s_denseRun = 0u; Flow_DenseMode(1u); }
}

static void Flow_DenseMode(u8 on)
{
    if ((u8)(denseMode ? 1u : 0u) == (u8)(on ? 1u : 0u)) return;
    denseMode = on;
    Cmd_SendMode(on ? "DENSE" : "NORMAL");
}

static void Flow_CancelStop(void)
{
    Belt_StopAll();
    Flow_SafeExit(0u);
    denseMode  = 0;
    recogValid = 0;
    selectWait = 0;
    boxCmd     = 0;
    s_boxPending = 0;

    UI_GotoMain();
    Flow_Home();
}

static u8 Flow_S1(void)
{

    u32 dly  = Flow_SensDelay(SENS_UP);

    Flow_Enter(FLOW_PREP);
    Flow_WarnSpeedCap(BELT1);
    Flow_WarnBeltHz(BELT1);
    Flow_Belt((u8)BELT2, 0u);

    (void)Flow_Belt((u8)BELT1, 1u);
    if (!Flow_WaitSensor(SENS_UP, 1u, T_WAIT_FOREVER, ERR_SENS)) return 0u;
    IGN_OK(Flow_PickGo(0u));
    if (!Flow_WaitMs(dly)) return 0u;

    Flow_Belt((u8)BELT1, 0u);
    (void)Flow_Belt((u8)BELT2, 1u);
    Sensor_ResyncOne(SENS_UP);

    IGN_OK(Flow_ProbeDense());

    return 1u;
}

static void Flow_BeltRunIdx(u8 idx, u8 dir)
{
    u8 sp = (u8)gParam.beltSpeed[idx];

    if (sp == 0u) sp = 1u;
    if (idx == (u8)BELT1) (void)Belt1_RunDir(sp, (u8)(dir ? 1u : 0u));
    else                  (void)Belt2_RunDir(sp, (u8)(dir ? 1u : 0u));
}

static void Flow_Belt(u8 idx, u8 on)
{
    if (on == 0u)
    {
        if (idx == (u8)BELT1) (void)Belt1_Stop();
        else                  (void)Belt2_Stop();
        return;
    }

    Flow_BeltRunIdx(idx, (u8)(gParam.beltDir[idx] ? 1u : 0u));
}

static void Flow_BeltRev(u8 idx)
{
    Flow_BeltRunIdx(idx, (u8)(gParam.beltDir[idx] ? 0u : 1u));
}

static void Flow_BeltBothRun(u8 rev)
{
    if (rev == 0u)
    {
        (void)Flow_Belt((u8)BELT1, 1u);
        (void)Flow_Belt((u8)BELT2, 1u);
    }
    else
    {
        (void)Flow_BeltRev((u8)BELT1);
        (void)Flow_BeltRev((u8)BELT2);
    }
}

static u8 Flow_S2(void)
{
    u32 dly = Flow_SensDelay(SENS_DOWN);
    u8  stopped = 0u;

    Flow_Enter(FLOW_FEED);
    Flow_WarnSpeedCap(BELT2);
    Flow_WarnBeltHz(BELT2);
    Flow_Belt((u8)BELT1, 0u);

    if (!Belt_IsRunning((u8)BELT2))
    {
        Flow_Belt((u8)BELT2, 1u);
    }

    if (!Flow_WaitDownWithBelt((u16)ERR_SENS)) return 0u;

    s_downApprove = 0u;

    if (Flow_PickTimerRunning())
    {
        Flow_Belt((u8)BELT2, 0u);
        stopped = 1u;
        if (!Flow_PickTimerWaitEnd()) return 0u;
    }
    else
    {
        s_pickT0 = 0u;
        s_pickMs = 0u;
    }

    if (stopped != 0u)
    {
        Flow_Belt((u8)BELT2, 1u);
    }

    if (!Flow_WaitMs(dly)) return 0u;

    s_downApprove = 1u;
    Flow_ExtraLoopBegin();
    return 1u;
}

static u8 Flow_S4(void)
{
    u8  box = 0u;

    Flow_Enter(FLOW_CLASSIFY);
    Flow_Belt((u8)BELT1, 0u);
    Flow_Belt((u8)BELT2, 0u);

    if (!Flow_GoRecog()) return 0u;

    recogValid = 1u;
    selectWait = 1u;
    boxCmd     = 0u;

    UI_ShowBoxSelect();

    for (;;)
    {
        s16 sel;

        Flow_BeatThrottled();
        if (Flow_Stopped())
        {
            UI_HideBoxSelect();
            recogValid = 0u;
            selectWait = 0u;
            return 0u;
        }

        Flow_ExtraLoopStep();
        IGN_OK(UI_PageBoxStep());
        sel = UI_ConsumeBoxSelect();
        if (sel >= 0) IGN_OK(Flow_SetBox((u8)sel));
        box = boxCmd;
        if (box != 0u) break;

    }

    UI_HideBoxSelect();
    recogValid = 0u;
    selectWait = 0u;
    boxCmd     = 0u;

    if (box != 0u)
    {
        if (!Flow_GoBox(box)) return 0u;
    }
    return 1u;
}

static u8 Flow_S5(void)
{
    Flow_Enter(FLOW_RETURN);
    Flow_Belt((u8)BELT1, 0u);

    return Flow_PickGo(1u);
}

static u8 Flow_OnePiece(u8 kind)
{
    (void)kind;
    if (!Flow_S2()) return 0u;

    if (!Flow_S4()) return 0u;

    if (!Flow_S5()) return 0u;
    Sensor_ResyncOne(SENS_DOWN);
    return 1u;
}

static void Flow_RunMain(void)
{
    u8 first = 1u;

    s_inMain = 0u;
    Sensor_Resync();
    Flow_Home();
    s_inMain = 1u;

    /* ����ѭ���Ȱ���ֻ��������״̬������λ����WARN,SENSBOOT,<bit1=��><bit0=��>
       3=��·������  0=��·�����ϣ��� SENS_ACTIVE_LOW ��һ������ UI ͬԴ�� */
    {
        u8 su = Sensor_Active((u8)SENS_UP);
        u8 sd = Sensor_Active((u8)SENS_DOWN);

        Cmd_SendWarnU32("SENSBOOT", (u32)(((u16)su << 1) | (u16)sd));
    }

    UI_ShowTestExit(0u);

    if (s_homed == 0u)
    {
        UI_GotoMain();
        Flow_SafeExit(0u);
        mode       = RUN_IDLE;
        st         = FLOW_PREP;
        testActive = 0;
        testMode   = 0;
        denseMode  = 0;
        Cmd_SendWarn("HOMEOVER");
        return;
    }

    mode = RUN_FLOW;
    st   = FLOW_PREP;

    s_cycleKind = QV_KIND_NORMAL;
    denseMode   = 0u;
    first       = 1u;

    for (;;)
    {
        if (Flow_Stopped()) break;

        if (first != 0u)
        {
            first       = 0u;
            s_cycleKind = QV_KIND_NORMAL;
        }
        else
        {
            s_cycleKind = (u8)((Qv_DenseJudge() != 0u) ? QV_KIND_DENSE : QV_KIND_NORMAL);
        }

        denseMode = (u8)((s_cycleKind == QV_KIND_DENSE) ? 1u : 0u);
        Cmd_SendMode((denseMode != 0u) ? "DENSE" : "NORMAL");

        if (!Qv_TrayLump()) break;
        if (!Qv_CycleFront()) break;
    }

}

static void Flow_TestFailDiag(void)
{
    if (s_err != (u16)ERR_SENS) return;
    if (Sensor_Active(SENS_UP))   Cmd_SendWarn("SENSHELD,1");
    if (Sensor_Active(SENS_DOWN)) Cmd_SendWarn("SENSHELD,2");
}

static u8 Flow_SensRound(void)
{

    (void)Flow_Belt((u8)BELT1, 1u);

    if (!Flow_WaitSensor(SENS_UP, 1u, T_WAIT_FOREVER, (u16)ERR_SENS)) return 0u;

    if (!Flow_WaitMs(Flow_SensDelay(SENS_UP))) return 0u;

    Flow_Belt((u8)BELT1, 0u);
    (void)Flow_Belt((u8)BELT2, 1u);

    if (!Flow_WaitSensor(SENS_DOWN, 1u, T_WAIT_FOREVER, (u16)ERR_SENS)) return 0u;

    if (!Flow_WaitMs(Flow_SensDelay(SENS_DOWN))) return 0u;

    Flow_Belt((u8)BELT2, 0u);
    return 1u;
}

static u8 Flow_WaitTestExit(void)
{
    for (;;)
    {
        Proto_Poll();
        Flow_BeatThrottled();
        if (Flow_TestStop()) { s_cancel = 1u; return 0u; }
    }
}

static u8 Flow_LoopRun(void)
{
    u8 n;

    if (!Flow_AllInit()) return 0u;

    Flow_BeltBothRun(0u);
    if (!Flow_WaitMs(T_FWD_MS)) return 0u;

    Flow_BeltBothRun(1u);
    if (!Flow_WaitMs(T_REV_MS)) return 0u;

    Belt_StopAll();

    for (n = 1u; n <= BOX_NUM; n++)
    {
        if (!Flow_BoxTrip(n)) return 0u;
    }

    Belt_StopAll();
    return Flow_WaitTestExit();
}

static u8 Flow_LoopStept(void)
{

    Flow_BeltBothRun(0u);

    return Flow_WaitTestExit();
}

static u8 Flow_LoopLink(void)
{
    for (;;)
    {
        if (!Flow_SensRound()) return 0u;
    }
}

static u8 Flow_Test1(void) { return Flow_LoopRun();   }
static u8 Flow_Test2(void) { return Flow_LoopStept(); }
static u8 Flow_Test3(void) { return Flow_LoopLink();  }

static const Step g_testSteps[3] = {
    { Flow_Test1, 0u, STEP_END, STEP_END },
    { Flow_Test2, 0u, STEP_END, STEP_END },
    { Flow_Test3, 0u, STEP_END, STEP_END },
};

#define TEST_STEP_N  ((u8)(sizeof(g_testSteps) / sizeof(g_testSteps[0])))

static void Flow_RunTest(void)
{
    u8 m = (u8)testMode;

    if ((m < 1u) || (m > TEST_STEP_N)) return;
    if (Step_Run(&g_testSteps[m - 1u], TEST_STEP_N, 0u) == 0u)
    {

        }
}

static u8 Flow_HomeLoop(void)
{
    /* ���1 ֻ���ϵ������PowerUp_Run��ʱ���������ڻ��������� */
    static const u8 order[] = { SRV_TRAY, SRV_ARM2 };
    u8 i;

    STATIC_ASSERT(sizeof(order) / sizeof(order[0]) == 2u, home_order_n);

    for (i = 0u; i < (u8)(sizeof(order) / sizeof(order[0])); i++)
    {
        u8 spd;

        if (Flow_Stopped()) return 0u;
        spd = (u8)gParam.runSpeed[order[i]];

        if (s_firstHome != 0u) spd = (u8)HOME_SPEED_FIRST;
        if (!Flow_MoveAngleAt(order[i], gParam.pos[POS_INIT][order[i]], spd)) return 0u;
    }
    s_firstHome = 0u;
    return 1u;
}

void Flow_Home(void)
{
    u8 i;
    u8 done;
    u8 wasCancel;

    if (s_inMain) { s_cancel = 1u; return; }

    if (PowerUp_Busy()) { s_cancel = 1u; s_puHome = 1u; return; }

    Belt_StopAll();
    Flow_SafeExit(0u);
    for (i = 0; i < (u8)HS_COUNT; i++) Hs_Clear((HandshakeId)i);

    testActive   = 0;
    testMode     = 0;
    denseMode    = 0;
    recogValid   = 0;
    selectWait   = 0;
    boxCmd       = 0;

    wasCancel    = s_cancel;
    s_cancel     = 0;
    if (wasCancel != 0u)
    {
        startPending = 0u;
        testPending  = 0u;
    }
    s_err        = 0;

    s_homed  = 0u;
    homeActive = 1;
    mode = RUN_HOME;
    st   = FLOW_PREP;
    s_inMain = 1u;
    done = Flow_HomeLoop();
    s_inMain = 0u;
    s_homeOk = done;
    if (done != 0u) s_homed = 1u;

    if ((done == 0u) || (s_cancel != 0u))
    {
        startPending = 0u;
        testPending  = 0u;
    }

    s_cancel   = 0;
    homeActive = 0;
    mode = RUN_IDLE;
    st   = FLOW_PREP;
}

u8 Flow_Reset(void)
{
    if (s_inMain || testActive || (mode == RUN_FLOW) || homeActive) return 0u;
    if (PowerUp_Busy()) return 0u;

    Belt_StopAll();
    Flow_SafeExit(0u);

    if (s_homed != 0u) return 1u;
    Flow_Home();
    return (u8)((s_homed != 0u) ? 1u : 0u);
}

void Flow_Init(void)
{
    (void)Flow_S1;
    (void)Flow_OnePiece;
    st = FLOW_PREP;
    mode = RUN_IDLE;
    homeActive = 0;
    startPending = 0;
    testPending  = 0;
    testActive = 0;
    testMode = 0;
    denseMode = 0;
    recogValid = 0;
    selectWait = 0;
    boxCmd = 0;
    s_cancel = 0;
    s_err = 0;
    s_inMain = 0;
    s_puHome = 0;
    s_homeOk = 0;
    s_homed  = 0;

}

static u8 Flow_ParamsReady(void)
{
    if (!Params_DraftDirty()) return 1u;
    ParamSet_ReqCommit();
    return 0u;
}

u8 Flow_Start(void)
{

    if (PowerUp_Busy())
    {
        startPending = 1;
        Cmd_SendFlow("WAIT");
        return 2u;
    }
    if (homeActive)
    {
        startPending = 1;
        Cmd_SendFlow("WAIT");
        return 2u;
    }

    if (s_inMain != 0u) return 0u;

    if (!Flow_ParamsReady())
    {
        startPending = 1;
        Cmd_SendFlow("WAIT");
        return 2u;
    }

    denseMode      = 0;
    recogValid     = 0;
    selectWait     = 0;
    boxCmd         = 0;

    IGN_OK(UI_ConsumeStopAll());
    s_cancel       = 0;
    s_err          = 0;
    s_inMain       = 0;

    Belt_StopAll();

    mode = RUN_FLOW;
    Flow_Enter(FLOW_PREP);
    Cmd_SendFlow("START");
    Cmd_SendMode("PREP");
    return 1;
}

void Flow_Abort(void)
{
    u8 i;

    if (s_inMain) { s_cancel = 1u; return; }

    Belt_StopAll();
    Flow_SafeExit(0u);
    for (i = 0; i < (u8)HS_COUNT; i++) Hs_Clear((HandshakeId)i);
    st = FLOW_PREP;
    mode = RUN_IDLE;
    homeActive = 0;
    startPending = 0;
    testPending  = 0;
    testActive = 0;
    testMode = 0;
    denseMode = 0;
    recogValid = 0;
    selectWait = 0;
    boxCmd = 0;
    s_cancel = 0;
    s_err = 0;
    s_inMain = 0;

}

static void Flow_TestEnd(u16 code);

FlowState Flow_State(void)        { return st; }
u8        Flow_Running(void)      { return (mode == RUN_FLOW) ? 1 : 0; }
u8        Flow_TestPending(void)  { return testPending; }
u8        Flow_HomeActive(void)   { return homeActive; }
u8        Flow_Homing(void)       { return (u8)(((homeActive != 0u) || (s_puHome != 0u)) ? 1u : 0u); }
u8        Flow_Homed(void)        { return s_homed; }

void      Flow_HomedMark(u8 ok)
{
    s_homed = (u8)((ok != 0u) ? 1u : 0u);

    if (s_homed == 0u)
    {
        startPending = 0u;
        testPending  = 0u;
    }
}

const char* Flow_StateName(FlowState s)
{
    switch (s)
    {
    case FLOW_PREP:     return "PREP";
    case FLOW_FEED:     return "FEED";
    case FLOW_CLASSIFY: return "CLASSIFY";
    case FLOW_RETURN:   return "RETURN";
    default:            return "?";
    }
}

static const char* TestTag(u8 m)
{
    switch (m)
    {
    case 1:  return "TEST1";
    case 2:  return "TEST2";
    case 3:  return "TEST3";
    default: return "TEST?";
    }
}

u8 Flow_StartTest(u8 testModeReq)
{
    if (testModeReq < 1 || testModeReq > 3) return 0;

    if (testActive) return 0;

    if (PowerUp_Busy() || homeActive || (mode == RUN_FLOW) || (s_inMain != 0u))
    {
        testPending = testModeReq;
        Cmd_SendFlow("WAIT");
        return 2u;
    }

    if (!Flow_ParamsReady())
    {
        testPending = testModeReq;
        Cmd_SendFlow("WAIT");
        return 2u;
    }
    Flow_Abort();
    IGN_OK(UI_ConsumeStopAll());

    testMode = testModeReq;
    testActive = 1;

    mode = (testModeReq == 1) ? RUN_TEST  :
           (testModeReq == 2) ? RUN_STEPT : RUN_SENST;

    Belt_StopAll();

    UI_ShowTestExit(testModeReq);
    Cmd_SendMode(TestTag(testModeReq));
    return 1;
}

u8 Flow_TestActive(void)
{
    return testActive;
}

static void Flow_TestEnd(u16 code)
{
    Belt_StopAll();
    if (code != 0u) Flow_TestFailDiag();
    Flow_SafeExit(code);
    testActive = 0;
    testMode   = 0;

    if (code != 0u)
    {
        startPending = 0u;
        testPending  = 0u;
    }

    Belt_StopAll();
    Cmd_SendMode("TESTEND");
    mode = RUN_IDLE;
    UI_GotoMain();
    Flow_Home();
}

void Flow_TestAbort(void)
{
    if (!testActive) return;
    Flow_TestEnd(0u);
}

u8 Flow_SetBox(u8 n)
{

    if (st != FLOW_CLASSIFY) return 0;
    if (s_boxWin == 0u) return 0;

    if (!recogValid || !selectWait)
    {
        if ((n >= 1) && (n <= BOX_NUM))
        {
            s_boxPending = n;
            return 1;
        }
        return 0;
    }

    if (boxCmd != 0) return 0;
    if ((n >= 1) && (n <= BOX_NUM)) boxCmd = n;
    else                            return 0;
    return 1;
}

RunMode Flow_CurrentMode(void)
{

    if (homeActive) return RUN_HOME;
    return mode;
}

void Flow_RunTestNow(void)
{
    if (testActive == 0u) return;

    s_cancel = 0u;
    s_err    = 0u;
    s_inMain = 1u;
    Flow_RunTest();
    s_inMain = 0u;

    Flow_TestEnd(s_err);
}

void Flow_RunMainNow(void)
{
    if (mode != RUN_FLOW) return;

    s_cancel  = 0u;
    s_err     = 0u;
    denseMode = 0u;
    st        = FLOW_PREP;
    s_inMain  = 1u;
    Flow_RunMain();
    s_inMain  = 0u;

    if (s_err != 0u) Flow_FailStop(s_err, 1u);
    else             Flow_CancelStop();
}

void Flow_IdleService(void)
{
    Proto_Poll();
    Flow_WatchSensOpen();

    if (s_inMain != 0u) return;

    if ((PowerUp_Busy() == 0u) && (homeActive == 0u) &&
        (mode == RUN_IDLE) && (testActive == 0u))
    {
        IGN_OK(UI_ConsumeStopAll());
    }

    if (UI_IsLiveDebug() != 0u) return;

    if (s_puHome != 0u)
    {
        if (PowerUp_Busy() == 0u)
        {
            s_puHome = 0u;
            Flow_Home();
            if (s_homeOk != 0u) Cmd_SendEvt(1);
        }
        return;
    }

    if (UI_ConsumeReset2() != 0u)
    {
        IGN_OK(Flow_Reset());
        return;
    }

    if (!PowerUp_Done() || homeActive) return;

    if (testActive != 0u) { Flow_RunTestNow(); return; }
    if (mode == RUN_FLOW) { Flow_RunMainNow();  return; }

    IGN_OK(Flow_ParamsReady());
    if (Params_DraftDirty()) return;

    if (testPending != 0u)
    {
        u8 m = testPending;
        testPending = 0u;
        if (Flow_StartTest(m) == 1u) Flow_RunTestNow();
    }
    else if (startPending != 0u)
    {
        startPending = 0u;
        if (Flow_Start() == 1u) Flow_RunMainNow();
    }
}
