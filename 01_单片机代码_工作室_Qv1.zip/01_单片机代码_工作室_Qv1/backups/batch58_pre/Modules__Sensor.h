#ifndef __MOD_SENSOR_H
#define __MOD_SENSOR_H

#include "Core/Types.h"

#define SENSOR_NUM        2
#define SENS_UP           0
#define SENS_DOWN         1
#define SENS_DEBOUNCE_MS  10
#define SENS_SAMPLE_N     8

void    Sensor_Init(void);
void    Sensor_Poll(void);
void    Sensor_Task(void);
u8      Sensor_Active(u8 idx);
void    Sensor_Resync(void);
void    Sensor_ResyncOne(u8 idx);
void    Sensor_ForceIdle(u8 idx);
void    Sensor_IsrEdge(u8 idx);

void    Sensor_ArmEdge(u8 idx);
u8      Sensor_TakeFreshEdge(u8 idx);

#define SENS_WIRED_WHITE_TO_GND  1u

/* NPN ����ԭ�����ߣ�����=�ߵ�ƽ��������������=�͵�ƽ����ͨ�� => ����Ч */
#define SENS_ACTIVE_LOW  0u

#if ((SENS_ACTIVE_LOW != 0u) && (SENS_ACTIVE_LOW != 1u))
#error "SENS_ACTIVE_LOW must be 0 (active-high) or 1 (active-low)"
#endif

u8  Sensor_RawLevel(u8 idx);
u32 Sensor_TakeGlitch(u8 idx);
u32 Sensor_GlitchTotal(u8 idx);

#endif
