#include "Core/Types.h"
#include "Core/Time.h"
#include "Bsp/Bsp.h"
#include "Modules/BoardCfg.h"
#include "Core/PinMap.h"
#include "Modules/Belt.h"
#include "Delay.h"
#include "Modules/Params.h"

u8 Motion_BeltLocked(u8 idx);

volatile u16 g_beltIsrLastUs = 0u;
volatile u16 g_beltIsrMaxUs  = 0u;

#define BELT_STEPS_REV       200u
#define BELT_ROLLER_MM       24.0f
#define BELT_CIRCUM_CM       (3.14159265f * BELT_ROLLER_MM / 10.0f)
#define BELT_PWM_PSC_1US     71u
#define BELT_PWM_ARR_MIN     49u
#define BELT_PWM_HZ_MAX      20000u
#define BELT_TIM_ARR_100US   100u
#define BELT_ARR_16BIT_MAX   65536u
#define BELT_TICK_DIV        10u
#define BELT_HB_DIV          5000u
#define BELT_RAMP_TICKS      ((u32)BELT_RAMP_MS * 10u)
#define BELT_SCALE_FULL_PCT  100u
#define BELT_ISR_W_MAX_US    1000u
#define BELT_STEP_ACC_FULL   10000u

typedef struct {

    PinDef         dirPin;
    PinDef         pulPin;
    TIM_TypeDef*   pwmTim;
    u16            pwmCh;
    u8             idx;

    volatile u8    running;
    volatile u8    switching;
    volatile u32   switchT;
    volatile u8    dirLevel;
    volatile u8    pendDir;

    volatile u32   arrNow;
    volatile u32   arrTgt;
    volatile u32   arrFloor;
    volatile u32   arrStepX1000;
    volatile u32   arrAcc;
    volatile u32   hzNow;

    u8             spCache;
    u16            scCache;
    u32            arrCache;

    volatile u32   stepCnt;
    volatile u32   stepAcc;

} BeltDev;

static BeltDev s_belt[BELT_NUM] = {
    { { 0, 0 }, { 0, 0 }, 0, 0u, (u8)BELT1 },
    { { 0, 0 }, { 0, 0 }, 0, 0u, (u8)BELT2 }
};

static volatile u8  s_tickDiv;
static volatile u16 s_hbDiv;      /* ������Ƶ��10kHz / 5000 = 2Hz */

#define BELT_HOT_SET(p, m)   ((p)->BSRR = (u32)(m))
#define BELT_HOT_CLR(p, m)   ((p)->BRR  = (u32)(m))
#define BELT_DIR_HOT(b, d)   do { if (d) BELT_HOT_SET(((b)->dirPin.port), (b)->dirPin.pin); \
                                  else    BELT_HOT_CLR(((b)->dirPin.port), (b)->dirPin.pin); } while (0)

static void BeltApplyDir(BeltDev* b, u8 dir)
{
    b->dirLevel = (u8)(dir ? 1u : 0u);
    Bsp_Write(b->dirPin, b->dirLevel);
}

static void BeltPulIdle(BeltDev* b)
{
    Bsp_SetMode(b->pulPin, PDIR_OUT_OD);
    Bsp_Write(b->pulPin, 1u);
}

static void BeltPulAf(BeltDev* b)
{
    /* Ӳ�� PWM��������и��ÿ�©���� TIM2_CH3 / TIM3_CH4 ֱ��������
     * �����ӷ�Ҫ��©���Ͳ������壬��� TIM_OCPolarity_Low�� */
    Bsp_SetMode(b->pulPin, PDIR_AF_OD);
}

static u16 BeltScaleX100(const BeltDev* b)
{
    s16 m = gParam.beltMicro[b->idx];

    if (m == 4 || m == 8 || m == 16 || m == 32)
    {
        return (u16)(((u32)m * BELT_SCALE_FULL_PCT) / (u32)BELT_MICROSTEP);
    }
    return (u16)BELT_SCALE_FULL_PCT;
}

static u32 BeltArrAtCmps(const BeltDev* b, u8 cmPerSec)
{
    u16 sc = BeltScaleX100(b);
    float hz;
    u32 arr;

    hz = (float)cmPerSec / BELT_CIRCUM_CM * ((float)BELT_STEPS_REV * (float)BELT_MICROSTEP);
    hz = hz * (float)sc / (float)BELT_SCALE_FULL_PCT;
    if (hz < 1.0f) hz = 1.0f;

    arr = (u32)(1000000.0f / hz + 0.5f);
    if (arr < 1u) arr = 1u;
    if (arr > BELT_ARR_16BIT_MAX) arr = BELT_ARR_16BIT_MAX;
    arr -= 1u;
    if (arr < (u32)BELT_PWM_ARR_MIN) arr = (u32)BELT_PWM_ARR_MIN;
    return arr;
}

typedef struct {
    u32 arrFloor;
    u32 arrTgt;
    u16 sc;
    u8  cacheHit;
} BeltPwmCalc;

static BeltPwmCalc BeltCalcPwm(const BeltDev* b, u8 cmPerSec)
{
    BeltPwmCalc c;
    u16 sc = BeltScaleX100(b);

    c.sc = sc;

    c.arrFloor = BeltArrAtCmps(b, (u8)BELT_SPEED_MIN);

    if (b->spCache == cmPerSec && b->scCache == sc)
    {
        c.arrTgt   = b->arrCache;
        c.cacheHit = 1u;
        return c;
    }

    c.arrTgt   = BeltArrAtCmps(b, cmPerSec);
    c.cacheHit = 0u;
    return c;
}

static void BeltPwmWriteArr(BeltDev* b, u32 arr)
{
    if (arr > (u32)BELT_ARR_16BIT_MAX) arr = (u32)BELT_ARR_16BIT_MAX;
    TIM_SetAutoreload(b->pwmTim, (u16)arr);
}

static void BeltPwmWriteCcr(BeltDev* b, u32 ccr)
{
    if (ccr > (u32)BELT_ARR_16BIT_MAX) ccr = (u32)BELT_ARR_16BIT_MAX;

    /* ������ռһ��������ʱ����Ƶ�ʻ���Ӱ�죺
     *   ��1 = TIM2 channel 3 (PA2)
     *   ��2 = TIM3 channel 4 (PB1)
     * ռ�ձȹ̶� 50%���������Ч��TB6600 ���� + ��©���� */
    if (b->idx == (u8)BELT1) TIM_SetCompare3(TIM2, (u16)ccr);
    else                     TIM_SetCompare4(TIM3, (u16)ccr);
}

static void BeltPwmStop(BeltDev* b)
{
    TIM_Cmd(b->pwmTim, DISABLE);
    BeltPulIdle(b);
}

static void BeltPwmHold(BeltDev* b)
{
    BeltPwmStop(b);
    BeltPulAf(b);
}

static void BeltPwmStartTimer(BeltDev* b)
{
    u32 arr = b->arrNow;
    u32 ccr = (arr + 1u) / 2u;

    if (ccr == 0u) ccr = 1u;

    (void)ccr;

    BeltPulAf(b);
    b->hzNow = 1000000u / (arr + 1u);

    /* Ӳ�� PWM ������1 MHz ������ARR �������ڣ�CCR �̶������� */
    BeltPwmWriteCcr(b, ccr);
    BeltPwmWriteArr(b, arr);
    TIM_Cmd(b->pwmTim, ENABLE);
}

static void BeltPwmStart(BeltDev* b)
{
    BeltPulAf(b);
    BeltPwmStartTimer(b);
}

static void BeltStartRamp(BeltDev* b)
{
    u32 floorArr = b->arrFloor;
    u32 tgt      = b->arrTgt;

    b->arrAcc = 0u;
    if (tgt >= floorArr)
    {
        b->arrNow       = tgt;
        b->arrStepX1000 = 0u;
    }
    else
    {
        b->arrNow       = floorArr;
        b->arrStepX1000 = ((floorArr - tgt) * 1000u) / BELT_RAMP_TICKS;
    }
    b->hzNow = 1000000u / (b->arrNow + 1u);
    BeltPwmWriteArr(b, b->arrNow);
    BeltPwmWriteCcr(b, (b->arrNow + 1u) / 2u);
}

static void BeltSetRampTarget(BeltDev* b)
{
    u32 nowArr = b->arrNow;
    u32 tgt    = b->arrTgt;

    b->arrAcc = 0u;
    if (tgt >= nowArr)
    {

        b->arrNow       = tgt;
        b->arrStepX1000 = 0u;
        b->hzNow        = 1000000u / (tgt + 1u);
        BeltPwmWriteCcr(b, (tgt + 1u) / 2u);
        BeltPwmWriteArr(b, tgt);
    }
    else
    {
        b->arrStepX1000 = ((nowArr - tgt) * 1000u) / BELT_RAMP_TICKS;
    }
}

static void BeltStopOne(BeltDev* b)
{
    u32 pm = __get_PRIMASK();
    __disable_irq();

    BeltPwmStop(b);
    b->running      = 0;
    b->switching    = 0;
    b->pendDir      = 0;
    b->switchT      = 0;
    b->arrNow       = 0;
    b->arrStepX1000 = 0;
    b->arrAcc       = 0;
    b->hzNow        = 0;
    b->stepAcc      = 0;
    __set_PRIMASK(pm);
}

static u8 BeltRunOne(BeltDev* b, u8 cmPerSec, u8 dir)
{
    u32 pm;
    u32 now;
    BeltPwmCalc calc;

    if (cmPerSec < BELT_SPEED_MIN) cmPerSec = BELT_SPEED_MIN;
    if (cmPerSec > BELT_SPEED_MAX) cmPerSec = BELT_SPEED_MAX;
    dir = (u8)(dir ? 1 : 0);

    if (Motion_BeltLocked(b->idx) != 0u)
    {
        BeltStopOne(b);
        return 0u;
    }

    now  = Time_Now();
    calc = BeltCalcPwm(b, cmPerSec);

    pm = __get_PRIMASK();
    __disable_irq();

    b->arrFloor = calc.arrFloor;
    b->arrTgt   = calc.arrTgt;
    if (calc.cacheHit == 0u)
    {
        b->spCache  = cmPerSec;
        b->scCache  = calc.sc;
        b->arrCache = calc.arrTgt;
    }

    if (b->running && b->dirLevel != dir)
    {
        b->running     = 0;
        b->switching   = 1;
        b->pendDir     = dir;
        b->switchT     = now + BELT_DIR_SWITCH_MS;
        BeltPwmHold(b);
        __set_PRIMASK(pm);
        return 1u;
    }

    if (b->switching)
    {
        if (b->dirLevel == dir)
        {
            b->switching = 0;
            BeltStartRamp(b);
            BeltPwmStart(b);
            b->running = 1;
            __set_PRIMASK(pm);
            return 1u;
        }

        b->pendDir = dir;
        b->switchT = now + BELT_DIR_SWITCH_MS;

        __set_PRIMASK(pm);
        return 2u;
    }

    BeltApplyDir(b, dir);

    if (!b->running)
    {
        BeltStartRamp(b);
        BeltPwmStart(b);
    }
    else
    {
        BeltSetRampTarget(b);
    }
    b->running = 1;

    __set_PRIMASK(pm);
    return 1u;
}

void Belt_Init(void)
{
    u8 i;

    s_belt[BELT1].dirPin = PIN_BELT1_DIR;
    s_belt[BELT1].pulPin = PIN_BELT1_PUL;
    s_belt[BELT2].dirPin = PIN_BELT2_DIR;
    s_belt[BELT2].pulPin = PIN_BELT2_PUL;


    for (i = 0; i < BELT_NUM; i++)
    {
        BeltDev* b = &s_belt[i];

        BeltApplyDir(b, 0u);
        BeltPulIdle(b);
    }

    for (i = 0; i < BELT_NUM; i++)
    {
        BeltDev* b = &s_belt[i];

        b->running       = 0;
        b->switching     = 0;
        b->switchT       = 0;
        b->dirLevel      = 0;
        b->pendDir       = 0;
        b->arrNow        = 0;
        b->arrTgt        = 0;
        b->arrFloor      = BeltArrAtCmps(b, (u8)BELT_SPEED_MIN);
        b->arrStepX1000  = 0;
        b->arrAcc        = 0;
        b->hzNow         = 0;
        b->spCache       = 0;
        b->scCache       = 0;
        b->arrCache      = 0;
        b->stepAcc       = 0;
    }
    s_tickDiv = 0u;

    /* ---- ����Ӳ�� PWM����ռһ��������ʱ����ARR ����Ӱ�� ----
     *   ��1 = TIM2 channel 3 -> PA2
     *   ��2 = TIM3 channel 4 -> PB1
     * �����ӷ�����© + TIM_OCPolarity_Low���������Ч�� */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3, ENABLE);
    {
        TIM_TimeBaseInitTypeDef t;
        TIM_OCInitTypeDef       oc;
        u16 arr0 = (u16)(BELT_PWM_ARR_MIN - 1u);
        u16 ccr0 = (u16)((arr0 + 1u) / 2u);

        if (ccr0 == 0u) ccr0 = 1u;

        t.TIM_ClockDivision     = TIM_CKD_DIV1;
        t.TIM_CounterMode       = TIM_CounterMode_Up;
        t.TIM_Period            = arr0;
        t.TIM_Prescaler         = (u16)(BELT_PWM_PSC_1US);
        t.TIM_RepetitionCounter = 0u;

        oc.TIM_OCMode       = TIM_OCMode_PWM1;
        oc.TIM_OutputState  = TIM_OutputState_Enable;
        oc.TIM_OutputNState = TIM_OutputNState_Disable;
        oc.TIM_Pulse        = ccr0;
        oc.TIM_OCPolarity   = TIM_OCPolarity_Low;
        oc.TIM_OCNPolarity  = TIM_OCNPolarity_High;
        oc.TIM_OCIdleState  = TIM_OCIdleState_Set;
        oc.TIM_OCNIdleState = TIM_OCNIdleState_Reset;

        TIM_TimeBaseInit(TIM2, &t);
        TIM_ARRPreloadConfig(TIM2, ENABLE);
        TIM_OC3Init(TIM2, &oc);
        TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);
        TIM_Cmd(TIM2, DISABLE);

        TIM_TimeBaseInit(TIM3, &t);
        TIM_ARRPreloadConfig(TIM3, ENABLE);
        TIM_OC4Init(TIM3, &oc);
        TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);
        TIM_Cmd(TIM3, DISABLE);

        s_belt[BELT1].pwmTim = TIM2;
        s_belt[BELT1].pwmCh  = (u16)TIM_Channel_3;
        s_belt[BELT2].pwmTim = TIM3;
        s_belt[BELT2].pwmCh  = (u16)TIM_Channel_4;
    }

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    {
        TIM_TimeBaseInitTypeDef t;

        t.TIM_ClockDivision     = TIM_CKD_DIV1;
        t.TIM_CounterMode       = TIM_CounterMode_Up;
        t.TIM_Period            = (u16)(BELT_TIM_ARR_100US - 1u);
        t.TIM_Prescaler         = (u16)(BELT_PWM_PSC_1US);
        t.TIM_RepetitionCounter = 0;
        TIM_TimeBaseInit(TIM4, &t);
        TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
        TIM_Cmd(TIM4, ENABLE);
    }

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    {
        NVIC_InitTypeDef n;

        n.NVIC_IRQChannel                   = TIM4_IRQn;
        n.NVIC_IRQChannelCmd                = ENABLE;
        n.NVIC_IRQChannelPreemptionPriority = 0;
        n.NVIC_IRQChannelSubPriority        = 0;
        NVIC_Init(&n);
    }
}

void Belt_Run(u8 idx, u8 cmPerSec, u8 dir)
{
    if (idx >= BELT_NUM) return;
    (void)BeltRunOne(&s_belt[idx], cmPerSec, dir);
}

void Belt_Stop(u8 idx)
{
    if (idx >= BELT_NUM) return;
    BeltStopOne(&s_belt[idx]);
}

u8 Belt1_Run(u8 cmps)
{
    return Belt1_RunDir(cmps, (u8)(gParam.beltDir[BELT1] ? 1u : 0u));
}

u8 Belt1_RunDir(u8 cmps, u8 dir)
{
    u8 ok;

    if (cmps == 0u)
    {
        BeltStopOne(&s_belt[BELT1]);
        ok = 1u;
    }
    else
    {
        ok = BeltRunOne(&s_belt[BELT1], cmps, dir);
    }
    Delay_ms((u32)CFG_BELT_SETTLE_MS);
    return ok;
}

u8 Belt1_Stop(void)
{
    BeltStopOne(&s_belt[BELT1]);
    Delay_ms((u32)CFG_BELT_SETTLE_MS);
    return 1u;
}

u8 Belt1_IsRunning(void)
{
    return (u8)(s_belt[BELT1].running ? 1 : 0);
}

u8 Belt2_Run(u8 cmps)
{
    return Belt2_RunDir(cmps, (u8)(gParam.beltDir[BELT2] ? 1u : 0u));
}

u8 Belt2_RunDir(u8 cmps, u8 dir)
{
    u8 ok;

    if (cmps == 0u)
    {
        BeltStopOne(&s_belt[BELT2]);
        ok = 1u;
    }
    else
    {
        ok = BeltRunOne(&s_belt[BELT2], cmps, dir);
    }
    Delay_ms((u32)CFG_BELT_SETTLE_MS);
    return ok;
}

u8 Belt2_Stop(void)
{
    BeltStopOne(&s_belt[BELT2]);
    Delay_ms((u32)CFG_BELT_SETTLE_MS);
    return 1u;
}

u8 Belt2_IsRunning(void)
{
    return (u8)(s_belt[BELT2].running ? 1 : 0);
}

static u8 s_lockBelt[2] = { 0u, 0u };
static u8 s_lockServo  = 0u;

void Motion_Lock(u8 target, u8 unlock)
{
    u8 lk = (u8)(unlock ? 0u : 1u);

    if (target == 1u)
    {
        s_lockBelt[BELT1] = lk;
        if (lk) (void)Belt1_Stop();
    }
    else if (target == 2u)
    {
        s_lockBelt[BELT2] = lk;
        if (lk) (void)Belt2_Stop();
    }
    else if (target == 3u)
    {
        s_lockServo = lk;
    }
}

u8 Motion_BeltLocked(u8 idx) { return (u8)((idx < (u8)BELT_NUM) ? s_lockBelt[idx] : 1u); }

u8 Motion_ServoLocked(void)  { return s_lockServo; }

void Belt_StopAll(void)
{
    Belt_Stop(BELT1);
    Belt_Stop(BELT2);
}

u8 Belt_IsRunning(u8 idx)
{
    if (idx >= BELT_NUM) return 0;
    return (u8)(s_belt[idx].running ? 1 : 0);
}

u8 Belt_IsSwitching(u8 idx)
{
    if (idx >= BELT_NUM) return 0;
    return (u8)(s_belt[idx].switching ? 1 : 0);
}

u8 Belt_IsBusy(u8 idx)
{
    if (idx >= BELT_NUM) return 0;
    return (u8)((s_belt[idx].running || s_belt[idx].switching) ? 1 : 0);
}

u16 g_beltSwitchTimeout = 0u;

void Belt_Watchdog(void)
{
    u8  i;
    u32 now = Time_Now();

    for (i = 0u; i < (u8)BELT_NUM; i++)
    {
        BeltDev* b = &s_belt[i];

        if (b->switching == 0u) continue;

        if ((s32)(now - b->switchT) > (s32)BELT_SWITCH_TIMEOUT_MS)
        {
            BeltStopOne(b);
            if (g_beltSwitchTimeout < 0xFFFFu) g_beltSwitchTimeout++;
        }
    }
}

void Belt_IsrTick(void)
{
    u8  i;
    u32 now;
    u32 t0 = Time_RawUs();
    u32 t1;

    /* Do NOT re-test UIF here: TIM4_IRQHandler already cleared it, so a test
     * would always see RESET and bail out before Time_TickFromIrq() ever ran,
     * freezing s_ms and hanging PowerUp_WaitMs(). Clearing again is harmless. */
    TIM_ClearITPendingBit(TIM4, TIM_IT_Update);

    s_tickDiv++;
    if (s_tickDiv >= (u8)BELT_TICK_DIV)
    {
        s_tickDiv = 0u;
        Time_TickFromIrq();
    }

    /* �����ƣ�TIM2 ���ø���1 PWM�����������Ƶ��ת��
     * TIM4 = 10 kHz��ÿ 5000 �� = 500 ms���õ� 2 Hz������Ҫ��� 0.5 s Ƶ�ʣ��� */
    if (++s_hbDiv >= (u16)BELT_HB_DIV)
    {
        s_hbDiv = 0u;
        Bsp_HbToggle();
    }

    now = Time_Now();

    for (i = 0; i < BELT_NUM; i++)
    {
        BeltDev* b = &s_belt[i];

        if (b->switching && (s32)(now - b->switchT) >= 0)
        {
            b->switching = 0;
            b->dirLevel  = b->pendDir;
            BELT_DIR_HOT(b, b->dirLevel);
            BeltStartRamp(b);
            BeltPwmStartTimer(b);
            b->running = 1;
        }
    }

    for (i = 0; i < BELT_NUM; i++)
    {
        BeltDev* b = &s_belt[i];

        if (!b->running) continue;

        if (b->arrNow > b->arrTgt)
        {
            u32 dec;

            b->arrAcc += b->arrStepX1000;
            dec = b->arrAcc / 1000u;
            b->arrAcc -= dec * 1000u;

            if (dec != 0u)
            {
                if ((b->arrNow - b->arrTgt) <= dec) b->arrNow = b->arrTgt;
                else                                b->arrNow -= dec;
                if (b->arrNow < (u32)BELT_PWM_ARR_MIN) b->arrNow = (u32)BELT_PWM_ARR_MIN;

                BeltPwmWriteCcr(b, (b->arrNow + 1u) / 2u);
                BeltPwmWriteArr(b, b->arrNow);
                b->hzNow = 1000000u / (b->arrNow + 1u);
            }
        }
        else if (b->arrNow < b->arrTgt)
        {

            b->arrNow = b->arrTgt;
            b->hzNow  = 1000000u / (b->arrNow + 1u);
            BeltPwmWriteCcr(b, (b->arrNow + 1u) / 2u);
            BeltPwmWriteArr(b, b->arrNow);
        }

        b->stepAcc += b->hzNow;
        if (b->stepAcc >= BELT_STEP_ACC_FULL)
        {
            u32 add = b->stepAcc / BELT_STEP_ACC_FULL;

            b->stepCnt += add;
            b->stepAcc -= add * BELT_STEP_ACC_FULL;
        }
    }

    t1 = Time_RawUs();
    {
        u16 w = (u16)(t1 - t0);

        if (w > (u16)BELT_ISR_W_MAX_US) w = (u16)BELT_ISR_W_MAX_US;
        g_beltIsrLastUs = w;
        if (w > g_beltIsrMaxUs) g_beltIsrMaxUs = w;
    }
}

u32 Belt_StepCount(u8 idx)
{
    if (idx >= BELT_NUM) return 0u;
    return s_belt[idx].stepCnt;
}

#define BELT_CM_AT_SC100_X100   18850u
#define BELT_SC_MAX             800u
#define BELT_CM_MAX_X100        (BELT_CM_AT_SC100_X100 * 100u / BELT_SC_MAX)
STATIC_ASSERT(BELT_CM_MAX_X100 > ((u32)BELT_SPEED_MAX * 100u), belt_effcmps_covers_speed_max);

u16 Belt_PulseHzAt(u8 idx, u8 cmPerSec)
{
    float hz;

    if (idx >= BELT_NUM) return 0u;
    if (cmPerSec == 0u)  return 0u;

    hz = (float)cmPerSec / BELT_CIRCUM_CM * ((float)BELT_STEPS_REV * (float)BELT_MICROSTEP);
    hz = hz * (float)BeltScaleX100(&s_belt[idx]) / (float)BELT_SCALE_FULL_PCT;
    if (hz > 65535.0f) hz = 65535.0f;
    return (u16)(hz + 0.5f);
}

u8 Belt_EffCmps(u8 idx)
{
    u16 sc;
    float cmMax;
    s16 want;

    if (idx >= BELT_NUM) return (u8)BELT_SPEED_MIN;

    sc = BeltScaleX100(&s_belt[idx]);

    cmMax = (float)BELT_PWM_HZ_MAX * BELT_CIRCUM_CM
            / ((float)BELT_STEPS_REV * (float)BELT_MICROSTEP) * ((float)BELT_SCALE_FULL_PCT / (float)sc);

    want = gParam.beltSpeed[idx];
    if (want < (s16)BELT_SPEED_MIN) want = (s16)BELT_SPEED_MIN;

    if ((float)want > cmMax) return (u8)cmMax;
    return (u8)want;
}
