#include "Bsp/Bsp.h"
#include "Core/Time.h"
#include "stm32f10x.h"

#define WDG_FEED_MS   100u

static GPIOMode_TypeDef Bsp_GpioMode(u8 dir)
{
    switch (dir)
    {
    case PDIR_IN_FLOAT: return GPIO_Mode_IN_FLOATING;
    case PDIR_IN_PU:    return GPIO_Mode_IPU;
    case PDIR_IN_PD:    return GPIO_Mode_IPD;
    case PDIR_OUT_PP:   return GPIO_Mode_Out_PP;
    case PDIR_OUT_OD:   return GPIO_Mode_Out_OD;
    case PDIR_AF_PP:    return GPIO_Mode_AF_PP;
    case PDIR_AF_OD:    return GPIO_Mode_AF_OD;
    case PDIR_AF_FLOAT: return GPIO_Mode_IN_FLOATING;
    default:            return GPIO_Mode_IN_FLOATING;
    }
}

static u8 Bsp_IsOutputDir(u8 dir)
{
    if (dir == PDIR_OUT_OD || dir == PDIR_OUT_PP || dir == PDIR_AF_PP || dir == PDIR_AF_OD) return 1u;
    return 0u;
}

static u8 Bsp_PinBit(u16 mask)
{
    u8 bit;

    for (bit = 0u; bit < 16u; bit++)
    {
        if (mask == (u16)(1u << bit)) return bit;
    }
    return 16u;
}

static void Bsp_PreloadOutputs(void)
{
#define BSP_PRELOAD_ONE(p, d, l, s) do { if (Bsp_IsOutputDir((u8)(d)) != 0u) Pin_Write((p), (u8)(l)); } while (0);
    BOARD_PIN_INIT(BSP_PRELOAD_ONE)
#undef BSP_PRELOAD_ONE
}

static void Bsp_ConfigOne(PinDef p, u8 dir)
{
    GPIO_InitTypeDef s;

    s.GPIO_Pin   = p.pin;
    s.GPIO_Speed = GPIO_Speed_50MHz;
    s.GPIO_Mode  = Bsp_GpioMode(dir);
    GPIO_Init(p.port, &s);
}

void Bsp_Init(void)
{

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC
                           | RCC_APB2Periph_AFIO, ENABLE);

    /* �ر� JTAG��ֻ���� SWD��PB3(JTDO)/PA15(JTDI)/PB4(NJTRST) �黹Ϊ��ͨ IO��
     * ������紫���������� PB3(��) �� PA15(��)������ JTAG ��������ⲿ��ƽ��
     * SWD(PA13/PA14) ���ֿ��ã�ST-Link �ճ����ص��ԡ�
     */
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

    Bsp_PreloadOutputs();

#define BSP_CONFIG_ONE(p, d, l, s) Bsp_ConfigOne((p), (u8)(d));
    BOARD_PIN_INIT(BSP_CONFIG_ONE)
#undef BSP_CONFIG_ONE

    Bsp_PreloadOutputs();
}

void Bsp_Write(PinDef p, u8 level)
{
    Pin_Write(p, (u8)(level ? 1u : 0u));
}

void Bsp_SetMode(PinDef p, u8 dir)
{
    GPIO_InitTypeDef s;

    if (dir > (u8)PDIR_AF_OD) return;

    if (Bsp_IsOutputDir(dir)) Pin_Write(p, 1u);

    s.GPIO_Pin   = p.pin;
    s.GPIO_Speed = GPIO_Speed_50MHz;
    s.GPIO_Mode  = Bsp_GpioMode(dir);
    GPIO_Init(p.port, &s);
}

u8 Bsp_Read(PinDef p)
{
    return Pin_Read(p);
}

void Bsp_ExtiConfig(PinDef p, u8 bothEdges, u8 irqPrio)
{
    EXTI_InitTypeDef e;
    NVIC_InitTypeDef n;
    u8 bit;
    u8 src;
    u8 chan;

    bit = Bsp_PinBit(p.pin);
    if (bit > 15u) return;

    if (irqPrio > 3u) irqPrio = 3u;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

    src = Pin_ExtiPortSource(p);
    GPIO_EXTILineConfig(src, bit);

    e.EXTI_Line    = (u32)0x01u << bit;
    e.EXTI_Mode    = EXTI_Mode_Interrupt;
    e.EXTI_Trigger = bothEdges ? EXTI_Trigger_Rising_Falling : EXTI_Trigger_Falling;
    e.EXTI_LineCmd = ENABLE;
    EXTI_Init(&e);

    EXTI_ClearITPendingBit(e.EXTI_Line);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    if (bit < 5u)       chan = (u8)(EXTI0_IRQn + (s32)bit);
    else if (bit < 10u) chan = (u8)EXTI9_5_IRQn;
    else                chan = (u8)EXTI15_10_IRQn;

    n.NVIC_IRQChannel = chan;
    n.NVIC_IRQChannelPreemptionPriority = irqPrio;
    n.NVIC_IRQChannelSubPriority = (u8)(bit & 0x03u);
    n.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&n);
}

void Bsp_WdgInit(void)
{
    DBGMCU_Config(DBGMCU_IWDG_STOP, ENABLE);
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
    IWDG_SetPrescaler(IWDG_Prescaler_64);
    IWDG_SetReload(625u);
    IWDG_ReloadCounter();
    IWDG_Enable();
}

void Bsp_HbInit(void)
{
    /* ��������ռ�� TIM2 ���� TIM2 �Ѹ�����1 ����Ӳ�� PWM��CH3 -> PA2����
     * �������� TIM4 �� 10 kHz ISR ��Ƶ��ת��Belt.c::Belt_IsrTick��5000 �� = 2 Hz����
     * ����������Ϊ�ն��壬��Ϊά�� main.c �ĳ�ʼ������˳�򲻱䡣 */
}

void Bsp_HbToggle(void)
{
    static u8 s_lv = 1u;

    s_lv = (u8)(s_lv ^ 1u);
    Pin_Write(PIN_LED_HB, s_lv);
}

void Bsp_WdgFeed(void)
{
    static u32 lastMs = 0u;
    u32 now = Time_Now();

    if ((u32)(now - lastMs) >= (u32)WDG_FEED_MS)
    {
        lastMs = now;
        IWDG_ReloadCounter();
    }
}
