#include "Core/Types.h"
#include "Core/Time.h"
#include "Bsp/Bsp.h"
#include "Modules/Encoder.h"

#define KEY_LONG_MS       2000u
#define KEY_SHORT_MIN_MS  30u
#define KEY_HIST_BITS     15u
#define KEY_HIST_MASK     ((u32)((1u << KEY_HIST_BITS) - 1u))
#define ENC_EV_QUEUE_N    8u
#define ENC_ROT_LIMIT     10000

static volatile s16 s_rotAcc    = 0;
static volatile s8  s_encSub    = 0;
static volatile u8  s_encLastAB = 0;
static volatile u32 s_keyHist   = 0;
static volatile u8  s_keyAny    = 0;

static u8  s_evQ[ENC_EV_QUEUE_N];
static u8  s_evHead = 0;
static u8  s_evTail = 0;
static u8  s_keyStable = 0;
static u32 s_keyDownMs = 0;

static u8 Enc_KeyRaw(void)
{
    /* ������������ͬ���ܣ�PA12(P5) �� PB15(P0)����Ϊ����+���½ӵصĵ���Ч */
#if ENC_KEY_ACTIVE_HIGH
    u8 k1 = (u8)(Bsp_Read(PIN_ENC_KEY) ? 1u : 0u);
    u8 k2 = (u8)(Bsp_Read(PIN_KEY_P0)  ? 1u : 0u);
#else
    u8 k1 = (u8)(Bsp_Read(PIN_ENC_KEY) ? 0u : 1u);
    u8 k2 = (u8)(Bsp_Read(PIN_KEY_P0)  ? 0u : 1u);
#endif

    return (u8)(((k1 != 0u) || (k2 != 0u)) ? 1u : 0u);
}

static void Enc_PushEvent(u8 ev)
{
    u8 next = (u8)((s_evHead + 1u) % ENC_EV_QUEUE_N);

    if (next == s_evTail)
    {
        s_evTail = (u8)((s_evTail + 1u) % ENC_EV_QUEUE_N);
    }
    s_evQ[s_evHead] = ev;
    s_evHead = next;
}

void Enc_Init(void)
{

    s_rotAcc    = 0;
    s_encSub    = 0;
    s_evHead    = 0;
    s_evTail    = 0;
    s_keyStable = 0;
    s_keyDownMs = 0;
    s_keyAny    = 0;
    s_keyHist   = 0;

    s_encLastAB = (u8)(((u8)(Bsp_Read(PIN_ENC_A) ? 1u : 0u) << 1) |
                        (u8)(Bsp_Read(PIN_ENC_B) ? 1u : 0u));
}

void Enc_IsrTick(void)
{
    u8 curAB = (u8)(((u8)(Bsp_Read(PIN_ENC_A) ? 1u : 0u) << 1) |
                     (u8)(Bsp_Read(PIN_ENC_B) ? 1u : 0u));
    u8 idx   = (u8)((s_encLastAB << 2) | curAB);
    s8 dir   = 0;
    u8 k;

    switch (idx)
    {

        case 0x01: case 0x07: case 0x0E: case 0x08:
            dir = 1;
            break;

        case 0x02: case 0x0B: case 0x0D: case 0x04:
            dir = -1;
            break;

        default:
            break;
    }

    if (dir != 0)
    {
#if ENC_REVERSE
        dir = (s8)(-dir);
#endif
        s_encSub = (s8)(s_encSub + dir);

        if (s_encSub >= (s8)ENC_STEP_DIV)
        {
            s_encSub = (s8)(s_encSub - (s8)ENC_STEP_DIV);
            if (s_rotAcc < (s16)ENC_ROT_LIMIT) s_rotAcc++;
        }
        if (s_encSub <= (s8)(-ENC_STEP_DIV))
        {
            s_encSub = (s8)(s_encSub + (s8)ENC_STEP_DIV);
            if (s_rotAcc > (s16)(-ENC_ROT_LIMIT)) s_rotAcc--;
        }
    }

    s_encLastAB = curAB;

    k = Enc_KeyRaw();
    s_keyHist = (s_keyHist << 1) | (u32)k;
    if (k != 0u) s_keyAny = 1u;
}

void Enc_Task(void)
{
    u32 hist;
    u8  seen;
    u8  allUp;

    seen = s_keyAny;
    s_keyAny = 0;
    hist = s_keyHist;

    allUp   = (u8)(((hist & KEY_HIST_MASK) == 0u) ? 1u : 0u);

    if (s_keyStable == 0u)
    {
        if ((hist & KEY_HIST_MASK) == KEY_HIST_MASK)
        {
            s_keyStable = 1u;
            s_keyDownMs = Time_Now();
            Enc_PushEvent(ENC_EV_DOWN);
        }
        else if ((seen != 0u) && allUp)
        {

            Enc_PushEvent(ENC_EV_SHORT);
            Enc_PushEvent(ENC_EV_UP);
        }
        else
        {

        }
    }
    else if (s_keyStable == 1u)
    {
        if (Time_Elapsed(s_keyDownMs, KEY_LONG_MS))
        {
            s_keyStable = 2u;
            Enc_PushEvent(ENC_EV_LONG);
        }
        else if (allUp)
        {
            if (Time_Since(s_keyDownMs) >= KEY_SHORT_MIN_MS)
            {
                Enc_PushEvent(ENC_EV_SHORT);
            }
            s_keyStable = 0u;
            Enc_PushEvent(ENC_EV_UP);
        }
        else
        {

        }
    }
    else
    {
        if (allUp)
        {
            s_keyStable = 0u;
            Enc_PushEvent(ENC_EV_UP);
        }
    }
}

s16 Enc_TakeRotate(void)
{
    s16 v;
    u32 pm = __get_PRIMASK();

    __disable_irq();
    v = s_rotAcc;
    s_rotAcc = 0;
    __set_PRIMASK(pm);

    return v;
}

u8 Enc_TakeEvent(void)
{
    u8 ev;

    if (s_evHead == s_evTail) return ENC_EV_NONE;

    ev = s_evQ[s_evTail];
    s_evTail = (u8)((s_evTail + 1u) % ENC_EV_QUEUE_N);
    return ev;
}

u8 Enc_KeyDown(void)
{
    return (u8)((s_keyStable != 0u) ? 1u : 0u);
}
