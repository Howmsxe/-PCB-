#include "Core/Types.h"
#include "Bsp/Bsp.h"
#include "Modules/Display/MyI2C.h"

static u8 s_busBusy = 0;
static u8 s_busNest = 0;

void MyI2C_BusEnter(void)
{
    if (s_busBusy != 0u) s_busNest = 1u;
    s_busBusy = 1u;
}

void MyI2C_BusLeave(void)
{
    s_busBusy = 0u;
}

u8 MyI2C_BusBusy(void) { return s_busBusy; }
u8 MyI2C_BusNest(void) { return s_busNest; }

#define MYI2C_SCL_MAX_HZ   400000uL
#define MYI2C_SCL_HALF_NS  (1000000000uL / MYI2C_SCL_MAX_HZ / 2uL)
#define MYI2C_LOOP_CYCLES  4u
#define MYI2C_NS_PER_CYCLE 13u
#define MYI2C_DELAY_LOOP   40u

STATIC_ASSERT((u32)MYI2C_DELAY_LOOP * MYI2C_LOOP_CYCLES * MYI2C_NS_PER_CYCLE
              >= (u32)MYI2C_SCL_HALF_NS, myi2c_scl_le_400k);

static void MyI2C_Delay(void)
{
    volatile u16 i;

    for (i = 0; i < (u16)MYI2C_DELAY_LOOP; i++)
    {

    }
}

static void MyI2C_W_SCL(u8 BitValue)
{
    Bsp_Write(PIN_PCA_SCL, (u8)(BitValue ? 1u : 0u));
    MyI2C_Delay();
}

static void MyI2C_W_SDA(u8 BitValue)
{
    Bsp_Write(PIN_PCA_SDA, (u8)(BitValue ? 1u : 0u));
    MyI2C_Delay();
}

static u8 MyI2C_R_SDA(void)
{
    u8 v;

    MyI2C_Delay();
    v = (u8)(Bsp_Read(PIN_PCA_SDA) ? 1u : 0u);
    MyI2C_Delay();

    return v;
}

void MyI2C_Init(void)
{

    MyI2C_W_SCL(1);
    MyI2C_W_SDA(1);
}

void MyI2C_Start(void)
{
    MyI2C_W_SCL(1);
    MyI2C_W_SDA(1);
    MyI2C_W_SDA(0);
    MyI2C_W_SCL(0);
}

void MyI2C_Stop(void)
{
    MyI2C_W_SDA(0);
    MyI2C_W_SCL(1);
    MyI2C_W_SDA(1);
}

void MyI2C_SendByte(uint8_t Byte)
{
    u8 i;

    for (i = 0; i < 8u; i++)
    {
        MyI2C_W_SDA((u8)((Byte & (uint8_t)(0x80u >> i)) ? 1u : 0u));
        MyI2C_W_SCL(1);
        MyI2C_W_SCL(0);
    }
}

uint8_t MyI2C_ReceiveByte(void)
{
    uint8_t Byte = 0x00;
    u8 i;

    MyI2C_W_SDA(1);
    for (i = 0; i < 8u; i++)
    {
        MyI2C_W_SCL(1);
        if (MyI2C_R_SDA() == 1u) Byte = (uint8_t)(Byte | (uint8_t)(0x80u >> i));
        MyI2C_W_SCL(0);
    }
    return Byte;
}

void MyI2C_SendAck(uint8_t AckBit)
{
    MyI2C_W_SDA((u8)(AckBit ? 1u : 0u));
    MyI2C_W_SCL(1);
    MyI2C_W_SCL(0);
}

uint8_t MyI2C_ReceiveAck(void)
{
    uint8_t AckBit;

    MyI2C_W_SDA(1);
    MyI2C_W_SCL(1);
    AckBit = MyI2C_R_SDA();
    MyI2C_W_SCL(0);
    return AckBit;
}
