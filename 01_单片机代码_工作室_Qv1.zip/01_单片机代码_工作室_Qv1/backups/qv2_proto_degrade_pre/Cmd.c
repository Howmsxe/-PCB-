#include "App/Cmd.h"
#include "Modules/SerialPort.h"
#include "Modules/Params.h"
#include "Core/ParamCode.h"
#include "App/ParamSet.h"
#include "Core/Time.h"
#include "Core/ProtoTx.h"
#include "Core/ProtoRx.h"

static void Cmd_Num(s16 v)
{
    char b[8];
    u8   n = 0;
    u16  u;
    u16  d;
    u8   neg = 0;

    if (v < 0) { neg = 1; u = (u16)(-(s32)v); }
    else       { u = (u16)v; }

    for (d = 10000; d > 0u; d = (u16)(d / 10u))
    {
        if (u >= d || n > 0u)
        {
            b[n++] = (char)('0' + (u8)((u / d) % 10u));
            if (n >= 6u) break;
        }
    }
    if (n == 0u) b[n++] = '0';
    b[n] = 0;
    if (neg) Ser_SendByte((u8)'-');
    Ser_SendStr(b);
}

static void Cmd_NumU32(u32 v)
{
    char b[16];
    u8   n = 0;
    u8   i;
    u32  d;

    if (v == 0u) { Ser_SendByte((u8)'0'); return; }
    for (d = 1000000000ul; d > 0u; d /= 10u)
    {
        if (v >= d || n > 0u)
        {
            b[n++] = (char)('0' + (u8)((v / d) % 10u));
            if (n >= 10u) break;
        }
    }
    for (i = 0u; i < n; i++) Ser_SendByte((u8)b[i]);
}

void Cmd_ParamExport(void)
{
    u8  code;
    s16 v;

    Ser_SendByte((u8)PROTO_TX_PARAM_BEGIN);
    for (code = PARAM_CODE_POS_FIRST; code <= PARAM_CODE_BELT_MICRO1; code++)
    {
        if (ParamCode_Get(&gParam, code, &v) == 0u) continue;
        Ser_SendByte(code);
        Ser_SendByte((u8)((u16)v & 0xFFu));
        Ser_SendByte((u8)(((u16)v >> 8) & 0xFFu));
        Ser_SendByte((u8)PARAM_CODE_END);
    }
    Ser_SendByte((u8)PROTO_TX_PARAM_END);
}

void Cmd_ParamImportStart(void)
{
    Ser_SendStr("PARM,READY\r\n");
}

void Cmd_Init(void)
{
}

void Cmd_Task(void)
{

    (void)Proto_Importing();
    (void)ParamSet_TakeSaved();
}

void Cmd_SendEvt(s16 evt)
{
    Ser_SendStr("EVT,");
    Cmd_Num(evt);
    Ser_SendStr("\r\n");
}

void Cmd_SendWarn(const char* tag)
{
    Ser_SendStr("WARN,");
    Ser_SendStr(tag);
    Ser_SendStr("\r\n");
}

void Cmd_SendWarnU32(const char* tag, u32 v)
{
    Ser_SendStr("WARN,");
    Ser_SendStr(tag);
    Ser_SendByte((u8)',');
    Cmd_NumU32(v);
    Ser_SendStr("\r\n");
}

void Cmd_SendMode(const char* tag)
{
    Ser_SendStr("MODE,");
    Ser_SendStr(tag);
    Ser_SendStr("\r\n");
}

void Cmd_SendFlow(const char* tag)
{
    Ser_SendStr("FLOW,");
    Ser_SendStr(tag);
    Ser_SendStr("\r\n");
}

static void Cmd_SendBin8(u8 v)
{
    s8 i;

    for (i = 7; i >= 0; i--)
    {
        Ser_SendByte((u8)('0' + (u8)((v >> (u8)i) & 1u)));
    }
}

void Cmd_SendStall(u16 code)
{
    if (code == 0u) return;

    Ser_SendStr("STALL,");
    Cmd_SendBin8((u8)code);
    Ser_SendStr("\r\n");
    Proto_SendIntErr((u8)code);
}

u8 Cmd_Importing(void) { return Proto_Importing(); }
