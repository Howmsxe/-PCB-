#ifndef __CORE_PROTO_RX_H
#define __CORE_PROTO_RX_H

#include "Core/Types.h"

#define PROTO_RX_START_COMM   0x53u
#define PROTO_RX_READY        0x54u
#define PROTO_RX_ACCEPT       0x55u
#define PROTO_RX_RETRY        0x57u
#define PROTO_RX_END_COMM     0x5Cu
#define PROTO_RX_CONFIRM      0x0Fu
#define PROTO_RX_IDLE_BYTE    0x00u

#define PROTO_RX_ACT_START_MAIN      2u
#define PROTO_RX_ACT_CANCEL_ALL      3u
#define PROTO_RX_ACT_BOX_1           4u
#define PROTO_RX_ACT_BOX_6           9u
#define PROTO_RX_ACT_RESET          10u
#define PROTO_RX_ACT_ESTOP_HOME     11u
#define PROTO_RX_ACT_EXPORT         12u
#define PROTO_RX_ACT_IMPORT         13u
#define PROTO_RX_ACT_MAX            13u

#define PROTO_SESSION_TIMEOUT_MS     5000u

#define PROTO_IMPORT_TIMEOUT_MS     15000u

void Proto_RxByte(u8 b);
void Proto_Poll(void);
void Proto_Enable(void);
u8   Proto_Importing(void);

#endif
