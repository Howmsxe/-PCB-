#include "Core/Types.h"
#include "Core/ProtoRx.h"
#include "Core/ProtoTx.h"
#include "Core/Time.h"
#include "Core/ParamCode.h"
#include "Modules/SerialPort.h"
#include "Modules/Params.h"
#include "App/Flow.h"
#include "App/Cmd.h"
#include "App/ParamSet.h"
#include "Ui/Ui.h"

typedef enum {
    PROTO_ST_IDLE = 0,
    PROTO_ST_WAIT_ACTION,
    PROTO_ST_WAIT_CONFIRM
} ProtoState;

static void Proto_ExecAction(u8 act);
static void Proto_SessionTick(void);
static void Proto_ImportBegin(void);
static void Proto_ImportReset(void);
static void Proto_ImportFinish(void);
static void Proto_ImportBad(void);
static void Proto_ImportTimeout(void);
static void Proto_ImportByte(u8 b);
static void Proto_ImportTick(void);

static u8 s_enabled = 0u;

static u8 s_state = (u8)PROTO_ST_IDLE;

static u8 s_action = 0u;

static u32 s_t0 = 0u;

static void Proto_ExecAction(u8 act)
{
    switch (act)
    {
    case (u8)PROTO_RX_ACT_START_MAIN:
        UI_EStop();
        if (Flow_Start() == 0u)
        {
            Proto_SendExtErr((u8)PROTO_EXT_BAD_STATE);
        }
        break;

    case (u8)PROTO_RX_ACT_CANCEL_ALL:
        UI_EStop();
        Flow_Abort();
        break;

    case (u8)PROTO_RX_ACT_RESET:
        if (Flow_Reset() == 0u)
        {
            Proto_SendExtErr((u8)PROTO_EXT_BAD_STATE);
        }
        break;

    case (u8)PROTO_RX_ACT_ESTOP_HOME:
        UI_EStop();
        Flow_Home();
        break;

    case (u8)PROTO_RX_ACT_EXPORT:
        Cmd_ParamExport();
        break;

    case (u8)PROTO_RX_ACT_IMPORT:
        Proto_ImportBegin();
        break;

    default:

        if ((act >= (u8)PROTO_RX_ACT_BOX_1) && (act <= (u8)PROTO_RX_ACT_BOX_6))
        {
            if (Flow_SetBox((u8)(act - (u8)PROTO_RX_ACT_BOX_1 + 1u)) == 0u)
            {
                Proto_SendExtErr((u8)PROTO_EXT_BAD_STATE);
            }
        }
        break;
    }
}

static u8  s_impOn   = 0u;
static u32 s_impT    = 0u;
static u8  s_impN    = 0u;
static u8  s_impCode = 0u;
static u8  s_impLo   = 0u;
static u8  s_impHi   = 0u;

static void Proto_ImportBegin(void)
{
    /* 参数导入已降级：不进入导入态、不接收参数，直接回 0xB3 接受确认，
     * 让上位机的导入流程能走完（不写 Flash）。 */
    s_impOn = 0u;
    Ser_SendByte((u8)PROTO_TX_PARAM_OK);
}

static void Proto_ImportReset(void)
{
    s_impOn = 0u;
    s_impN  = 0u;
}

static void Proto_ImportFinish(void)
{
    Proto_ImportReset();
    Params_ClampAll(Params_Draft());
    ParamSet_ReqSave();
    Ser_SendByte((u8)PROTO_TX_PARAM_OK);
}

static void Proto_ImportBad(void)
{
    Proto_ImportReset();
    Proto_SendExtErr((u8)PROTO_EXT_BAD_DATA);
}

static void Proto_ImportTimeout(void)
{
    Proto_ImportReset();
    Proto_SendExtErr((u8)PROTO_EXT_BAD_STATE);
}

static void Proto_ImportByte(u8 b)
{
    if (s_impN == 0u)
    {
        if ((b == (u8)PROTO_RX_CONFIRM) || (b == (u8)PROTO_RX_IDLE_BYTE))
        {
            return;
        }
        if (b == (u8)PARAM_CODE_END)
        {
            Proto_ImportFinish();
            return;
        }
        s_impCode = b;
        s_impN    = 1u;
        return;
    }

    if (s_impN == 1u)
    {
        s_impLo = b;
        s_impN  = 2u;
        return;
    }

    if (s_impN == 2u)
    {
        s_impHi = b;
        s_impN  = 3u;
        return;
    }

    s_impN = 0u;
    if (b != (u8)PARAM_CODE_END)
    {
        Proto_ImportBad();
        return;
    }
    if (ParamCode_Apply(Params_Draft(), s_impCode,
                        (s16)((u16)s_impLo | ((u16)s_impHi << 8u))) == 0u)
    {
        Proto_ImportBad();
    }
}

static void Proto_ImportTick(void)
{
    if (s_impOn == 0u) return;
    if (!TIME_ELAPSED(s_impT, PROTO_IMPORT_TIMEOUT_MS)) return;
    Proto_ImportTimeout();
}

static void Proto_SessionTick(void)
{
    if (s_state == (u8)PROTO_ST_IDLE) return;
    if (s_impOn != 0u) return;
    if (!TIME_ELAPSED(s_t0, PROTO_SESSION_TIMEOUT_MS)) return;
    s_action = 0u;
    s_state  = (u8)PROTO_ST_IDLE;
}

void Proto_RxByte(u8 b)
{

    if (s_enabled == 0u)
    {
        return;
    }

    if (s_impOn != 0u)
    {
        Proto_ImportByte(b);
        return;
    }

    if (b == (u8)PROTO_RX_IDLE_BYTE)
    {
        return;
    }

    if ((b & 0x80u) != 0u)
    {
        return;
    }

    if (b == (u8)PROTO_RX_START_COMM)
    {
        s_state  = (u8)PROTO_ST_WAIT_ACTION;
        s_action = 0u;
        s_t0     = Time_Now();
        Proto_SendReady();
        return;
    }

    if (b == (u8)PROTO_RX_RETRY)
    {
        s_action = 0u;
        s_state  = (u8)PROTO_ST_IDLE;
        return;
    }

    if (b == (u8)PROTO_RX_END_COMM)
    {
        if (s_state != (u8)PROTO_ST_WAIT_ACTION)
        {
            return;
        }
        if (s_action == 0u)
        {
            Proto_SendExtErr((u8)PROTO_EXT_BAD_STATE);
            return;
        }
        s_state = (u8)PROTO_ST_WAIT_CONFIRM;
        Proto_SendAcceptOk(s_action);
        return;
    }

    if (b == (u8)PROTO_RX_CONFIRM)
    {
        u8 act;

        if (s_state != (u8)PROTO_ST_WAIT_CONFIRM)
        {
            return;
        }
        act      = s_action;
        s_action = 0u;
        s_state  = (u8)PROTO_ST_IDLE;
        Proto_ExecAction(act);
        /* 参数导入（动作13）降级为"直接回 0xB3 接受确认"，不再发 0xD6。 */
        if (act != (u8)PROTO_RX_ACT_IMPORT)
        {
            Proto_SendActionDone();
        }
        return;
    }

    if (s_state == (u8)PROTO_ST_WAIT_ACTION)
    {
        if (b <= (u8)PROTO_RX_ACT_MAX)
        {
            if (b == 1u)
            {
                return;
            }
            s_action = b;
            return;
        }
        return;
    }

}

void Proto_Poll(void)
{
    u8 b;
    u8 n;

    if (s_enabled == 0u)
    {
        for (n = 0u; n < 32u; n++)
        {
            if (!Ser_GetByte(&b))
            {
                return;
            }
        }
        return;
    }

    Proto_ImportTick();
    Proto_SessionTick();

    for (n = 0u; n < 32u; n++)
    {
        if (!Ser_GetByte(&b))
        {
            return;
        }

        Proto_RxByte(b);
    }
}

void Proto_Enable(void)
{
    Ser_Flush();
    s_enabled = 1u;
}

u8 Proto_Importing(void)
{
    return s_impOn;
}
